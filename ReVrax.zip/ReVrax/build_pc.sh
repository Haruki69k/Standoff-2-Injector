#!/bin/bash
# ReVrax v2.0 - PC Build Script (Linux/macOS)
# Requires: Android NDK, CMake 3.10+, Android SDK

set -e

echo "=========================================="
echo "  ReVrax v2.0 - PC Builder"
echo "  Standoff 2 v0.39.2 | ARM64"
echo "=========================================="

# Config
NDK_VERSION="26.1.10909125"
ANDROID_NDK="${ANDROID_SDK}/ndk/${NDK_VERSION}"
BUILD_TYPE="Release"
ABI="arm64-v8a"
API_LEVEL=29

# Check NDK
if [ -z "$ANDROID_SDK" ]; then
    echo "[!] ANDROID_SDK not set, trying default..."
    ANDROID_SDK="$HOME/Android/Sdk"
fi

if [ ! -d "$ANDROID_NDK" ]; then
    echo "[!] NDK not found at $ANDROID_NDK"
    echo "[*] Install via: sdkmanager \"ndk;${NDK_VERSION}\""
    exit 1
fi

echo "[*] NDK: $ANDROID_NDK"

# Clean and create build dir
rm -rf build_pc
mkdir -p build_pc
cd build_pc

# Configure
echo "[*] Configuring with CMake..."
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=$ABI \
    -DANDROID_PLATFORM=android-$API_LEVEL \
    -DCMAKE_BUILD_TYPE=$BUILD_TYPE \
    -DANDROID_STL=c++_static \
    -DCMAKE_C_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector" \
    -DCMAKE_CXX_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector -fno-exceptions -fno-rtti"

# Build
echo "[*] Building..."
cmake --build . --config $BUILD_TYPE --parallel $(nproc)

# Strip
echo "[*] Stripping..."
$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip \
    --strip-all libReVrax.so

# Copy
mkdir -p ../libs/arm64-v8a
cp libReVrax.so ../libs/arm64-v8a/

echo "[+] Build complete: libs/arm64-v8a/libReVrax.so"

# Optional: Build APK
if command -v gradle &> /dev/null; then
    echo "[*] Building APK..."
    cd ..
    gradle assembleRelease
    echo "[+] APK: app/build/outputs/apk/release/app-release.apk"
fi

echo "[+] Done!"
