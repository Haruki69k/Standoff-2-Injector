#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=========================================="
echo "  ReVrax — Termux Build"
echo "=========================================="

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# NDK
if [ -z "$NDK" ]; then
    NDK="$HOME/android-ndk-r29"
fi

TOOLCHAIN="$NDK/build/cmake/android.toolchain.cmake"
if [ ! -f "$TOOLCHAIN" ]; then
    echo -e "${RED}[!] Toolchain не найден: \( TOOLCHAIN \){NC}"
    exit 1
fi
echo -e "${GREEN}[+] NDK: \( NDK \){NC}"

# Зависимости
pkg install -y cmake make clang git 2>/dev/null || true

# ImGui
if [ ! -d "jni/imgui" ]; then
    echo -e "\( {YELLOW}[!] Клонирую ImGui... \){NC}"
    git clone --depth 1 https://github.com/ocornut/imgui.git jni/imgui
fi

# Сборка
BUILD_DIR="jni/build"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo -e "\( {CYAN}[*] CMake configure... \){NC}"
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN" \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM=android-29 \
    -DANDROID_STL=c++_static \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_C_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector" \
    -DCMAKE_CXX_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector -fno-exceptions -fno-rtti" \
    -G "Unix Makefiles"

echo -e "\( {CYAN}[*] Building... \){NC}"
make -j$(nproc)

# Strip + копирование
if [ -f libReVrax.so ]; then
    STRIP_BIN=$(find "$NDK" -name "llvm-strip" -type f 2>/dev/null | head -1)
    [ -x "$STRIP_BIN" ] && "$STRIP_BIN" --strip-all libReVrax.so
    
    mkdir -p ../../libs/arm64-v8a
    cp -f libReVrax.so ../../libs/arm64-v8a/
    echo -e "\( {GREEN}[+] Готово: libs/arm64-v8a/libReVrax.so \){NC}"
else
    echo -e "\( {RED}[!] libReVrax.so не собрался \){NC}"
    exit 1
fi

cd ../..
echo -e "${GREEN}=========================================="
echo "  Native library built successfully"
echo "==========================================${NC}"
