#!/bin/bash
# ReVrax v2.0 - Termux Build Script (Full APK)
# Requires: termux + pkg install ndk-sysroot cmake make clang aapt apksigner

set -e

echo "=========================================="
echo "  ReVrax v2.0 - Termux APK Builder"
echo "  Standoff 2 v0.39.2 | Multi-Arch"
echo "=========================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Check dependencies
echo -e "${CYAN}[*] Checking dependencies...${NC}"
pkg update -y
pkg install -y cmake make clang ndk-sysroot git aapt apksigner zip unzip 2>/dev/null || true

# Setup paths
export ANDROID_NDK_HOME=$PREFIX
export PATH=$PATH:$PREFIX/bin
export CC=clang
export CXX=clang++
export AR=llvm-ar
export STRIP=llvm-strip

# Check ImGui
echo -e "${CYAN}[*] Checking ImGui...${NC}"
if [ ! -d "jni/imgui" ]; then
    echo -e "${YELLOW}[!] ImGui not found. Downloading...${NC}"
    git clone --depth 1 https://github.com/ocornut/imgui.git jni/imgui
fi

# Create build dir
mkdir -p build
cd build

# Configure with CMake
echo -e "${CYAN}[*] Configuring CMake...${NC}"
cmake .. \
    -DCMAKE_TOOLCHAIN_FILE=$PREFIX/share/ndk-build/cmake/android.toolchain.cmake \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM=android-29 \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_C_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector" \
    -DCMAKE_CXX_FLAGS="-O2 -fPIC -fvisibility=hidden -fno-stack-protector -fno-exceptions -fno-rtti" \
    -DANDROID_STL=c++_static

# Build native library
echo -e "${CYAN}[*] Building native library...${NC}"
make -j$(nproc)

# Strip
echo -e "${CYAN}[*] Stripping symbols...${NC}"
$STRIP --strip-all libReVrax.so

# Copy to libs
cp libReVrax.so ../libs/arm64-v8a/
echo -e "${GREEN}[+] Native library built: libs/arm64-v8a/libReVrax.so${NC}"

cd ..

# Build APK using aapt
echo -e "${CYAN}[*] Building APK...${NC}"

# Create temp dir
rm -rf temp_apk
mkdir -p temp_apk/lib/arm64-v8a
mkdir -p temp_apk/res

# Copy native lib
cp libs/arm64-v8a/libReVrax.so temp_apk/lib/arm64-v8a/

# Copy resources
cp -r res/* temp_apk/res/ 2>/dev/null || true
cp -r java temp_apk/ 2>/dev/null || true

# Create AndroidManifest.xml in temp
cp AndroidManifest.xml temp_apk/

# Compile resources
echo -e "${CYAN}[*] Compiling resources...${NC}"
aapt package -f -M AndroidManifest.xml -S res -I $PREFIX/share/aapt/android.jar -F temp_apk/res.apk 2>/dev/null || aapt package -f -M AndroidManifest.xml -S res -I /system/framework/framework-res.apk -F temp_apk/res.apk 2>/dev/null || echo -e "${YELLOW}[!] aapt resource compilation skipped${NC}"

# Alternative: use zip to create APK
echo -e "${CYAN}[*] Creating APK...${NC}"
cd temp_apk
zip -r ../ReVrax_v2.0_unsigned.apk . -x "*.git*" 2>/dev/null || true
cd ..

# Sign APK
echo -e "${CYAN}[*] Signing APK...${NC}"
if [ ! -f "revrax.keystore" ]; then
    keytool -genkey -v -keystore revrax.keystore -alias revrax -keyalg RSA -keysize 2048 -validity 10000 -storepass revrax123 -keypass revrax123 -dname "CN=ReVrax" 2>/dev/null || true
fi

apksigner sign --ks revrax.keystore --ks-pass pass:revrax123 --key-pass pass:revrax123 --out ReVrax_v2.0.apk ReVrax_v2.0_unsigned.apk 2>/dev/null || echo -e "${YELLOW}[!] APK signing skipped. Use: jarsigner -keystore revrax.keystore ReVrax_v2.0_unsigned.apk revrax${NC}"

# Cleanup
rm -rf temp_apk
rm -f ReVrax_v2.0_unsigned.apk

echo -e "${GREEN}=========================================="
echo -e "  BUILD COMPLETE!"
echo -e "  Output: ReVrax_v2.0.apk"
echo -e "==========================================${NC}"

# Alternative: ndk-build
echo -e "${CYAN}[*] Trying ndk-build for all architectures...${NC}"
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk -j$(nproc) 2>/dev/null || \
    echo -e "${YELLOW}[!] ndk-build not available${NC}"

echo -e "${GREEN}[+] Done!${NC}"
echo -e "${CYAN}Install: adb install ReVrax_v2.0.apk${NC}"
