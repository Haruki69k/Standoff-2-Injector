package com.revrax;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class FloatingService extends Service {
    private static final String TAG = "ReVrax";
    private WindowManager mWindowManager;
    private View mFloatingView;
    private SurfaceView mSurfaceView;
    private ImageView mIconView;
    private boolean mMenuVisible = false;

    static {
        System.loadLibrary("ReVrax");
    }

    public native void nativeStartRender(Surface surface);
    public native void nativeStopRender();
    public native void nativeToggleMenu();
    public native boolean nativeIsMenuVisible();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "FloatingService onCreate");
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        setupFloatingIcon();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "FloatingService onStartCommand");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "FloatingService onDestroy");
        nativeStopRender();
        if (mFloatingView != null) {
            mWindowManager.removeView(mFloatingView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void setupFloatingIcon() {
        // Create floating layout
        mFloatingView = LayoutInflater.from(this).inflate(R.layout.floating_layout, null);

        // Window parameters
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20;
        params.y = 100;

        // Get views
        mIconView = mFloatingView.findViewById(R.id.floating_icon);
        mSurfaceView = mFloatingView.findViewById(R.id.surface_view);

        // Setup icon click
        mIconView.setOnClickListener(v -> {
            toggleMenu();
        });

        // Setup drag
        mIconView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                        // Check if it was a click (small movement)
                        float dx = event.getRawX() - initialTouchX;
                        float dy = event.getRawY() - initialTouchY;
                        if (Math.abs(dx) < 10 && Math.abs(dy) < 10) {
                            v.performClick();
                        }
                        return true;
                }
                return false;
            }
        });

        // Setup surface
        mSurfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.i(TAG, "Surface created");
                nativeStartRender(holder.getSurface());
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                Log.i(TAG, "Surface changed: " + width + "x" + height);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                Log.i(TAG, "Surface destroyed");
                nativeStopRender();
            }
        });

        // Add to window
        mWindowManager.addView(mFloatingView, params);
    }

    private void toggleMenu() {
        nativeToggleMenu();
        mMenuVisible = nativeIsMenuVisible();

        if (mMenuVisible) {
            // Show surface view
            mSurfaceView.setVisibility(View.VISIBLE);
            // Expand window for menu
            WindowManager.LayoutParams params = (WindowManager.LayoutParams) mFloatingView.getLayoutParams();
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = WindowManager.LayoutParams.MATCH_PARENT;
            params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            mWindowManager.updateViewLayout(mFloatingView, params);
        } else {
            // Hide surface view
            mSurfaceView.setVisibility(View.GONE);
            // Collapse window
            WindowManager.LayoutParams params = (WindowManager.LayoutParams) mFloatingView.getLayoutParams();
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            mWindowManager.updateViewLayout(mFloatingView, params);
        }
    }
}
