package com.revrax;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "ReVrax";
    private static final int REQUEST_OVERLAY_PERMISSION = 1001;

    static {
        System.loadLibrary("ReVrax");
    }

    public native void nativeInit();
    public native void nativeShutdown();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "MainActivity onCreate");

        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                return;
            }
        }

        // Check root access
        if (!isDeviceRooted()) {
            Toast.makeText(this, "Root access required!", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Initialize native
        nativeInit();

        // Start floating service
        startService(new Intent(this, FloatingService.class));

        // Show toast
        Toast.makeText(this, "ReVrax v2.0 loaded!", Toast.LENGTH_SHORT).show();

        // Finish activity (keep running in background)
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    // Retry
                    recreate();
                } else {
                    Toast.makeText(this, "Overlay permission denied!", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        nativeShutdown();
    }

    private boolean isDeviceRooted() {
        // Check for root binaries
        String[] paths = {
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/su/bin/su", "/data/local/xbin/su", "/data/local/bin/su"
        };
        for (String path : paths) {
            if (new java.io.File(path).exists()) return true;
        }

        // Check for Magisk
        if (new java.io.File("/data/adb/magisk").exists()) return true;
        if (new java.io.File("/sbin/.magisk").exists()) return true;

        // Check for KernelSU
        if (new java.io.File("/data/adb/ksu").exists()) return true;
        if (new java.io.File("/data/adb/apd").exists()) return true;

        // Try executing su
        try {
            Runtime.getRuntime().exec("su -c echo test");
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
