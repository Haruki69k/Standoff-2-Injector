LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := ReVrax
LOCAL_SRC_FILES :=     main.cpp     utils/memory.cpp     hooks/hooks.cpp     menu/menu.cpp     anti_ban/anti_ban.cpp     renderer/vulkan_renderer.cpp     renderer/opengl_renderer.cpp     imgui/imgui.cpp     imgui/imgui_demo.cpp     imgui/imgui_draw.cpp     imgui/imgui_tables.cpp     imgui/imgui_widgets.cpp     imgui/backends/imgui_impl_android.cpp     imgui/backends/imgui_impl_opengl3.cpp     imgui/backends/imgui_impl_vulkan.cpp

LOCAL_C_INCLUDES :=     $(LOCAL_PATH)     $(LOCAL_PATH)/imgui     $(LOCAL_PATH)/imgui/backends     $(LOCAL_PATH)/renderer

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -ldl -lvulkan
LOCAL_CPPFLAGS := -std=c++17 -O2 -fPIC -fvisibility=hidden -fno-stack-protector -fno-exceptions -fno-rtti -DREVRAX_SILENT -DIMGUI_IMPL_VULKAN_NO_PROTOTYPES
LOCAL_CFLAGS := -O2 -fPIC -fvisibility=hidden -fno-stack-protector -DREVRAX_SILENT

include $(BUILD_SHARED_LIBRARY)
