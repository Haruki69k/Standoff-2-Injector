APP_ABI := armeabi-v7a arm64-v8a x86 x86_64
APP_PLATFORM := android-29
APP_STL := c++_static
APP_CPPFLAGS := -std=c++17 -O2 -fPIC -fvisibility=hidden -fno-stack-protector -fno-exceptions -fno-rtti -DREVRAX_SILENT
APP_CFLAGS := -O2 -fPIC -fvisibility=hidden -fno-stack-protector -DREVRAX_SILENT
APP_OPTIM := release
