#pragma once
#include "../utils/memory.h"
#include "../utils/logger.h"
#include <string>
#include <vector>

namespace ReVrax {
namespace AntiBan {

// ==================== ROOT & EMULATOR HIDING ====================
bool HideRoot();
bool HideEmulator();
bool HideXposed();
bool HideMagisk();
bool HideBusybox();
bool HideSuperSU();
bool HideTermux();
bool HideFrida();
bool HideGameGuardian();
bool HideLuckyPatcher();
bool HideMTManager();

// ==================== FILE SYSTEM SPOOFING ====================
bool SpoofProcMaps();
bool SpoofProcStatus();
bool SpoofProcTask();
bool SpoofProcFd();
bool SpoofProcEnviron();
bool SpoofBuildProps();
bool SpoofCpuInfo();
bool SpoofCmdline();
bool SpoofMounts();
bool SpoofStatus();
bool SpoofStat();
bool SpoofMapsFiltering();

// ==================== NETWORK SPOOFING ====================
bool SpoofIP(const char* fakeIP);
bool SpoofMAC(const char* fakeMAC);
bool SpoofDNS();
bool UseVPNProxy(const char* proxy);
bool SpoofNetworkInterfaces();
bool BlockNetworkDetection();

// ==================== DEVICE SPOOFING ====================
bool SpoofDeviceID(const char* newID);
bool SpoofAndroidID(const char* newID);
bool SpoofIMEI(const char* newIMEI);
bool SpoofIMSI(const char* newIMSI);
bool SpoofSIMSerial(const char* newSerial);
bool SpoofMACAddress(const char* newMAC);
bool SpoofBluetoothMAC(const char* newMAC);
bool SpoofHardwareID(const char* newHWID);
bool SpoofFingerprint(const char* newFP);
bool SpoofBrand(const char* newBrand);
bool SpoofModel(const char* newModel);
bool SpoofManufacturer(const char* newManufacturer);
bool SpoofBoard(const char* newBoard);
bool SpoofDevice(const char* newDevice);
bool SpoofProduct(const char* newProduct);
bool SpoofSerial(const char* newSerial);
bool SpoofBootloader(const char* newBootloader);
bool SpoofRadio(const char* newRadio);
bool SpoofGoogleAdvertisingID(const char* newID);
bool SpoofFirebaseID(const char* newID);
bool SpoofFacebookID(const char* newID);

// ==================== STANDOFF 2 SPECIFIC SPOOFING ====================
bool SpoofStandoffUUID(const char* newUUID);
bool SpoofStandoffDeviceToken(const char* newToken);
bool SpoofStandoffAccountID(const char* newID);
bool SpoofStandoffSessionID(const char* newID);
bool SpoofStandoffSignature(const char* newSig);
bool SpoofStandoffStats();
bool SpoofStandoffRank(int rank);
bool SpoofStandoffLevel(int level);
bool SpoofStandoffXP(int xp);
bool ResetStandoffBindings();
bool ClearStandoffCache();
bool ClearStandoffData();
bool ClearStandoffPrefs();
bool WipeStandoffTraces();

// ==================== BAN RESET / UNBAN ====================
bool ResetBan();
bool ClearBanFlags();
bool SpoofNewIdentity();
bool GenerateFreshDeviceProfile();
bool WipeGameTraces();
bool WipeAntiCheatLogs();
bool ClearGameCache();
bool ResetGameData();
bool UnlinkSocialAccounts();
bool ClearDeviceFingerprint();

// ==================== ANTI-REPORT / ANTI-KICK ====================
bool BlockReports();
bool BlockKicks();
bool BlockSpectate();
bool BlockVoteKick();
bool BlockServerRPC(const char* method);
bool BlockAntiCheatRPC();
bool BlockAnalytics();
bool BlockCrashReporting();

// ==================== STEALTH & EVASION ====================
bool DisableLogs();
bool HideOverlay();
bool HideFromTaskManager();
bool RandomizeProcessName();
bool AntiPtrace();
bool AntiDebug();
bool AntiMemScan();
bool AntiSigScan();
bool ObfuscateMemory();
bool RandomizeOffsets();
bool DelayExecution();
bool JitterTiming();
bool FakeSystemCalls();
bool BypassSELinux();
bool HideLibrary(const char* libName);
bool UnlinkLibrary(const char* libName);
bool SpoofLibraryName(const char* oldName, const char* newName);

// ==================== ANTI-DETECTION ====================
bool BypassAntiCheat();
bool BypassIntegrityCheck();
bool BypassSignatureVerify();
bool BypassHookDetection();
bool BypassMemoryScan();
bool BypassDebuggerDetection();
bool BypassEmulatorDetection();
bool BypassRootDetection();
bool BypassVPNDetection();
bool BypassProxyDetection();

// ==================== FULL PROTECTION ====================
bool InitializeAntiBan();
void ShutdownAntiBan();
void RunAntiBanLoop();
bool IsAntiBanActive();

} // namespace AntiBan
} // namespace ReVrax
