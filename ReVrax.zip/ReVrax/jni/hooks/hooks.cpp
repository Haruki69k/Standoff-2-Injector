#include "hooks.h"
#include <cmath>
#include <cstring>

namespace S2 {

CheatConfig g_Config;

// Original function pointers
void* o_PlayerController_Update = nullptr;
void* o_AimController_Update = nullptr;
void* o_GunController_Shoot = nullptr;
void* o_GunController_GetSpread = nullptr;
void* o_GunController_GetRecoil = nullptr;
void* o_GunController_GetFireRate = nullptr;
void* o_GunController_GetDamage = nullptr;
void* o_GunController_GetRange = nullptr;
void* o_GunController_Reload = nullptr;
void* o_DamageEffectController_Apply = nullptr;
void* o_PlayerHitbox_GetPosition = nullptr;
void* o_MovementController_Update = nullptr;
void* o_AntiCheatManager_Report = nullptr;
void* o_AntiCheatManager_Ban = nullptr;
void* o_AntiCheatManager_Kick = nullptr;
void* o_AntiCheatManager_CheckIntegrity = nullptr;
void* o_AntiCheatManager_ScanMemory = nullptr;
void* o_PhotonView_RPC = nullptr;
void* o_PhotonView_Send = nullptr;
void* o_Camera_WorldToScreenPoint = nullptr;
void* o_Camera_get_fieldOfView = nullptr;
void* o_Camera_set_fieldOfView = nullptr;
void* o_Transform_get_position = nullptr;
void* o_Transform_set_position = nullptr;
void* o_CharacterController_Move = nullptr;
void* o_CharacterController_get_isGrounded = nullptr;
void* o_Reports_SendReport = nullptr;
void* o_KickVote_Process = nullptr;
void* o_Spectate_Follow = nullptr;
void* o_RadarManager_Update = nullptr;
void* o_WeaponryController_SwitchWeapon = nullptr;
void* o_PlayerController_get_Health = nullptr;
void* o_PlayerController_set_Health = nullptr;
void* o_PlayerController_get_Armor = nullptr;
void* o_PlayerController_set_Armor = nullptr;
void* o_NetworkController_SendRPC = nullptr;
void* o_Animator_GetBoneTransform = nullptr;

// ==================== HELPER FUNCTIONS ====================

std::vector<void*> GetAllPlayers() {
    std::vector<void*> players;
    if (!PlayerManager::instance) {
        // Try to get instance
        if (PlayerManager::get_Instance) {
            PlayerManager::instance = PlayerManager::get_Instance();
        }
    }
    if (!PlayerManager::instance) return players;

    // Get HashSet<PlayerController> at offset 0x38
    void* hashSet = Mem::Read<void*>((uintptr_t)PlayerManager::instance + Offsets::PM_playerHashSet);
    if (!hashSet) return players;

    // HashSet iteration (simplified - real impl needs HashSet internal structure)
    // For now, use dictionary at 0x28
    void* dict = Mem::Read<void*>((uintptr_t)PlayerManager::instance + Offsets::PM_playerDict);
    if (!dict) return players;

    // Dictionary iteration would go here
    // Placeholder: scan memory for PlayerController instances

    return players;
}

void* GetLocalPlayer() {
    if (!PlayerManager::instance) {
        if (PlayerManager::get_Instance) {
            PlayerManager::instance = PlayerManager::get_Instance();
        }
    }
    if (!PlayerManager::instance) return nullptr;

    // Try offset 0x68 first
    void* local = Mem::Read<void*>((uintptr_t)PlayerManager::instance + Offsets::PM_localPlayer1);
    if (local) {
        void* pv = PlayerController::get_PhotonView ? PlayerController::get_PhotonView(local) : nullptr;
        if (pv && PhotonView::get_isMine) {
            if (PhotonView::get_isMine(pv)) return local;
        }
    }

    // Try offset 0x70
    local = Mem::Read<void*>((uintptr_t)PlayerManager::instance + Offsets::PM_localPlayer2);
    if (local) {
        void* pv = PlayerController::get_PhotonView ? PlayerController::get_PhotonView(local) : nullptr;
        if (pv && PhotonView::get_isMine) {
            if (PhotonView::get_isMine(pv)) return local;
        }
    }

    return nullptr;
}

Team GetPlayerTeam(void* player) {
    if (!player) return Team::None;
    if (PlayerController::get_Team) {
        return PlayerController::get_Team(player);
    }
    // Direct memory read fallback
    return (Team)Mem::Read<int32_t>((uintptr_t)player + Offsets::PC_team);
}

int GetPlayerHealth(void* player) {
    if (!player) return 0;
    if (PlayerController::get_Health) {
        return PlayerController::get_Health(player);
    }
    return Mem::Read<int32_t>((uintptr_t)player + Offsets::PC_health);
}

int GetPlayerArmor(void* player) {
    if (!player) return 0;
    if (PlayerController::get_Armor) {
        return PlayerController::get_Armor(player);
    }
    return Mem::Read<int32_t>((uintptr_t)player + Offsets::PC_armor);
}

bool IsPlayerDead(void* player) {
    if (!player) return true;
    if (PlayerController::get_IsDead) {
        return PlayerController::get_IsDead(player);
    }
    return GetPlayerHealth(player) <= 0;
}

bool IsPlayerLocal(void* player) {
    if (!player) return false;
    if (PlayerController::get_IsLocal) {
        return PlayerController::get_IsLocal(player);
    }
    void* pv = PlayerController::get_PhotonView ? PlayerController::get_PhotonView(player) : nullptr;
    if (pv && PhotonView::get_isMine) {
        return PhotonView::get_isMine(pv);
    }
    return player == GetLocalPlayer();
}

Vector3 GetPlayerPosition(void* player) {
    if (!player) return Vector3();

    // Try CharacterController
    void* cc = PlayerController::get_CharacterController ? PlayerController::get_CharacterController(player) : nullptr;
    if (!cc) {
        cc = Mem::Read<void*>((uintptr_t)player + Offsets::PC_characterController);
    }
    if (cc && Component::get_transform) {
        void* trans = Component::get_transform(cc);
        if (trans && Transform::get_position) {
            // Transform.get_position returns by value in IL2CPP
            // Need to call properly via resolved function
            // Placeholder: return cached or computed position
        }
    }

    // Fallback: read transform position directly
    void* trans = Mem::Read<void*>((uintptr_t)player + Offsets::PC_characterController);
    if (trans) {
        void* transform = Mem::Read<void*>((uintptr_t)trans + 0x28); // Component->transform
        if (transform) {
            return Mem::Read<Vector3>((uintptr_t)transform + Offsets::TR_position);
        }
    }

    return Vector3();
}

Vector3 GetPlayerHeadPosition(void* player) {
    if (!player) return Vector3();

    // Try PlayerCharacterView -> BipedMap -> Head
    void* pcv = PlayerController::get_PlayerCharacterView ? PlayerController::get_PlayerCharacterView(player) : nullptr;
    if (!pcv) {
        pcv = Mem::Read<void*>((uintptr_t)player + Offsets::PC_characterView1);
    }
    if (pcv && PlayerCharacterView::get_bipedMap) {
        BipedMap* bm = PlayerCharacterView::get_bipedMap(pcv);
        if (bm && bm->Head) {
            void* headTrans = Component::get_transform ? Component::get_transform(bm->Head) : nullptr;
            if (headTrans) {
                return Mem::Read<Vector3>((uintptr_t)headTrans + Offsets::TR_position);
            }
        }
    }

    // Fallback: position + height offset
    Vector3 pos = GetPlayerPosition(player);
    pos.y += 1.7f; // Approximate head height
    return pos;
}

Vector3 GetPlayerBonePosition(void* player, Bip bone) {
    if (!player) return Vector3();

    void* pcv = PlayerController::get_PlayerCharacterView ? PlayerController::get_PlayerCharacterView(player) : nullptr;
    if (!pcv) {
        pcv = Mem::Read<void*>((uintptr_t)player + Offsets::PC_characterView1);
    }
    if (!pcv) return GetPlayerPosition(player);

    BipedMap* bm = PlayerCharacterView::get_bipedMap ? PlayerCharacterView::get_bipedMap(pcv) : nullptr;
    if (!bm) return GetPlayerPosition(player);

    void* boneTransform = nullptr;
    switch (bone) {
        case Bip::Head: boneTransform = bm->Head; break;
        case Bip::Neck: boneTransform = bm->Neck; break;
        case Bip::Spine: boneTransform = bm->Spine; break;
        case Bip::Spine1: boneTransform = bm->Spine1; break;
        case Bip::Spine2: boneTransform = bm->Spine2; break;
        case Bip::LeftShoulder: boneTransform = bm->LeftShoulder; break;
        case Bip::LeftUpperarm: boneTransform = bm->LeftUpperarm; break;
        case Bip::LeftForearm: boneTransform = bm->LeftForearm; break;
        case Bip::LeftHand: boneTransform = bm->LeftHand; break;
        case Bip::RightShoulder: boneTransform = bm->RightShoulder; break;
        case Bip::RightUpperarm: boneTransform = bm->RightUpperarm; break;
        case Bip::RightForearm: boneTransform = bm->RightForearm; break;
        case Bip::RightHand: boneTransform = bm->RightHand; break;
        case Bip::Hip: boneTransform = bm->Hip; break;
        case Bip::LeftUpLeg: boneTransform = bm->LeftUpLeg; break;
        case Bip::LeftLeg: boneTransform = bm->LeftLeg; break;
        case Bip::LeftFoot: boneTransform = bm->LeftFoot; break;
        case Bip::RightUpLeg: boneTransform = bm->RightUpLeg; break;
        case Bip::RightLeg: boneTransform = bm->RightLeg; break;
        case Bip::RightFoot: boneTransform = bm->RightFoot; break;
        default: boneTransform = bm->Spine; break;
    }

    if (boneTransform && Component::get_transform) {
        void* trans = Component::get_transform(boneTransform);
        if (trans) {
            return Mem::Read<Vector3>((uintptr_t)trans + Offsets::TR_position);
        }
    }

    return GetPlayerPosition(player);
}

const char* GetPlayerName(void* player) {
    if (!player) return "Unknown";

    void* pv = PlayerController::get_PhotonView ? PlayerController::get_PhotonView(player) : nullptr;
    if (!pv) pv = Mem::Read<void*>((uintptr_t)player + Offsets::PC_photonView);
    if (!pv) return "Unknown";

    void* owner = PhotonView::get_owner ? PhotonView::get_owner(pv) : nullptr;
    if (!owner) return "Unknown";

    if (PhotonPlayer::get_NickName) {
        Il2CppString* name = PhotonPlayer::get_NickName(owner);
        if (name) {
            static char nameBuf[256];
            std::string s = Mem::ReadIl2CppString(name);
            strncpy(nameBuf, s.c_str(), sizeof(nameBuf)-1);
            return nameBuf;
        }
    }

    return "Player";
}

void* GetPlayerWeapon(void* player) {
    if (!player) return nullptr;

    void* wc = PlayerController::get_WeaponryController ? PlayerController::get_WeaponryController(player) : nullptr;
    if (!wc) wc = Mem::Read<void*>((uintptr_t)player + Offsets::PC_weaponryController);
    if (!wc) return nullptr;

    if (WeaponryController::get_CurrentWeapon) {
        return WeaponryController::get_CurrentWeapon(wc);
    }

    return Mem::Read<void*>((uintptr_t)wc + Offsets::WC_currentWeapon);
}

int GetPlayerWeaponId(void* player) {
    void* weapon = GetPlayerWeapon(player);
    if (!weapon) return -1;
    // Weapon ID would be in GunParameters or similar
    return 0; // Placeholder
}

float GetDistanceToPlayer(void* player) {
    void* local = GetLocalPlayer();
    if (!local || !player) return 999999.0f;

    Vector3 localPos = GetPlayerPosition(local);
    Vector3 playerPos = GetPlayerPosition(player);

    float dx = localPos.x - playerPos.x;
    float dy = localPos.y - playerPos.y;
    float dz = localPos.z - playerPos.z;

    return sqrtf(dx*dx + dy*dy + dz*dz);
}

bool IsPlayerVisible(void* player) {
    if (!player) return false;

    void* local = GetLocalPlayer();
    if (!local) return false;
    if (player == local) return true;

    Vector3 localHead = GetPlayerHeadPosition(local);
    Vector3 targetHead = GetPlayerHeadPosition(player);

    // Raycast from local to target
    Vector3 dir = targetHead - localHead;
    float dist = dir.Length();
    if (dist < 0.1f) return true;

    dir = dir * (1.0f / dist);

    Ray ray;
    ray.origin = localHead;
    ray.direction = dir;

    RaycastHit hit;
    if (Physics::Raycast && Physics::Raycast(ray, &hit, dist)) {
        // Check if hit target
        // Would need to compare hit collider with target's collider
        return false; // Something blocked
    }

    return true; // No obstruction
}

bool IsPlayerVisibleBone(void* player, Bip bone) {
    if (!player) return false;

    void* local = GetLocalPlayer();
    if (!local) return false;

    Vector3 localHead = GetPlayerHeadPosition(local);
    Vector3 targetBone = GetPlayerBonePosition(player, bone);

    Vector3 dir = targetBone - localHead;
    float dist = dir.Length();
    if (dist < 0.1f) return true;

    dir = dir * (1.0f / dist);

    Ray ray;
    ray.origin = localHead;
    ray.direction = dir;

    RaycastHit hit;
    if (Physics::Raycast && Physics::Raycast(ray, &hit, dist)) {
        return false;
    }

    return true;
}

bool IsTeammate(void* player) {
    if (!player) return false;
    void* local = GetLocalPlayer();
    if (!local) return false;
    if (player == local) return true;

    Team localTeam = GetPlayerTeam(local);
    Team playerTeam = GetPlayerTeam(player);

    return localTeam != Team::None && localTeam == playerTeam;
}

void* GetClosestPlayer(float maxDist, bool visibleOnly, bool teamCheck) {
    std::vector<void*> players = GetAllPlayers();
    void* closest = nullptr;
    float closestDist = maxDist;

    void* local = GetLocalPlayer();
    if (!local) return nullptr;

    for (void* player : players) {
        if (!player || player == local) continue;
        if (IsPlayerDead(player)) continue;
        if (teamCheck && IsTeammate(player)) continue;
        if (visibleOnly && !IsPlayerVisible(player)) continue;

        float dist = GetDistanceToPlayer(player);
        if (dist < closestDist) {
            closestDist = dist;
            closest = player;
        }
    }

    return closest;
}

void* GetClosestPlayerToCrosshair(float fov, bool visibleOnly, bool teamCheck) {
    std::vector<void*> players = GetAllPlayers();
    void* closest = nullptr;
    float closestAngle = fov;

    void* local = GetLocalPlayer();
    if (!local) return nullptr;

    Vector3 localHead = GetPlayerHeadPosition(local);
    Vector3 localForward = GetCameraForward();

    for (void* player : players) {
        if (!player || player == local) continue;
        if (IsPlayerDead(player)) continue;
        if (teamCheck && IsTeammate(player)) continue;
        if (visibleOnly && !IsPlayerVisible(player)) continue;

        Vector3 targetHead = GetPlayerHeadPosition(player);
        Vector3 dir = targetHead - localHead;
        dir = dir * (1.0f / dir.Length());

        float dot = localForward.x * dir.x + localForward.y * dir.y + localForward.z * dir.z;
        float angle = acosf(fmaxf(-1.0f, fminf(1.0f, dot))) * (180.0f / 3.14159265f);

        if (angle < closestAngle) {
            closestAngle = angle;
            closest = player;
        }
    }

    return closest;
}

Vector3 WorldToScreen(Vector3 worldPos) {
    Vector3 screenPos;

    void* mainCam = Camera::get_main ? Camera::get_main() : nullptr;
    if (!mainCam) return screenPos;

    if (Camera::WorldToScreenPoint) {
        // Returns Vector3 by value in IL2CPP
        // screenPos = Camera::WorldToScreenPoint(mainCam, worldPos, 0);
        // Placeholder implementation
    }

    // Manual W2S calculation
    void* camTrans = Camera::get_transform ? Camera::get_transform(mainCam) : nullptr;
    if (!camTrans) return screenPos;

    Vector3 camPos = Mem::Read<Vector3>((uintptr_t)camTrans + Offsets::TR_position);
    // ... matrix calculation would go here

    return screenPos;
}

bool IsOnScreen(Vector3 screenPos) {
    // Assuming screenPos is already in screen coordinates
    return screenPos.z > 0 && screenPos.x > 0 && screenPos.y > 0;
}

float GetCrosshairDistance(Vector3 screenPos) {
    // Screen center
    float centerX = 0; // Would need actual screen dimensions
    float centerY = 0;
    float dx = screenPos.x - centerX;
    float dy = screenPos.y - centerY;
    return sqrtf(dx*dx + dy*dy);
}

void* GetMainCamera() {
    if (Camera::get_main) return Camera::get_main();
    return nullptr;
}

Vector3 GetCameraPosition() {
    void* cam = GetMainCamera();
    if (!cam) return Vector3();

    void* trans = Camera::get_transform ? Camera::get_transform(cam) : nullptr;
    if (!trans) return Vector3();

    return Mem::Read<Vector3>((uintptr_t)trans + Offsets::TR_position);
}

Vector3 GetCameraForward() {
    void* cam = GetMainCamera();
    if (!cam) return Vector3(0, 0, 1);

    void* trans = Camera::get_transform ? Camera::get_transform(cam) : nullptr;
    if (!trans) return Vector3(0, 0, 1);

    if (Transform::get_forward) {
        // return Transform::get_forward(trans);
    }

    // Fallback: calculate from rotation
    Quaternion rot = Mem::Read<Quaternion>((uintptr_t)trans + Offsets::TR_rotation);
    Vector3 forward;
    forward.x = 2.0f * (rot.x * rot.z + rot.w * rot.y);
    forward.y = 2.0f * (rot.y * rot.z - rot.w * rot.x);
    forward.z = 1.0f - 2.0f * (rot.x * rot.x + rot.y * rot.y);
    return forward;
}

void SetCameraFOV(float fov) {
    void* cam = GetMainCamera();
    if (!cam) return;
    if (Camera::set_fieldOfView) {
        Camera::set_fieldOfView(cam, fov);
    }
}

float GetCameraFOV() {
    void* cam = GetMainCamera();
    if (!cam) return 60.0f;
    if (Camera::get_fieldOfView) {
        return Camera::get_fieldOfView(cam);
    }
    return 60.0f;
}

void* GetAimController() {
    void* local = GetLocalPlayer();
    if (!local) return nullptr;
    if (PlayerController::get_AimController) {
        return PlayerController::get_AimController(local);
    }
    return Mem::Read<void*>((uintptr_t)local + Offsets::PC_aimController);
}

void* GetWeaponryController() {
    void* local = GetLocalPlayer();
    if (!local) return nullptr;
    if (PlayerController::get_WeaponryController) {
        return PlayerController::get_WeaponryController(local);
    }
    return Mem::Read<void*>((uintptr_t)local + Offsets::PC_weaponryController);
}

void* GetMovementController() {
    void* local = GetLocalPlayer();
    if (!local) return nullptr;
    if (PlayerController::get_MovementController) {
        return PlayerController::get_MovementController(local);
    }
    return Mem::Read<void*>((uintptr_t)local + Offsets::PC_movementController);
}

void* GetCurrentGun() {
    void* wc = GetWeaponryController();
    if (!wc) return nullptr;
    if (WeaponryController::get_CurrentWeapon) {
        return WeaponryController::get_CurrentWeapon(wc);
    }
    return Mem::Read<void*>((uintptr_t)wc + Offsets::WC_currentWeapon);
}

void* GetGunParameters(void* gun) {
    if (!gun) return nullptr;
    if (GunController::get_GunParameters) {
        return GunController::get_GunParameters(gun);
    }
    return Mem::Read<void*>((uintptr_t)gun + Offsets::GC_gunParameters);
}


// ==================== AIMBOT FUNCTIONS ====================

Vector3 GetAimTargetPosition(void* player, int bone) {
    if (!player) return Vector3();

    Bip targetBone = Bip::Head;
    switch (bone) {
        case 0: targetBone = Bip::Head; break;
        case 1: targetBone = Bip::Neck; break;
        case 2: targetBone = Bip::Spine; break;
        case 3: targetBone = Bip::Hip; break;
        default: targetBone = Bip::Head; break;
    }

    Vector3 pos = GetPlayerBonePosition(player, targetBone);

    // Prediction
    if (g_Config.Aimbot.prediction) {
        void* mc = GetMovementController();
        if (mc) {
            Vector3 vel = CharacterController::get_velocity ? 
                CharacterController::get_velocity(Mem::Read<void*>((uintptr_t)mc + Offsets::MC_characterController)) : Vector3();
            pos = pos + (vel * g_Config.Aimbot.predictionFactor);
        }
    }

    return pos;
}

void AimAt(Vector3 target) {
    void* ac = GetAimController();
    if (!ac) return;

    void* camTrans = AimController::get_CamTransform ? AimController::get_CamTransform(ac) : nullptr;
    if (!camTrans) return;

    Vector3 camPos = Mem::Read<Vector3>((uintptr_t)camTrans + Offsets::TR_position);

    Vector3 dir = target - camPos;
    float dist = dir.Length();
    if (dist < 0.001f) return;

    dir = dir * (1.0f / dist);

    // Convert direction to rotation
    float yaw = atan2f(dir.x, dir.z) * (180.0f / 3.14159265f);
    float pitch = -asinf(dir.y) * (180.0f / 3.14159265f);

    // Apply to aim controller
    if (AimController::set_sensitivityX && AimController::set_sensitivityY) {
        // Modify sensitivity temporarily for aim
        float oldSensX = AimController::get_sensitivityX ? AimController::get_sensitivityX(ac) : 1.0f;
        float oldSensY = AimController::get_sensitivityY ? AimController::get_sensitivityY(ac) : 1.0f;

        // Set new rotation via transform
        Quaternion rot;
        float cy = cosf(yaw * 0.5f * 3.14159265f / 180.0f);
        float sy = sinf(yaw * 0.5f * 3.14159265f / 180.0f);
        float cp = cosf(pitch * 0.5f * 3.14159265f / 180.0f);
        float sp = sinf(pitch * 0.5f * 3.14159265f / 180.0f);

        rot.w = cy * cp;
        rot.x = cy * sp;
        rot.y = sy * cp;
        rot.z = sy * sp;

        if (Transform::set_localRotation) {
            Transform::set_localRotation(camTrans, rot);
        }
    }
}

void SmoothAim(Vector3 target, float smooth) {
    void* ac = GetAimController();
    if (!ac) return;

    void* camTrans = AimController::get_CamTransform ? AimController::get_CamTransform(ac) : nullptr;
    if (!camTrans) return;

    Vector3 camPos = Mem::Read<Vector3>((uintptr_t)camTrans + Offsets::TR_position);

    Vector3 targetDir = target - camPos;
    float dist = targetDir.Length();
    if (dist < 0.001f) return;
    targetDir = targetDir * (1.0f / dist);

    // Get current forward
    Vector3 currentForward = GetCameraForward();

    // Smooth interpolation
    Vector3 newDir;
    newDir.x = currentForward.x + (targetDir.x - currentForward.x) / smooth;
    newDir.y = currentForward.y + (targetDir.y - currentForward.y) / smooth;
    newDir.z = currentForward.z + (targetDir.z - currentForward.z) / smooth;

    float len = newDir.Length();
    if (len > 0.001f) newDir = newDir * (1.0f / len);

    // Convert to rotation and apply
    float yaw = atan2f(newDir.x, newDir.z) * (180.0f / 3.14159265f);
    float pitch = -asinf(newDir.y) * (180.0f / 3.14159265f);

    Quaternion rot;
    float cy = cosf(yaw * 0.5f * 3.14159265f / 180.0f);
    float sy = sinf(yaw * 0.5f * 3.14159265f / 180.0f);
    float cp = cosf(pitch * 0.5f * 3.14159265f / 180.0f);
    float sp = sinf(pitch * 0.5f * 3.14159265f / 180.0f);

    rot.w = cy * cp;
    rot.x = cy * sp;
    rot.y = sy * cp;
    rot.z = sy * sp;

    if (Transform::set_localRotation) {
        Transform::set_localRotation(camTrans, rot);
    }
}

float CalculateFOV(Vector3 target) {
    Vector3 camPos = GetCameraPosition();
    Vector3 camForward = GetCameraForward();

    Vector3 dir = target - camPos;
    float dist = dir.Length();
    if (dist < 0.001f) return 999.0f;
    dir = dir * (1.0f / dist);

    float dot = camForward.x * dir.x + camForward.y * dir.y + camForward.z * dir.z;
    return acosf(fmaxf(-1.0f, fminf(1.0f, dot))) * (180.0f / 3.14159265f);
}

bool IsTargetValid(void* player) {
    if (!player) return false;
    if (IsPlayerDead(player)) return false;
    if (IsPlayerLocal(player)) return false;
    if (g_Config.Aimbot.teamCheck && IsTeammate(player)) return false;
    if (g_Config.Aimbot.visibleCheck && !IsPlayerVisible(player)) return false;

    float dist = GetDistanceToPlayer(player);
    if (dist > g_Config.Aimbot.maxDistance) return false;

    return true;
}

void RunAimbot() {
    if (!g_Config.Aimbot.enabled || !g_Config.Aimbot.aimLock) return;

    void* target = GetClosestPlayerToCrosshair(g_Config.Aimbot.fov, 
        g_Config.Aimbot.visibleCheck, g_Config.Aimbot.teamCheck);

    if (!target || !IsTargetValid(target)) return;

    Vector3 targetPos = GetAimTargetPosition(target, g_Config.Aimbot.bone);

    if (g_Config.Aimbot.smooth > 1.0f) {
        SmoothAim(targetPos, g_Config.Aimbot.smooth);
    } else {
        AimAt(targetPos);
    }

    if (g_Config.Aimbot.autoShoot) {
        void* gun = GetCurrentGun();
        if (gun && GunController::Shoot) {
            GunController::Shoot(gun);
        }
    }
}

void RunSilentAim() {
    if (!g_Config.Aimbot.enabled || !g_Config.Aimbot.silentAim) return;
    // Silent aim modifies bullet trajectory server-side
    // Would need to hook bullet spawn/trajectory functions
}

void RunRageAim() {
    if (!g_Config.Aimbot.enabled || !g_Config.Aimbot.rageAim) return;

    void* target = GetClosestPlayer(g_Config.Aimbot.maxDistance,
        g_Config.Aimbot.visibleCheck, g_Config.Aimbot.teamCheck);

    if (!target || !IsTargetValid(target)) return;

    Vector3 targetPos = GetAimTargetPosition(target, g_Config.Aimbot.bone);
    AimAt(targetPos);

    // Instant shoot
    void* gun = GetCurrentGun();
    if (gun && GunController::Shoot) {
        GunController::Shoot(gun);
    }
}

void RunTriggerBot() {
    if (!g_Config.Aimbot.enabled || !g_Config.Aimbot.triggerBot) return;

    void* target = GetClosestPlayerToCrosshair(5.0f, true, true);
    if (!target || !IsTargetValid(target)) return;

    // Check if crosshair is on target
    Vector3 targetHead = GetPlayerHeadPosition(target);
    Vector3 screenPos = WorldToScreen(targetHead);

    if (IsOnScreen(screenPos) && GetCrosshairDistance(screenPos) < 20.0f) {
        void* gun = GetCurrentGun();
        if (gun && GunController::Shoot) {
            GunController::Shoot(gun);
        }
    }
}

void RunMagnetAim() {
    if (!g_Config.Aimbot.enabled || !g_Config.Aimbot.magnetAim) return;

    void* target = GetClosestPlayerToCrosshair(g_Config.Aimbot.fov * 2.0f,
        g_Config.Aimbot.visibleCheck, g_Config.Aimbot.teamCheck);

    if (!target || !IsTargetValid(target)) return;

    Vector3 targetPos = GetAimTargetPosition(target, g_Config.Aimbot.bone);
    SmoothAim(targetPos, g_Config.Aimbot.magnetStrength * 10.0f);
}

// ==================== ESP FUNCTIONS ====================

void DrawESP() {
    if (!g_Config.ESP.enabled) return;

    std::vector<void*> players = GetAllPlayers();
    void* local = GetLocalPlayer();
    if (!local) return;

    for (void* player : players) {
        if (!player || player == local) continue;
        if (IsPlayerDead(player)) continue;
        if (g_Config.ESP.teamCheck && IsTeammate(player)) continue;

        float dist = GetDistanceToPlayer(player);
        if (dist > g_Config.ESP.maxDistance) continue;

        bool visible = IsPlayerVisible(player);
        if (g_Config.ESP.visibleOnly && !visible) continue;

        Color color = visible ? g_Config.ESP.visibleColor : 
            (IsTeammate(player) ? g_Config.ESP.teamColor : g_Config.ESP.enemyColor);

        if (g_Config.ESP.box) DrawBox(player, color);
        if (g_Config.ESP.skeleton) DrawSkeleton(player, color);
        if (g_Config.ESP.healthBar) DrawHealthBar(player);
        if (g_Config.ESP.armorBar) DrawArmorBar(player);
        if (g_Config.ESP.name) DrawName(player, color);
        if (g_Config.ESP.distance) DrawDistance(player);
        if (g_Config.ESP.weapon) DrawWeapon(player);
        if (g_Config.ESP.snaplines) DrawSnapline(player, color);
        if (g_Config.ESP.headDot) DrawHeadDot(player, color);
        if (g_Config.ESP.tracers) DrawTracers(player);
        if (g_Config.ESP.offScreenArrows) DrawOffScreenArrow(player, color);
    }
}

void DrawBox(void* player, Color color) {
    // Would use ImGui draw list
    // Placeholder for actual implementation
    Vector3 pos = GetPlayerPosition(player);
    Vector3 head = GetPlayerHeadPosition(player);
    Vector3 screenPos = WorldToScreen(pos);
    Vector3 screenHead = WorldToScreen(head);

    if (!IsOnScreen(screenPos) && !IsOnScreen(screenHead)) return;

    float height = fabsf(screenPos.y - screenHead.y);
    float width = height * 0.4f;

    // Draw box corners using ImGui
    // ImGui::GetForegroundDrawList()->AddRect(...)
}

void DrawSkeleton(void* player, Color color) {
    if (!player) return;

    Bip bones[] = {
        Bip::Head, Bip::Neck, Bip::Spine, Bip::Spine1, Bip::Spine2,
        Bip::LeftShoulder, Bip::LeftUpperarm, Bip::LeftForearm, Bip::LeftHand,
        Bip::RightShoulder, Bip::RightUpperarm, Bip::RightForearm, Bip::RightHand,
        Bip::Hip, Bip::LeftUpLeg, Bip::LeftLeg, Bip::LeftFoot,
        Bip::RightUpLeg, Bip::RightLeg, Bip::RightFoot
    };

    // Draw lines between connected bones
    // Would use ImGui draw list
}

void DrawHealthBar(void* player) {
    int health = GetPlayerHealth(player);
    int maxHealth = 100; // Would get from class

    Vector3 pos = GetPlayerPosition(player);
    Vector3 head = GetPlayerHeadPosition(player);
    Vector3 screenPos = WorldToScreen(pos);
    Vector3 screenHead = WorldToScreen(head);

    if (!IsOnScreen(screenPos)) return;

    float height = fabsf(screenPos.y - screenHead.y);
    float barWidth = 3.0f;
    float barHeight = height;
    float healthPct = (float)health / (float)maxHealth;

    Color healthColor = health > 60 ? Color(0,1,0,1) : (health > 30 ? Color(1,1,0,1) : Color(1,0,0,1));

    // Draw bar background and fill
    // ImGui::GetForegroundDrawList()->AddRectFilled(...)
}

void DrawArmorBar(void* player) {
    int armor = GetPlayerArmor(player);
    if (armor <= 0) return;

    // Similar to health bar but offset
}

void DrawName(void* player, Color color) {
    const char* name = GetPlayerName(player);
    Vector3 head = GetPlayerHeadPosition(player);
    Vector3 screenHead = WorldToScreen(head);

    if (!IsOnScreen(screenHead)) return;

    // Draw text above head
    // ImGui::GetForegroundDrawList()->AddText(...)
}

void DrawDistance(void* player) {
    float dist = GetDistanceToPlayer(player);
    Vector3 pos = GetPlayerPosition(player);
    Vector3 screenPos = WorldToScreen(pos);

    if (!IsOnScreen(screenPos)) return;

    // Draw distance text
    // ImGui::GetForegroundDrawList()->AddText(...)
}

void DrawWeapon(void* player) {
    void* weapon = GetPlayerWeapon(player);
    if (!weapon) return;

    Vector3 pos = GetPlayerPosition(player);
    Vector3 screenPos = WorldToScreen(pos);

    if (!IsOnScreen(screenPos)) return;

    // Draw weapon name
}

void DrawSnapline(void* player, Color color) {
    Vector3 pos = GetPlayerPosition(player);
    Vector3 screenPos = WorldToScreen(pos);

    if (!IsOnScreen(screenPos)) return;

    // Draw line from screen bottom to player
    // ImGui::GetForegroundDrawList()->AddLine(...)
}

void DrawHeadDot(void* player, Color color) {
    Vector3 head = GetPlayerHeadPosition(player);
    Vector3 screenHead = WorldToScreen(head);

    if (!IsOnScreen(screenHead)) return;

    // Draw circle at head position
    // ImGui::GetForegroundDrawList()->AddCircle(...)
}

void DrawTracers(void* player) {
    void* local = GetLocalPlayer();
    if (!local) return;

    Vector3 localHead = GetPlayerHeadPosition(local);
    Vector3 targetHead = GetPlayerHeadPosition(player);
    Vector3 screenLocal = WorldToScreen(localHead);
    Vector3 screenTarget = WorldToScreen(targetHead);

    if (!IsOnScreen(screenTarget)) return;

    // Draw line from local to target
}

void DrawOffScreenArrow(void* player, Color color) {
    Vector3 pos = GetPlayerPosition(player);
    Vector3 screenPos = WorldToScreen(pos);

    if (IsOnScreen(screenPos)) return;

    // Calculate arrow direction and draw at screen edge
    // ImGui::GetForegroundDrawList()->AddTriangleFilled(...)
}

// ==================== RADAR FUNCTIONS ====================

void DrawRadar() {
    if (!g_Config.Radar.enabled) return;

    // Draw radar background
    // ImGui::GetForegroundDrawList()->AddRectFilled(...)

    void* local = GetLocalPlayer();
    if (!local) return;

    Vector3 localPos = GetPlayerPosition(local);
    float localYaw = 0.0f; // Would get from rotation

    // Draw local player at center
    Vector2 center(g_Config.Radar.posX + g_Config.Radar.size / 2.0f,
                   g_Config.Radar.posY + g_Config.Radar.size / 2.0f);

    if (g_Config.Radar.showLocal) {
        DrawRadarLocalPlayer(center);
    }

    // Draw other players
    std::vector<void*> players = GetAllPlayers();
    for (void* player : players) {
        if (!player || player == local) continue;
        if (IsPlayerDead(player)) continue;

        bool isEnemy = !IsTeammate(player);
        if (!isEnemy && !g_Config.Radar.showTeammates) continue;
        if (isEnemy && !g_Config.Radar.showEnemies) continue;

        Vector3 playerPos = GetPlayerPosition(player);
        Vector3 relative = playerPos - localPos;

        // Rotate relative to local player yaw
        float cosY = cosf(-localYaw);
        float sinY = sinf(-localYaw);
        Vector2 rotated;
        rotated.x = relative.x * cosY - relative.z * sinY;
        rotated.y = relative.x * sinY + relative.z * cosY;

        // Scale to radar
        float scale = g_Config.Radar.scale * g_Config.Radar.zoom;
        Vector2 radarPos;
        radarPos.x = center.x + rotated.x * scale;
        radarPos.y = center.y - rotated.y * scale;

        Color color = isEnemy ? Color(1,0,0,1) : Color(0,1,0,1);
        DrawRadarPlayer(player, radarPos, color);
    }
}

void UpdateRadar() {
    // Update radar data
}

void DrawRadarPlayer(void* player, Vector2 pos, Color color) {
    // Draw player dot on radar
    // ImGui::GetForegroundDrawList()->AddCircleFilled(...)
}

void DrawRadarLocalPlayer(Vector2 pos) {
    // Draw local player indicator (triangle pointing forward)
    // ImGui::GetForegroundDrawList()->AddTriangleFilled(...)
}

void ShareRadarLink() {
    if (!g_Config.Radar.shareLink) return;

    // Start local HTTP server for radar sharing
    // Would need to implement mini HTTP server
    strncpy(g_Config.Radar.shareURL, "http://192.168.1.X:8080/radar", sizeof(g_Config.Radar.shareURL)-1);
}

// ==================== MOVEMENT FUNCTIONS ====================

void RunSpeedHack() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.speedHack) return;

    void* mc = GetMovementController();
    if (!mc) return;

    void* cc = Mem::Read<void*>((uintptr_t)mc + Offsets::MC_characterController);
    if (!cc) return;

    // Modify movement speed
    // Would hook CharacterController.Move or modify speed field
}

void RunFly() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.fly) return;

    void* mc = GetMovementController();
    if (!mc) return;

    void* cc = Mem::Read<void*>((uintptr_t)mc + Offsets::MC_characterController);
    if (!cc) return;

    // Set velocity upward
    Vector3 vel = Mem::Read<Vector3>((uintptr_t)cc + Offsets::CC_velocity);
    vel.y = g_Config.Movement.flySpeed;
    Mem::Write<Vector3>((uintptr_t)cc + Offsets::CC_velocity, vel);

    // Disable gravity
    if (g_Config.Movement.antiGravity) {
        // Modify gravity field
    }
}

void RunNoClip() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.noClip) return;

    void* mc = GetMovementController();
    if (!mc) return;

    void* cc = Mem::Read<void*>((uintptr_t)mc + Offsets::MC_characterController);
    if (!cc) return;

    // Disable collider
    if (Collider::set_enabled) {
        Collider::set_enabled(cc, false);
    }
}

void RunSuperJump() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.superJump) return;

    void* mc = GetMovementController();
    if (!mc) return;

    // Modify jump force
    float jumpForce = Mem::Read<float>((uintptr_t)mc + Offsets::MC_speed);
    // Would need actual jump force offset
}

void RunAntiGravity() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.antiGravity) return;

    void* mc = GetMovementController();
    if (!mc) return;

    // Modify gravity multiplier
}

void RunBunnyHop() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.bunnyHop) return;

    void* mc = GetMovementController();
    if (!mc) return;

    void* cc = Mem::Read<void*>((uintptr_t)mc + Offsets::MC_characterController);
    if (!cc) return;

    bool grounded = CharacterController::get_isGrounded ? 
        CharacterController::get_isGrounded(cc) : false;

    if (grounded) {
        // Trigger jump
        if (MovementController::Jump) {
            MovementController::Jump(mc);
        }
    }
}

void RunAutoStrafe() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.autoStrafe) return;
    // Auto-strafe for bunny hop optimization
}

void RunTeleport() {
    if (!g_Config.Movement.enabled || !g_Config.Movement.teleport) return;

    if (g_Config.Movement.teleportSave) {
        void* local = GetLocalPlayer();
        if (local) {
            g_Config.Movement.teleportPos = GetPlayerPosition(local);
            g_Config.Movement.teleportSave = false;
        }
    }

    if (g_Config.Movement.teleportLoad) {
        void* local = GetLocalPlayer();
        if (local) {
            void* cc = PlayerController::get_CharacterController ? 
                PlayerController::get_CharacterController(local) : nullptr;
            if (cc) {
                void* trans = Component::get_transform ? Component::get_transform(cc) : nullptr;
                if (trans && Transform::set_position) {
                    Transform::set_position(trans, g_Config.Movement.teleportPos);
                }
            }
            g_Config.Movement.teleportLoad = false;
        }
    }
}

// ==================== WEAPON FUNCTIONS ====================

void RunNoRecoil() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.noRecoil) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    if (GunParameters::set_recoilX) GunParameters::set_recoilX(gp, 0.0f);
    if (GunParameters::set_recoilY) GunParameters::set_recoilY(gp, 0.0f);
}

void RunNoSpread() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.noSpread) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    if (GunParameters::set_spread) GunParameters::set_spread(gp, 0.0f);
}

void RunRapidFire() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.rapidFire) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    float fireRate = GunParameters::get_fireRate ? GunParameters::get_fireRate(gp) : 0.1f;
    if (GunParameters::set_fireRate) {
        GunParameters::set_fireRate(gp, fireRate / g_Config.Weapon.fireRateMult);
    }
}

void RunInstantReload() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.instantReload) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    if (GunParameters::set_reloadTime) {
        GunParameters::set_reloadTime(gp, 0.01f);
    }
}

void RunInfiniteAmmo() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.infiniteAmmo) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    if (GunController::set_Ammo) {
        GunController::set_Ammo(gun, 999);
    }
    if (GunController::set_ReserveAmmo) {
        GunController::set_ReserveAmmo(gun, 999);
    }
}

void RunWallBang() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.wallBang) return;
    // Modify raycast to ignore walls
    // Would need to hook Physics.Raycast
}

void RunOneHit() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.oneHit) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    if (GunParameters::set_damage) {
        GunParameters::set_damage(gp, 999.0f);
    }
}

void RunDamageModifier() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.damageModifier) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    void* gp = GetGunParameters(gun);
    if (!gp) return;

    float baseDamage = GunParameters::get_damage ? GunParameters::get_damage(gp) : 25.0f;
    if (GunParameters::set_damage) {
        GunParameters::set_damage(gp, baseDamage * g_Config.Weapon.damageMult);
    }
}

void RunAutoShoot() {
    if (!g_Config.Weapon.enabled || !g_Config.Weapon.autoPistol) return;

    void* gun = GetCurrentGun();
    if (!gun) return;

    // Auto-shoot when target in crosshair
    void* target = GetClosestPlayerToCrosshair(5.0f, true, true);
    if (target && IsTargetValid(target)) {
        if (GunController::Shoot) {
            GunController::Shoot(gun);
        }
    }
}

// ==================== COMBAT FUNCTIONS ====================

void RunGodMode() {
    if (!g_Config.Combat.enabled || !g_Config.Combat.godMode) return;

    void* local = GetLocalPlayer();
    if (!local) return;

    void* phc = PlayerController::get_PlayerHitController ? 
        PlayerController::get_PlayerHitController(local) : nullptr;
    if (phc && PlayerHitController::SetGodMode) {
        PlayerHitController::SetGodMode(phc, true);
    }
}

void RunInfiniteHealth() {
    if (!g_Config.Combat.enabled || !g_Config.Combat.infiniteHealth) return;

    void* local = GetLocalPlayer();
    if (!local) return;

    if (PlayerController::set_Health) {
        PlayerController::set_Health(local, 100);
    } else {
        Mem::Write<int32_t>((uintptr_t)local + Offsets::PC_health, 100);
    }
}

void RunInfiniteArmor() {
    if (!g_Config.Combat.enabled || !g_Config.Combat.infiniteArmor) return;

    void* local = GetLocalPlayer();
    if (!local) return;

    if (PlayerController::set_Armor) {
        PlayerController::set_Armor(local, 100);
    } else {
        Mem::Write<int32_t>((uintptr_t)local + Offsets::PC_armor, 100);
    }
}

void RunHealOnKill() {
    if (!g_Config.Combat.enabled || !g_Config.Combat.healOnKill) return;
    // Would need to hook kill event
}

void RunAutoHeal() {
    if (!g_Config.Combat.enabled || !g_Config.Combat.autoHeal) return;

    void* local = GetLocalPlayer();
    if (!local) return;

    int health = GetPlayerHealth(local);
    if (health < g_Config.Combat.autoHealThreshold) {
        // Use medkit or auto-heal
        // Would need to trigger heal action
    }
}

// ==================== SKIN FUNCTIONS ====================

void RunSkinChanger() {
    if (!g_Config.Skins.enabled || !g_Config.Skins.skinChanger) return;

    void* sm = SkinManager::get_Instance ? SkinManager::get_Instance() : nullptr;
    if (!sm) return;

    if (g_Config.Skins.allSkins) {
        SkinManager::ApplyAllSkins(sm);
    }
}

void RunKnifeChanger() {
    if (!g_Config.Skins.enabled || !g_Config.Skins.knifeChanger) return;

    void* sm = SkinManager::get_Instance ? SkinManager::get_Instance() : nullptr;
    if (!sm) return;

    if (g_Config.Skins.rareKnives) {
        SkinManager::EquipKnife(sm, 9999); // Rare knife ID
    }
}

void RunGloveChanger() {
    if (!g_Config.Skins.enabled || !g_Config.Skins.gloveChanger) return;

    void* sm = SkinManager::get_Instance ? SkinManager::get_Instance() : nullptr;
    if (!sm) return;

    SkinManager::EquipGloves(sm, 9999); // Glove ID
}

void RunStickerChanger() {
    if (!g_Config.Skins.enabled || !g_Config.Skins.stickerChanger) return;

    void* sm = SkinManager::get_Instance ? SkinManager::get_Instance() : nullptr;
    if (!sm) return;

    SkinManager::EquipSticker(sm, 0, 9999); // Slot 0, sticker ID
}

void ApplyAllSkins() {
    void* sm = SkinManager::get_Instance ? SkinManager::get_Instance() : nullptr;
    if (!sm) return;

    SkinManager::ApplyAllSkins(sm);
}

// ==================== SPOOF FUNCTIONS ====================

void RunSpoofing() {
    if (!g_Config.Spoof.enabled) return;

    // Device spoofing
    if (g_Config.Spoof.spoofDevice) {
        // Hook system properties
    }

    if (g_Config.Spoof.spoofAndroidID) {
        // Hook Settings.Secure.ANDROID_ID
    }

    if (g_Config.Spoof.spoofIMEI) {
        // Hook TelephonyManager.getDeviceId
    }

    if (g_Config.Spoof.spoofMAC) {
        // Hook NetworkInterface.getHardwareAddress
    }

    if (g_Config.Spoof.spoofHWID) {
        // Hook Build.SERIAL and other HW identifiers
    }

    if (g_Config.Spoof.spoofStandoffUUID) {
        // Hook Standoff 2 UUID generation
    }

    if (g_Config.Spoof.changeIP) {
        // Use proxy or VPN
    }
}

void RunBanReset() {
    if (!g_Config.Spoof.enabled || !g_Config.Spoof.resetBan) return;

    // Clear game data
    // Wipe shared preferences
    // Clear cache
    // Generate new device fingerprint

    g_Config.Spoof.resetBan = false; // One-time action
}

void RunBlockReports() {
    if (!g_Config.Spoof.enabled || !g_Config.Spoof.blockReports) return;
    // Hook Reports.SendReport to block
}

void RunBlockKicks() {
    if (!g_Config.Spoof.enabled || !g_Config.Spoof.blockKicks) return;
    // Hook kick vote processing
}

void RunBlockSpectate() {
    if (!g_Config.Spoof.enabled || !g_Config.Spoof.blockSpectate) return;
    // Block spectate RPCs
}

void RunBlockVoteKick() {
    if (!g_Config.Spoof.enabled || !g_Config.Spoof.blockVoteKick) return;
    // Block vote kick processing
}


// ==================== HOOK IMPLEMENTATIONS ====================

void PlayerController_Update_Hook(void* self) {
    // Call original
    if (o_PlayerController_Update) {
        ((void(*)(void*))o_PlayerController_Update)(self);
    }

    // Run combat features
    if (g_Config.Combat.enabled) {
        RunGodMode();
        RunInfiniteHealth();
        RunInfiniteArmor();
        RunHealOnKill();
        RunAutoHeal();
    }

    // Run movement features
    if (g_Config.Movement.enabled) {
        RunSpeedHack();
        RunFly();
        RunNoClip();
        RunSuperJump();
        RunAntiGravity();
        RunBunnyHop();
        RunAutoStrafe();
        RunTeleport();
    }

    // Run spoofing
    if (g_Config.Spoof.enabled) {
        RunSpoofing();
        RunBanReset();
        RunBlockReports();
        RunBlockKicks();
        RunBlockSpectate();
        RunBlockVoteKick();
    }
}

void AimController_Update_Hook(void* self) {
    // Call original first
    if (o_AimController_Update) {
        ((void(*)(void*))o_AimController_Update)(self);
    }

    // Run aimbot features
    if (g_Config.Aimbot.enabled) {
        RunAimbot();
        RunSilentAim();
        RunRageAim();
        RunTriggerBot();
        RunMagnetAim();
    }

    // Apply FOV
    if (g_Config.Visual.enabled && g_Config.Visual.fov != 90.0f) {
        SetCameraFOV(g_Config.Visual.fov);
    }

    // Third person
    if (g_Config.Visual.enabled && g_Config.Visual.thirdPerson) {
        void* pmc = GetLocalPlayer();
        if (pmc) {
            void* mainCam = PlayerController::get_PlayerMainCamera ? 
                PlayerController::get_PlayerMainCamera(pmc) : nullptr;
            if (mainCam && PlayerMainCamera::SetThirdPerson) {
                PlayerMainCamera::SetThirdPerson(mainCam, true);
            }
        }
    }
}

void GunController_Shoot_Hook(void* self) {
    // Run weapon features before shoot
    if (g_Config.Weapon.enabled) {
        RunNoRecoil();
        RunNoSpread();
        RunRapidFire();
        RunWallBang();
        RunOneHit();
        RunDamageModifier();
    }

    // Call original
    if (o_GunController_Shoot) {
        ((void(*)(void*))o_GunController_Shoot)(self);
    }

    // Run infinite ammo after shoot
    if (g_Config.Weapon.enabled && g_Config.Weapon.infiniteAmmo) {
        RunInfiniteAmmo();
    }
}

float GunController_GetSpread_Hook(void* self) {
    if (g_Config.Weapon.enabled && g_Config.Weapon.noSpread) {
        return 0.0f;
    }
    if (o_GunController_GetSpread) {
        return ((float(*)(void*))o_GunController_GetSpread)(self);
    }
    return 0.0f;
}

Vector3 GunController_GetRecoil_Hook(void* self) {
    if (g_Config.Weapon.enabled && g_Config.Weapon.noRecoil) {
        return Vector3(0, 0, 0);
    }
    if (o_GunController_GetRecoil) {
        return ((Vector3(*)(void*))o_GunController_GetRecoil)(self);
    }
    return Vector3(0, 0, 0);
}

float GunController_GetFireRate_Hook(void* self) {
    float original = 0.1f;
    if (o_GunController_GetFireRate) {
        original = ((float(*)(void*))o_GunController_GetFireRate)(self);
    }
    if (g_Config.Weapon.enabled && g_Config.Weapon.rapidFire) {
        return original / g_Config.Weapon.fireRateMult;
    }
    return original;
}

float GunController_GetDamage_Hook(void* self) {
    float original = 25.0f;
    if (o_GunController_GetDamage) {
        original = ((float(*)(void*))o_GunController_GetDamage)(self);
    }
    if (g_Config.Weapon.enabled && g_Config.Weapon.damageModifier) {
        return original * g_Config.Weapon.damageMult;
    }
    if (g_Config.Weapon.enabled && g_Config.Weapon.oneHit) {
        return 999.0f;
    }
    return original;
}

float GunController_GetRange_Hook(void* self) {
    float original = 100.0f;
    if (o_GunController_GetRange) {
        original = ((float(*)(void*))o_GunController_GetRange)(self);
    }
    if (g_Config.Weapon.enabled && g_Config.Weapon.noDamageFalloff) {
        return 9999.0f;
    }
    return original;
}

void GunController_Reload_Hook(void* self) {
    if (g_Config.Weapon.enabled && g_Config.Weapon.instantReload) {
        // Skip reload animation, instantly set ammo
        if (GunController::set_Ammo) {
            void* gp = GetGunParameters(self);
            if (gp && GunParameters::get_ammoCapacity) {
                int maxAmmo = GunParameters::get_ammoCapacity(gp);
                GunController::set_Ammo(self, maxAmmo);
            }
        }
        return; // Skip original reload
    }

    if (o_GunController_Reload) {
        ((void(*)(void*))o_GunController_Reload)(self);
    }
}

void DamageEffectController_Apply_Hook(void* self, float damage, void* attacker, int damageType) {
    if (g_Config.Combat.enabled && g_Config.Combat.godMode) {
        return; // Block all damage
    }

    if (g_Config.Combat.enabled && g_Config.Combat.noKnockback) {
        damageType &= ~0x2; // Remove knockback flag
    }

    if (o_DamageEffectController_Apply) {
        ((void(*)(void*, float, void*, int))o_DamageEffectController_Apply)(self, damage, attacker, damageType);
    }
}

Vector3 PlayerHitbox_GetPosition_Hook(void* self) {
    // Could modify hitbox positions for expand hitbox
    if (o_PlayerHitbox_GetPosition) {
        return ((Vector3(*)(void*))o_PlayerHitbox_GetPosition)(self);
    }
    return Vector3();
}

void MovementController_Update_Hook(void* self) {
    // Call original
    if (o_MovementController_Update) {
        ((void(*)(void*))o_MovementController_Update)(self);
    }

    // Apply speed modifications
    if (g_Config.Movement.enabled && g_Config.Movement.speedHack) {
        void* cc = Mem::Read<void*>((uintptr_t)self + Offsets::MC_characterController);
        if (cc) {
            Vector3 vel = Mem::Read<Vector3>((uintptr_t)cc + Offsets::CC_velocity);
            vel.x *= g_Config.Movement.speedMult;
            vel.z *= g_Config.Movement.speedMult;
            Mem::Write<Vector3>((uintptr_t)cc + Offsets::CC_velocity, vel);
        }
    }
}

// ==================== ANTI-CHEAT HOOKS ====================

void AntiCheatManager_Report_Hook(void* self, void* player, int reason) {
    // Block reports
    LOGI("[AntiBan] Blocked report: reason=%d", reason);
    return; // Don't call original
}

void AntiCheatManager_Ban_Hook(void* self, void* player, int code, int duration) {
    // Block bans
    LOGI("[AntiBan] Blocked ban: code=%d, duration=%d", code, duration);
    return; // Don't call original
}

void AntiCheatManager_Kick_Hook(void* self, void* player, void* reason) {
    // Block kicks
    LOGI("[AntiBan] Blocked kick");
    return; // Don't call original
}

bool AntiCheatManager_CheckIntegrity_Hook(void* self) {
    // Return true to pass integrity check
    LOGI("[AntiBan] Faked integrity check");
    return true;
}

void AntiCheatManager_ScanMemory_Hook(void* self) {
    // Block memory scan
    LOGI("[AntiBan] Blocked memory scan");
    return; // Don't call original
}

// ==================== NETWORK HOOKS ====================

void PhotonView_RPC_Hook(void* self, void* method, void* target, void* params) {
    // Intercept and block suspicious RPCs
    if (g_Config.Spoof.enabled && g_Config.Spoof.blockKicks) {
        // Check if this is a kick RPC
        // Would need to check method name
    }

    if (o_PhotonView_RPC) {
        ((void(*)(void*, void*, void*, void*))o_PhotonView_RPC)(self, method, target, params);
    }
}

void PhotonView_Send_Hook(void* self, void* data) {
    // Modify outgoing data
    if (o_PhotonView_Send) {
        ((void(*)(void*, void*))o_PhotonView_Send)(self, data);
    }
}

void NetworkController_SendRPC_Hook(void* self, void* method, void* target, void* params) {
    // Block suspicious RPCs
    if (g_Config.Spoof.enabled && g_Config.Spoof.blockSpectate) {
        // Block spectate RPCs
    }

    if (o_NetworkController_SendRPC) {
        ((void(*)(void*, void*, void*, void*))o_NetworkController_SendRPC)(self, method, target, params);
    }
}

// ==================== CAMERA HOOKS ====================

Vector3 Camera_WorldToScreenPoint_Hook(void* self, Vector3 pos, int eye) {
    // Could modify W2S for chams or other effects
    if (o_Camera_WorldToScreenPoint) {
        return ((Vector3(*)(void*, Vector3, int))o_Camera_WorldToScreenPoint)(self, pos, eye);
    }
    return Vector3();
}

float Camera_get_fieldOfView_Hook(void* self) {
    if (g_Config.Visual.enabled && g_Config.Visual.fov != 90.0f) {
        return g_Config.Visual.fov;
    }
    if (o_Camera_get_fieldOfView) {
        return ((float(*)(void*))o_Camera_get_fieldOfView)(self);
    }
    return 60.0f;
}

void Camera_set_fieldOfView_Hook(void* self, float fov) {
    if (g_Config.Visual.enabled && g_Config.Visual.fov != 90.0f) {
        fov = g_Config.Visual.fov;
    }
    if (o_Camera_set_fieldOfView) {
        ((void(*)(void*, float))o_Camera_set_fieldOfView)(self, fov);
    }
}

// ==================== TRANSFORM HOOKS ====================

Vector3 Transform_get_position_Hook(void* self) {
    // Could modify positions for teleport or other features
    if (o_Transform_get_position) {
        return ((Vector3(*)(void*))o_Transform_get_position)(self);
    }
    return Vector3();
}

void Transform_set_position_Hook(void* self, Vector3 pos) {
    if (o_Transform_set_position) {
        ((void(*)(void*, Vector3))o_Transform_set_position)(self, pos);
    }
}

// ==================== CHARACTER CONTROLLER HOOKS ====================

void CharacterController_Move_Hook(void* self, Vector3 motion) {
    if (g_Config.Movement.enabled && g_Config.Movement.speedHack) {
        motion.x *= g_Config.Movement.speedMult;
        motion.z *= g_Config.Movement.speedMult;
    }
    if (o_CharacterController_Move) {
        ((void(*)(void*, Vector3))o_CharacterController_Move)(self, motion);
    }
}

bool CharacterController_get_isGrounded_Hook(void* self) {
    if (g_Config.Movement.enabled && g_Config.Movement.bunnyHop) {
        return true; // Always grounded for bunny hop
    }
    if (o_CharacterController_get_isGrounded) {
        return ((bool(*)(void*))o_CharacterController_get_isGrounded)(self);
    }
    return false;
}

// ==================== REPORT / KICK / SPECTATE HOOKS ====================

void Reports_SendReport_Hook(void* self, void* target, int reason, void* details) {
    if (g_Config.Spoof.enabled && g_Config.Spoof.blockReports) {
        LOGI("[AntiBan] Blocked report send");
        return;
    }
    if (o_Reports_SendReport) {
        ((void(*)(void*, void*, int, void*))o_Reports_SendReport)(self, target, reason, details);
    }
}

void KickVote_Process_Hook(void* self, void* args) {
    if (g_Config.Spoof.enabled && g_Config.Spoof.blockVoteKick) {
        LOGI("[AntiBan] Blocked vote kick");
        return;
    }
    if (o_KickVote_Process) {
        ((void(*)(void*, void*))o_KickVote_Process)(self, args);
    }
}

void Spectate_Follow_Hook(void* self, void* player) {
    if (g_Config.Spoof.enabled && g_Config.Spoof.blockSpectate) {
        LOGI("[AntiBan] Blocked spectate");
        return;
    }
    if (o_Spectate_Follow) {
        ((void(*)(void*, void*))o_Spectate_Follow)(self, player);
    }
}

// ==================== RADAR HOOK ====================

void RadarManager_Update_Hook(void* self) {
    // Call original
    if (o_RadarManager_Update) {
        ((void(*)(void*))o_RadarManager_Update)(self);
    }

    // Draw our custom radar
    if (g_Config.Radar.enabled) {
        DrawRadar();
    }
}

// ==================== WEAPONRY HOOK ====================

void WeaponryController_SwitchWeapon_Hook(void* self, int slot) {
    if (g_Config.Weapon.enabled && g_Config.Weapon.quickSwitch) {
        // Instant weapon switch
    }
    if (o_WeaponryController_SwitchWeapon) {
        ((void(*)(void*, int))o_WeaponryController_SwitchWeapon)(self, slot);
    }
}

// ==================== HEALTH / ARMOR HOOKS ====================

int PlayerController_get_Health_Hook(void* self) {
    if (g_Config.Combat.enabled && g_Config.Combat.godMode) {
        return 100;
    }
    if (o_PlayerController_get_Health) {
        return ((int(*)(void*))o_PlayerController_get_Health)(self);
    }
    return Mem::Read<int32_t>((uintptr_t)self + Offsets::PC_health);
}

void PlayerController_set_Health_Hook(void* self, int val) {
    if (g_Config.Combat.enabled && g_Config.Combat.godMode) {
        val = 100; // Force max health
    }
    if (o_PlayerController_set_Health) {
        ((void(*)(void*, int))o_PlayerController_set_Health)(self, val);
    } else {
        Mem::Write<int32_t>((uintptr_t)self + Offsets::PC_health, val);
    }
}

int PlayerController_get_Armor_Hook(void* self) {
    if (g_Config.Combat.enabled && g_Config.Combat.infiniteArmor) {
        return 100;
    }
    if (o_PlayerController_get_Armor) {
        return ((int(*)(void*))o_PlayerController_get_Armor)(self);
    }
    return Mem::Read<int32_t>((uintptr_t)self + Offsets::PC_armor);
}

void PlayerController_set_Armor_Hook(void* self, int val) {
    if (g_Config.Combat.enabled && g_Config.Combat.infiniteArmor) {
        val = 100;
    }
    if (o_PlayerController_set_Armor) {
        ((void(*)(void*, int))o_PlayerController_set_Armor)(self, val);
    } else {
        Mem::Write<int32_t>((uintptr_t)self + Offsets::PC_armor, val);
    }
}

// ==================== ANIMATOR HOOK ====================

void* Animator_GetBoneTransform_Hook(void* self, int humanBoneId) {
    // Could modify bone transforms for animation changes
    if (o_Animator_GetBoneTransform) {
        return ((void*(*)(void*, int))o_Animator_GetBoneTransform)(self, humanBoneId);
    }
    return nullptr;
}

// ==================== INIT / SHUTDOWN ====================

bool InitializeHooks() {
    LOGI("[Hooks] Initializing...");

    // Resolve IL2CPP functions first
    // This would use il2cpp API or pattern scanning
    // Placeholder: assume functions are resolved elsewhere

    // Install hooks using Dobby or inline hooking
    // Placeholder: actual hook installation

    LOGI("[Hooks] Initialized successfully");
    return true;
}

void ShutdownHooks() {
    LOGI("[Hooks] Shutting down...");

    // Unhook all functions
    // Placeholder: actual unhooking

    LOGI("[Hooks] Shutdown complete");
}

void UpdateAll() {
    // Called every frame
    if (g_Config.ESP.enabled) {
        DrawESP();
    }

    if (g_Config.Radar.enabled) {
        UpdateRadar();
    }

    if (g_Config.Skins.enabled) {
        RunSkinChanger();
        RunKnifeChanger();
        RunGloveChanger();
        RunStickerChanger();
    }

    if (g_Config.Economy.enabled) {
        // Economy features
    }

    if (g_Config.Misc.enabled) {
        // Misc features
    }
}

} // namespace S2
