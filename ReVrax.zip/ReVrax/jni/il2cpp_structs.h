#pragma once
#include <cstdint>
#include <string>

// ============================================================
// ReVrax v2.0 - Standoff 2 v0.39.2 IL2CPP Structures (ARM64)
// Extracted from dump.cs | Updated 2026
// ============================================================

namespace IL2CPP {

// Forward declarations
struct Il2CppObject;
struct Il2CppString;
struct Il2CppArray;

template<typename T>
struct Il2CppArraySize {
    Il2CppObject obj;
    void* bounds;
    uintptr_t max_length;
    T m_Items[0];
};

// ==================== BASIC UNITY TYPES ====================
struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
    Vector3 operator+(const Vector3& o) const { return Vector3(x+o.x, y+o.y, z+o.z); }
    Vector3 operator-(const Vector3& o) const { return Vector3(x-o.x, y-o.y, z-o.z); }
    Vector3 operator*(float s) const { return Vector3(x*s, y*s, z*s); }
    float Length() const { return sqrtf(x*x + y*y + z*z); }
    float Distance(const Vector3& o) const {
        float dx = x-o.x, dy = y-o.y, dz = z-o.z;
        return sqrtf(dx*dx + dy*dy + dz*dz);
    }
};

struct Vector2 {
    float x, y;
    Vector2() : x(0), y(0) {}
    Vector2(float _x, float _y) : x(_x), y(_y) {}
};

struct Quaternion {
    float x, y, z, w;
};

struct Color {
    float r, g, b, a;
    Color(float _r=1,float _g=1,float _b=1,float _a=1):r(_r),g(_g),b(_b),a(_a){}
};

struct Ray {
    Vector3 origin;
    Vector3 direction;
};

struct RaycastHit {
    Vector3 point;
    Vector3 normal;
    uint32_t faceID;
    float distance;
    Vector2 uv;
    int32_t collider;
};

// ==================== IL2CPP INTERNALS ====================
struct MethodInfo {
    void* methodPointer;
    void* virtualMethodPointer;
    void* invoker_method;
    const char* name;
    void* klass;
    void* signature;
};

struct Il2CppClass {
    void* image;
    void* gc_desc;
    const char* name;
    const char* namespaze;
    void* byval_arg;
    void* this_arg;
    void* element_class;
    void* castClass;
    void* declaringType;
    void* parent;
    void* generic_class;
    void* typeDefinition;
    void* interopData;
    void* fields;
    void* events;
    void* properties;
    void* methods;
    void* nestedTypes;
    void* implementedInterfaces;
    void* interfaceOffsets;
    void* static_fields;
    void* rgctx_data;
    void* typeHierarchy;
    void* unity_user_data;
    uint32_t cctor_started;
    uint32_t cctor_finished;
    uint64_t cctor_thread;
    int32_t genericContainerIndex;
    int32_t customAttributeIndex;
    uint32_t instance_size;
    uint32_t actualSize;
    uint32_t element_size;
    int32_t native_size;
    uint32_t static_fields_size;
    uint32_t thread_static_fields_size;
    int32_t thread_static_fields_offset;
    uint32_t flags;
    uint32_t token;
    uint16_t method_count;
    uint16_t property_count;
    uint16_t field_count;
    uint16_t event_count;
    uint16_t nested_type_count;
    uint16_t vtable_count;
    uint16_t interfaces_count;
    uint16_t interface_offsets_count;
    uint8_t typeHierarchyDepth;
    uint8_t genericRecursionDepth;
    uint8_t rank;
    uint8_t minimumAlignment;
    uint8_t naturalAligment;
    uint8_t packingSize;
    uint8_t bitflags1;
    uint8_t bitflags2;
};

struct Il2CppObject {
    Il2CppClass* klass;
    void* monitor;
};

struct Il2CppString {
    Il2CppObject obj;
    int32_t length;
    wchar_t chars[0];
};

// ==================== STANDOFF 2 ENUMS ====================
enum class Team : int32_t {
    None = 0,
    Tr = 1,
    Ct = 2,
    Spectator = 3
};

enum class Bip : int32_t {
    Head = 0, Neck = 1, Spine1 = 2, Spine2 = 3,
    LeftUpperarm = 4, LeftForearm = 5, LeftHand = 6, LeftShoulder = 7,
    RightShoulder = 8, RightUpperarm = 9, RightForearm = 10, RightHand = 11,
    Hip = 12, LeftUpLeg = 13, LeftLeg = 14, LeftFoot = 15,
    RightUpLeg = 16, RightLeg = 17, RightFoot = 18, Spine = 19,
    WeaponContainer = 20
};

enum class HitboxType : int32_t {
    Sphere = 0,
    Capsule = 1,
    Box = 2
};

// ==================== UNITY COMPONENTS ====================
struct Transform {
    Il2CppObject obj;
    static void* (*get_position)(void* transform);
    static void* (*set_position)(void* transform, Vector3 pos);
    static void* (*get_rotation)(void* transform);
    static void* (*get_forward)(void* transform);
    static void* (*get_right)(void* transform);
    static void* (*get_up)(void* transform);
    static void* (*get_localPosition)(void* transform);
    static void* (*set_localPosition)(void* transform, Vector3 pos);
    static void* (*get_localRotation)(void* transform);
    static void* (*set_localRotation)(void* transform, Quaternion rot);
    static void* (*get_localScale)(void* transform);
    static void* (*set_localScale)(void* transform, Vector3 scale);
    static void* (*LookAt)(void* transform, Vector3 worldPosition);
};

struct Component {
    Il2CppObject obj;
    static void* (*get_transform)(void* component);
    static void* (*get_gameObject)(void* component);
    static void* (*get_tag)(void* component);
};

struct GameObject {
    Il2CppObject obj;
    static void* (*get_transform)(void* go);
    static void* (*Find)(const char* name);
    static void* (*FindWithTag)(const char* tag);
    static void* (*GetComponent)(void* go, void* type);
    static bool (*get_activeSelf)(void* go);
    static void (*set_active)(void* go, bool value);
    static void* (*get_layer)(void* go);
};

struct Camera {
    Il2CppObject obj;
    static void* (*get_main)();
    static void* (*get_current)();
    static void* (*WorldToScreenPoint)(void* cam, Vector3 pos, int eye);
    static void* (*WorldToViewportPoint)(void* cam, Vector3 pos);
    static float (*get_fieldOfView)(void* cam);
    static void (*set_fieldOfView)(void* cam, float fov);
    static float (*get_nearClipPlane)(void* cam);
    static float (*get_farClipPlane)(void* cam);
    static void* (*get_transform)(void* cam);
    static void* (*ScreenPointToRay)(void* cam, Vector2 pos);
    static void* (*ViewportPointToRay)(void* cam, Vector2 pos);
};

struct Animator {
    Il2CppObject obj;
    static void* (*get_transform)(void* animator);
    static void (*SetBool)(void* animator, Il2CppString* name, bool value);
    static void (*SetFloat)(void* animator, Il2CppString* name, float value);
    static void (*SetInteger)(void* animator, Il2CppString* name, int value);
    static void (*SetTrigger)(void* animator, Il2CppString* name);
    static bool (*GetBool)(void* animator, Il2CppString* name);
    static float (*GetFloat)(void* animator, Il2CppString* name);
    static int (*GetInteger)(void* animator, Il2CppString* name);
    static void* (*GetBoneTransform)(void* animator, int humanBoneId);
};

struct CharacterController {
    Il2CppObject obj;
    static Vector3 (*get_velocity)(void* cc);
    static bool (*get_isGrounded)(void* cc);
    static void (*Move)(void* cc, Vector3 motion);
    static float (*get_height)(void* cc);
    static void (*set_height)(void* cc, float h);
    static float (*get_radius)(void* cc);
    static void (*set_radius)(void* cc, float r);
    static Vector3 (*get_center)(void* cc);
    static void (*set_center)(void* cc, Vector3 c);
};

struct Collider {
    Il2CppObject obj;
    static void* (*get_transform)(void* collider);
    static Vector3 (*ClosestPoint)(void* collider, Vector3 pos);
    static bool (*get_enabled)(void* collider);
    static void (*set_enabled)(void* collider, bool value);
};

struct Physics {
    static bool (*Raycast)(Ray ray, RaycastHit* hit, float maxDistance);
    static bool (*RaycastLayer)(Ray ray, RaycastHit* hit, float maxDistance, int layerMask);
    static bool (*Linecast)(Vector3 start, Vector3 end, RaycastHit* hit);
};

// ==================== PHOTON NETWORKING ====================
struct PhotonPlayer {
    Il2CppObject obj;
    static int32_t (*get_ID)(void* player);
    static Il2CppString* (*get_NickName)(void* player);
    static bool (*get_IsMasterClient)(void* player);
    static bool (*get_IsLocal)(void* player);
    static int32_t (*get_ActorNr)(void* player);
    static void* (*get_CustomProperties)(void* player);
};

struct PhotonView {
    Il2CppObject obj;
    static int32_t (*get_viewID)(void* pv);
    static void* (*get_owner)(void* pv);
    static bool (*get_isMine)(void* pv);
    static void (*RPC)(void* pv, Il2CppString* method, void* target, void* params);
    static void* (*get_transform)(void* pv);
};

// ==================== HITBOX SYSTEM ====================
struct HitboxConfig {
    Il2CppObject obj;
    Bip bone;
    int32_t hitboxType;
    Vector3 center;
    Vector3 size;
    int32_t direction;
    float radius;
    float height;
};

struct PlayerHitbox {
    Il2CppObject obj;
    void* hitboxConfig;
    void* collider;
    int32_t bipEnum;
    float damageMult;
    void* owner;
    static Vector3 (*get_position)(void* hitbox);
    static int32_t (*get_bone)(void* hitbox);
    static float (*get_damageMult)(void* hitbox);
};

struct BipedMap {
    Il2CppObject obj;
    void* Head;
    void* Neck;
    void* Spine;
    void* Spine1;
    void* Spine2;
    void* LeftShoulder;
    void* LeftUpperarm;
    void* LeftForearm;
    void* LeftHand;
    void* RightShoulder;
    void* RightUpperarm;
    void* RightForearm;
    void* RightHand;
    void* Hip;
    void* LeftUpLeg;
    void* LeftLeg;
    void* LeftFoot;
    void* RightUpLeg;
    void* RightLeg;
    void* RightFoot;
    void* WeaponContainer;
};

// ==================== PLAYER CHARACTER ====================
struct PlayerCharacterView {
    Il2CppObject obj;
    void* transform1;
    void* transform2;
    bool flag;
    void* animator;
    void* skinnedMeshLodGroup;
    BipedMap* bipedMap;
    static BipedMap* (*get_bipedMap)(void* view);
    static void* (*get_animator)(void* view);
    static void* (*get_transform)(void* view);
};

// ==================== PLAYER CONTROLLER ====================
// Offsets from dump.cs v0.39.2
// 0x28 Transform _mainCameraHolder
// 0x48 PlayerCharacterView FHGACBBGHEEBEEA
// 0x50 PlayerCharacterView GBEHADFCHGCGDHF
// 0x78 bool EDBGBDAHEAEDFCC
// 0x79 EBBFAFBCBFGDGGE EAGCGEABDGFGBHC (team)
// 0x7c float AEDDGECCHCFBBCH
// 0x80 AimController DAFBHDCBBFDBDBD
// 0x88 WeaponryController AECFFADGAGBBHHB
// 0x90 MecanimController HBAHCHGEEHAHGDE
// 0x98 MovementController DBHAFHFGGFGFECA
// 0xa0 ArmsAnimationController ECHDHADACBDFHHF
// 0xa8 PlayerHitController HHAHHGGACGEBFGH
// 0xb0 PlayerMaterialController AECGCDFHEGEAGCG
// 0xb8 PlayerOcclusionController BDGBDHGFBHDDAFA
// 0xc0 NetworkController CEGFDEEGFGDBDBF
// 0xd0 PlayerCharacterView HBHHEGDHGDHFHCD
// 0xd8 bool AFBHCBEGEDFFEBE
// 0xd9 bool EDCDFBHFEADADBB
// 0xdc float CEBAFFDFHGBHBBB
// 0xe0 PlayerSoundController DCGHBCFBFHAACBH
// 0xe8 PlayerMainCamera HDDBDFEHGCFFBEA
// 0xf0 PlayerFPSCamera FEADFHGCFFBBFED
// 0x118 CharacterController CCFHEEFGBDDFFDC
// 0x120 SkinnedMeshLodGroup DDGADDFFCFEFEBG
// 0x128 CharacterLodGroup DABFEBCECBBFFFD
// 0x150 PhotonView HHCEEHGACEBEDFC
// 0x158 int FACDFFBDHEBHAFG (health)
// 0x15c int FFHFDHGFFDGFBBB (armor)
// 0x160 PhotonPlayer EAADHDCCHBDEAAB
struct PlayerController {
    Il2CppObject obj;
    static void* (*get_AimController)(void* pc);
    static void* (*get_WeaponryController)(void* pc);
    static void* (*get_MovementController)(void* pc);
    static void* (*get_MecanimController)(void* pc);
    static void* (*get_PlayerHitController)(void* pc);
    static void* (*get_PlayerCharacterView)(void* pc);
    static void* (*get_NetworkController)(void* pc);
    static void* (*get_PhotonView)(void* pc);
    static Team (*get_Team)(void* pc);
    static int32_t (*get_Health)(void* pc);
    static int32_t (*get_Armor)(void* pc);
    static bool (*get_IsDead)(void* pc);
    static bool (*get_IsLocal)(void* pc);
    static void* (*get_CharacterController)(void* pc);
    static void* (*get_PlayerMainCamera)(void* pc);
    static void* (*get_PlayerFPSCamera)(void* pc);
    static void* (*get_PlayerSoundController)(void* pc);
    static void* (*get_PlayerMaterialController)(void* pc);
    static void* (*get_PlayerOcclusionController)(void* pc);
    static void* (*get_ArmsAnimationController)(void* pc);
    static float (*get_HealthFloat)(void* pc);
    static void (*set_Health)(void* pc, int32_t val);
    static void (*set_Armor)(void* pc, int32_t val);
    static void* (*get_Transform)(void* pc);
    static Vector3 (*GetPosition)(void* pc);
};

// ==================== PLAYER MANAGER (Singleton) ====================
// 0x28 Dictionary<int, PlayerController> ACHDCBAEFACDCEE
// 0x38 HashSet<PlayerController> BBFEFFBGDEBDEBB (all players)
// 0x68 PlayerController CFCHCBFEEFHBAEH (local?)
// 0x70 PlayerController EGAHBFAFFCBCEDF
struct PlayerManager {
    Il2CppObject obj;
    static void* instance;
    static void* (*get_Instance)();
    static void* (*get_AllPlayers)();
    static void* (*get_LocalPlayer)();
    static void* (*GetPlayerById)(int32_t id);
    static void* (*GetPlayerByViewId)(int32_t viewId);
    static void* (*GetPlayerByGameObject)(void* go);
    static bool (*IsPlayerValid)(int32_t id);
};

// ==================== AIM CONTROLLER ====================
// 0x53 bool _overrideSpineRotation
// 0x58 float sensitivityX
// 0x5c float sensitivityY
// 0x60 float minimumX
// 0x64 float maximumX
// 0x68 Transform FPSP_go
// 0x70 Transform spineDirector
// 0x78 Transform FPSCamera
// 0x80 Transform camTransform
// 0x88 AimingParameters aimingParameters
// 0x90 GEADDDBFAGHCHFF aimingData
// 0x98 InterpolatorsBunch interpolatorsBunch
// 0xa0 TuningParams tuningParams
// 0xa8 float _headDampingSpeed
// 0xb0 PlayerController HFGEBEFBDFAFDFF
// 0xb8 MovementController GFCBDDAHGGBFHFD
// 0xc0 Transform CBABFEGAHDBGAEA
// 0xc8 MecanimController FGDCABDEBACBEHG
struct AimController {
    Il2CppObject obj;
    static void* (*get_FPSCamera)(void* ac);
    static void* (*get_spineDirector)(void* ac);
    static void* (*get_aimingParameters)(void* ac);
    static void (*set_sensitivityX)(void* ac, float val);
    static void (*set_sensitivityY)(void* ac, float val);
    static void (*set_minimumX)(void* ac, float val);
    static void (*set_maximumX)(void* ac, float val);
    static void (*set_overrideSpineRotation)(void* ac, bool val);
    static float (*get_sensitivityX)(void* ac);
    static float (*get_sensitivityY)(void* ac);
    static void* (*get_PlayerController)(void* ac);
    static void* (*get_MovementController)(void* ac);
    static void* (*get_MecanimController)(void* ac);
    static void* (*get_CamTransform)(void* ac);
};

// ==================== WEAPONRY CONTROLLER ====================
// 0x58 Dictionary<byte, WeaponController> CCCCCAHDHAGHFCG
// 0x60 List<WeaponController> HHAADFDEGAGEHBG
// 0x68 List<byte> HHACCCAFFCGFAED
// 0x70 List<ECAAHCHBBBFEDFC> AGGFFGHGGAGHGBH
// 0x78 PlayerController BHFADCBGGCAHCAA
// 0x80 MecanimController ECDBGHGEFCFFGGC
// 0x88 byte HEBGAAFFAHCBHEH
// 0x89 bool GFGEFABFBEBDBHH
// 0x90 WeaponPickupController DGHAHAHBBFEFGHF
// 0x98 KitController EDGAEHHEGGEEDAE
// 0xa0 WeaponController GBCHHHGABFGDBFD (current weapon)
// 0xa8 bool GFABGFHAGGDABCC
// 0xa9 bool CGHDAEACBBFECFC
// 0xac float GCBDFHAGAFAGAEE
// 0xb0 float ECDDCBBBHCGCDEG
// 0xb8 WeaponManager BGDGBFFBHBAHECF
struct WeaponryController {
    Il2CppObject obj;
    static void* (*get_CurrentWeapon)(void* wc);
    static void* (*get_WeaponPickupController)(void* wc);
    static void* (*get_KitController)(void* wc);
    static void* (*get_PlayerController)(void* wc);
    static void* (*get_MecanimController)(void* wc);
    static void* (*get_WeaponManager)(void* wc);
    static bool (*get_CanShoot)(void* wc);
    static bool (*get_IsReloading)(void* wc);
    static float (*get_SwitchProgress)(void* wc);
    static void (*SwitchWeapon)(void* wc, int slot);
    static void (*Reload)(void* wc);
};

// ==================== GUN CONTROLLER ====================
// 0x100 HBFBFBDAFAFDDFH BGDFDGFBEBAHFAC
// 0x108 SafeFloat CHBGCADAEGDBFDC
// 0x110 SafeFloat BFGCHCHGGEBAFFF
// 0x118 int GHGHCFCBEECFDDC
// 0x11c int DDEFAHABCCGEHFG
// 0x120 SafeInt GCGGGBHBEBBBHGA
// 0x128 SafeInt DGAHCGDGEEGFDHE
// 0x130 SafeBool CDGAHGCBCBBCHAE
// 0x138 SafeBool FEAGHCDFHDEEBGD
// 0x140 GunSoundController DAFHCHEFAACEGFD
// 0x148 ShootingLoopState GFFAHFCCEBCAADA
// 0x150 DHFEEFEGBBDCCCB CBFFFGHHEFFBEBB
// 0x168 GunParameters EEFHHDBADHBFCBC
// 0x170 BACHBFDDCGGCGAD CHEEHCEHCFGFEGH
// 0x178 float GFBDGHFEFBAEDBC
// 0x17c float EDCCACACHHBGHCH
// 0x1c0 Transform DCFHEGCBCBDEFBE
// 0x1c8 Transform ECHEHCAHEGCHABH
// 0x1d0 Transform BGEGBACGEBEHGDH
// 0x1d8 GunSoundParameters GGBBGCAFDAFEGAH
// 0x1e0 float DAEHHCGAAHAFGCF
// 0x1e4 float BCEAFDDFDEFDFAC
// 0x1e8 int HGGABDHGFDCFGDA
// 0x1ec SafeFloat FCEAEFDEFFHBFDD
// 0x1f4 SafeFloat GFBAGFDHDDHGHBG
struct GunController {
    Il2CppObject obj;
    static void* (*get_GunParameters)(void* gc);
    static void* (*get_GunSoundController)(void* gc);
    static int (*get_Ammo)(void* gc);
    static int (*get_MaxAmmo)(void* gc);
    static int (*get_ReserveAmmo)(void* gc);
    static float (*get_FireRate)(void* gc);
    static float (*get_RecoilX)(void* gc);
    static float (*get_RecoilY)(void* gc);
    static float (*get_Spread)(void* gc);
    static float (*get_Damage)(void* gc);
    static float (*get_Range)(void* gc);
    static bool (*get_IsShooting)(void* gc);
    static bool (*get_CanShoot)(void* gc);
    static void (*set_Ammo)(void* gc, int val);
    static void (*set_ReserveAmmo)(void* gc, int val);
    static void (*set_FireRate)(void* gc, float val);
    static void (*set_RecoilX)(void* gc, float val);
    static void (*set_RecoilY)(void* gc, float val);
    static void (*set_Spread)(void* gc, float val);
    static void (*set_Damage)(void* gc, float val);
    static void (*set_Range)(void* gc, float val);
    static void (*Shoot)(void* gc);
    static void (*Reload)(void* gc);
    static void* (*get_Transform)(void* gc);
    static void* (*get_MuzzleTransform)(void* gc);
    static void* (*get_ShellTransform)(void* gc);
};

// ==================== GUN PARAMETERS ====================
struct GunParameters {
    Il2CppObject obj;
    static float (*get_damage)(void* gp);
    static float (*get_fireRate)(void* gp);
    static float (*get_reloadTime)(void* gp);
    static float (*get_spread)(void* gp);
    static float (*get_recoilX)(void* gp);
    static float (*get_recoilY)(void* gp);
    static float (*get_range)(void* gp);
    static int (*get_ammoCapacity)(void* gp);
    static int (*get_reserveAmmo)(void* gp);
    static float (*get_movementSpeed)(void* gp);
    static float (*get_aimSpeed)(void* gp);
    static float (*get_scopeFov)(void* gp);
    static bool (*get_isAutomatic)(void* gp);
    static bool (*get_canScope)(void* gp);
    static void (*set_damage)(void* gp, float val);
    static void (*set_fireRate)(void* gp, float val);
    static void (*set_reloadTime)(void* gp, float val);
    static void (*set_spread)(void* gp, float val);
    static void (*set_recoilX)(void* gp, float val);
    static void (*set_recoilY)(void* gp, float val);
    static void (*set_range)(void* gp, float val);
    static void (*set_ammoCapacity)(void* gp, int val);
    static void (*set_reserveAmmo)(void* gp, int val);
};

// ==================== MOVEMENT CONTROLLER ====================
// 0x58 PlayerController GACHCFECGAEGBGH
// 0x60 PlayerOcclusionController DHDGECACBGGACFH
// 0x68 bool _neverIdle
// 0x70 Transform EBDHDHDBCCBGDEA
// 0x78 CBGAABDHGHGDFCE GAGBGBCAFFBAAFG
// 0x80 float DAACGCEGCFEBDGB
// 0x84 float BADDGBHHAGBGHGB
// 0x88 CharacterController FEBFAEAGADABFDC
// 0x90 Trigger GDCGGBFBFFCGHCF
// 0x98 ABCCFAEABHDGDED[] BCDACCGEHFACDFG
// 0xa0 BGGHFDHDDDFEDHH BBHGHCHFABCEFBH
// 0xa8 PlayerTranslationParameters translationParameters
// 0xb0 FHGFGHACABBBFFC translationData
// 0xb8 AFDBCGFGCBHCHED CEBCGBFBDHACECH
// 0xc0 Transform characterTransform
// 0xc8 MecanimController HFEAAGEDHCAFECA
// 0xd0 float FEAAGCFFGCEHCCE
struct MovementController {
    Il2CppObject obj;
    static void* (*get_PlayerController)(void* mc);
    static void* (*get_CharacterController)(void* mc);
    static void* (*get_Transform)(void* mc);
    static void* (*get_MecanimController)(void* mc);
    static void* (*get_PlayerOcclusionController)(void* mc);
    static float (*get_Speed)(void* mc);
    static float (*get_JumpForce)(void* mc);
    static float (*get_Gravity)(void* mc);
    static bool (*get_IsGrounded)(void* mc);
    static bool (*get_IsMoving)(void* mc);
    static bool (*get_IsSprinting)(void* mc);
    static bool (*get_IsCrouching)(void* mc);
    static void (*set_Speed)(void* mc, float val);
    static void (*set_JumpForce)(void* mc, float val);
    static void (*set_Gravity)(void* mc, float val);
    static void (*Move)(void* mc, Vector3 direction);
    static void (*Jump)(void* mc);
    static void (*Sprint)(void* mc, bool val);
    static void (*Crouch)(void* mc, bool val);
};

// ==================== MECANIM CONTROLLER ====================
struct MecanimController {
    Il2CppObject obj;
    static void* (*get_Animator)(void* mc);
    static void* (*get_Transform)(void* mc);
    static void (*SetBool)(void* mc, Il2CppString* name, bool val);
    static void (*SetFloat)(void* mc, Il2CppString* name, float val);
    static void (*SetInteger)(void* mc, Il2CppString* name, int val);
    static void (*SetTrigger)(void* mc, Il2CppString* name);
    static bool (*GetBool)(void* mc, Il2CppString* name);
    static float (*GetFloat)(void* mc, Il2CppString* name);
    static int (*GetInteger)(void* mc, Il2CppString* name);
    static void* (*GetBoneTransform)(void* mc, int humanBoneId);
    static void (*PlayState)(void* mc, Il2CppString* stateName);
};

// ==================== PLAYER HIT CONTROLLER ====================
struct PlayerHitController {
    Il2CppObject obj;
    static void* (*get_PlayerController)(void* phc);
    static void* (*get_Hitboxes)(void* phc);
    static void* (*GetHitboxByBone)(void* phc, Bip bone);
    static Vector3 (*GetHitboxPosition)(void* phc, Bip bone);
    static float (*GetHitboxDamageMult)(void* phc, Bip bone);
    static void (*ApplyDamage)(void* phc, float damage, void* attacker);
    static void (*SetGodMode)(void* phc, bool val);
    static bool (*get_IsGodMode)(void* phc);
};

// ==================== DAMAGE EFFECT CONTROLLER ====================
struct DamageEffectController {
    Il2CppObject obj;
    static void (*ApplyDamage)(void* dec, float damage, void* attacker, int damageType);
    static void (*ApplyHeal)(void* dec, float amount);
    static void (*SetInvincible)(void* dec, bool val);
    static bool (*get_IsInvincible)(void* dec);
    static float (*get_LastDamageTime)(void* dec);
};

// ==================== NETWORK CONTROLLER ====================
struct NetworkController {
    Il2CppObject obj;
    static void* (*get_PhotonView)(void* nc);
    static void* (*get_PhotonPlayer)(void* nc);
    static void (*SendRPC)(void* nc, Il2CppString* method, void* target, void* params);
    static void (*SendReliable)(void* nc, void* data);
    static void (*SendUnreliable)(void* nc, void* data);
    static float (*get_Ping)(void* nc);
    static int (*get_ServerTimestamp)(void* nc);
    static bool (*get_IsConnected)(void* nc);
    static bool (*get_IsMasterClient)(void* nc);
};

// ==================== PLAYER MAIN CAMERA ====================
struct PlayerMainCamera {
    Il2CppObject obj;
    static void* (*get_Camera)(void* pmc);
    static void* (*get_Transform)(void* pmc);
    static float (*get_FOV)(void* pmc);
    static void (*set_FOV)(void* pmc, float fov);
    static void (*set_Position)(void* pmc, Vector3 pos);
    static void (*set_Rotation)(void* pmc, Quaternion rot);
    static void (*SetThirdPerson)(void* pmc, bool val);
    static bool (*get_IsThirdPerson)(void* pmc);
};

// ==================== PLAYER FPS CAMERA ====================
struct PlayerFPSCamera {
    Il2CppObject obj;
    static void* (*get_Camera)(void* pfc);
    static void* (*get_Transform)(void* pfc);
    static float (*get_FOV)(void* pfc);
    static void (*set_FOV)(void* pfc, float fov);
    static void (*set_Position)(void* pfc, Vector3 pos);
    static void (*set_Rotation)(void* pfc, Quaternion rot);
    static void (*RecoilKick)(void* pfc, Vector3 kick);
    static void (*ResetRecoil)(void* pfc);
};

// ==================== ANTI-CHEAT ====================
struct AntiCheatManager {
    Il2CppObject obj;
    static void* (*get_Instance)();
    static void (*Report)(void* acm, void* player, int reason);
    static void (*Ban)(void* acm, void* player, int code, int duration);
    static void (*Kick)(void* acm, void* player, Il2CppString* reason);
    static bool (*CheckIntegrity)(void* acm);
    static void (*ScanMemory)(void* acm);
    static void (*VerifySignatures)(void* acm);
    static void (*CheckHooks)(void* acm);
    static void (*SendHeartbeat)(void* acm);
    static void (*SetDetectionLevel)(void* acm, int level);
};

struct Anticheat {
    Il2CppObject obj;
    static void* (*get_Instance)();
    static void (*ReportViolation)(void* ac, int code, void* data);
    static void (*BanPlayer)(void* ac, int code);
    static bool (*IsPlayerBanned)(void* ac, void* player);
    static void (*LogEvent)(void* ac, Il2CppString* eventName, void* data);
    static void (*SendAnalytics)(void* ac, void* data);
};

// ==================== RADAR SYSTEM ====================
struct RadarManager {
    Il2CppObject obj;
    static void* (*get_Instance)();
    static void* (*get_RadarView)(void* rm);
    static void* (*get_MiniMap)(void* rm);
    static void* (*get_FullMap)(void* rm);
    static void (*AddPlayer)(void* rm, void* player);
    static void (*RemovePlayer)(void* rm, void* player);
    static void (*UpdatePlayerPosition)(void* rm, void* player, Vector3 pos);
    static void (*SetVisible)(void* rm, bool val);
    static bool (*get_IsVisible)(void* rm);
    static void (*SetScale)(void* rm, float scale);
    static float (*get_Scale)(void* rm);
};

struct RadarView {
    Il2CppObject obj;
    static void (*DrawPlayer)(void* rv, void* player, Vector2 pos, Color color);
    static void (*DrawLocalPlayer)(void* rv, Vector2 pos);
    static void (*Clear)(void* rv);
    static void (*SetZoom)(void* rv, float zoom);
    static float (*get_Zoom)(void* rv);
};

// ==================== REPORTS / KICK / SPECTATE ====================
struct Reports {
    Il2CppObject obj;
    static void (*SendReport)(void* r, void* target, int reason, Il2CppString* details);
    static void (*BlockReports)(void* r, bool val);
    static bool (*get_AreReportsBlocked)(void* r);
};

struct KickVoteArgs {
    Il2CppObject obj;
    int32_t targetId;
    Il2CppString* reason;
    int32_t votesNeeded;
    int32_t currentVotes;
};

struct SpectateFollowPlayerView {
    Il2CppObject obj;
    static void* (*get_TargetPlayer)(void* spv);
    static void (*set_TargetPlayer)(void* spv, void* player);
    static void (*Follow)(void* spv, void* player);
    static void (*Unfollow)(void* spv);
    static bool (*get_IsFollowing)(void* spv);
    static void (*SetCameraMode)(void* spv, int mode);
};

// ==================== SKIN / INVENTORY SYSTEM ====================
struct SkinManager {
    Il2CppObject obj;
    static void* (*get_Instance)();
    static void (*EquipSkin)(void* sm, int weaponId, int skinId);
    static void (*EquipKnife)(void* sm, int knifeId);
    static void (*EquipGloves)(void* sm, int gloveId);
    static void (*EquipSticker)(void* sm, int slot, int stickerId);
    static void (*ApplyAllSkins)(void* sm);
    static void (*ResetSkins)(void* sm);
    static int (*GetSkinId)(void* sm, int weaponId);
    static int (*GetKnifeId)(void* sm);
    static int (*GetGloveId)(void* sm);
};

struct Inventory {
    Il2CppObject obj;
    static void* (*get_Instance)();
    static void (*AddItem)(void* inv, int itemId, int count);
    static void (*RemoveItem)(void* inv, int itemId, int count);
    static int (*GetItemCount)(void* inv, int itemId);
    static bool (*HasItem)(void* inv, int itemId);
    static void (*Clear)(void* inv);
    static void* (*GetItems)(void* inv);
};

// ==================== SAFE TYPES (Anti-Cheat Protected) ====================
struct SafeFloat {
    float value;
    int32_t salt;
    float Get() const;
    void Set(float val);
};

struct SafeInt {
    int32_t value;
    int32_t salt;
    int32_t Get() const;
    void Set(int32_t val);
};

struct SafeBool {
    bool value;
    int32_t salt;
    bool Get() const;
    void Set(bool val);
};

// ==================== GLOBAL OFFSETS (v0.39.2 ARM64) ====================
namespace Offsets {
    // libil2cpp.so
    constexpr uintptr_t il2cpp_base = 0x0;

    // Assembly-CSharp.dll
    constexpr uintptr_t PlayerController_class = 0x0;
    constexpr uintptr_t PlayerManager_class = 0x0;
    constexpr uintptr_t AimController_class = 0x0;
    constexpr uintptr_t WeaponryController_class = 0x0;
    constexpr uintptr_t GunController_class = 0x0;
    constexpr uintptr_t MovementController_class = 0x0;
    constexpr uintptr_t DamageEffectController_class = 0x0;
    constexpr uintptr_t AntiCheatManager_class = 0x0;
    constexpr uintptr_t RadarManager_class = 0x0;
    constexpr uintptr_t PhotonView_class = 0x0;
    constexpr uintptr_t PhotonPlayer_class = 0x0;
    constexpr uintptr_t Camera_class = 0x0;
    constexpr uintptr_t Transform_class = 0x0;
    constexpr uintptr_t CharacterController_class = 0x0;
    constexpr uintptr_t Animator_class = 0x0;
    constexpr uintptr_t PlayerHitController_class = 0x0;
    constexpr uintptr_t PlayerCharacterView_class = 0x0;
    constexpr uintptr_t NetworkController_class = 0x0;
    constexpr uintptr_t PlayerMainCamera_class = 0x0;
    constexpr uintptr_t PlayerFPSCamera_class = 0x0;
    constexpr uintptr_t MecanimController_class = 0x0;
    constexpr uintptr_t SkinManager_class = 0x0;
    constexpr uintptr_t Inventory_class = 0x0;
    constexpr uintptr_t Reports_class = 0x0;
    constexpr uintptr_t SpectateFollowPlayerView_class = 0x0;

    // PlayerController field offsets
    constexpr uintptr_t PC_mainCameraHolder = 0x28;
    constexpr uintptr_t PC_fpsCameraHolder = 0x30;
    constexpr uintptr_t PC_fpsDirective = 0x38;
    constexpr uintptr_t PC_characterView1 = 0x48;
    constexpr uintptr_t PC_characterView2 = 0x50;
    constexpr uintptr_t PC_boolFlag1 = 0x78;
    constexpr uintptr_t PC_team = 0x79;
    constexpr uintptr_t PC_floatVal1 = 0x7c;
    constexpr uintptr_t PC_aimController = 0x80;
    constexpr uintptr_t PC_weaponryController = 0x88;
    constexpr uintptr_t PC_mecanimController = 0x90;
    constexpr uintptr_t PC_movementController = 0x98;
    constexpr uintptr_t PC_armsAnimationController = 0xa0;
    constexpr uintptr_t PC_playerHitController = 0xa8;
    constexpr uintptr_t PC_playerMaterialController = 0xb0;
    constexpr uintptr_t PC_playerOcclusionController = 0xb8;
    constexpr uintptr_t PC_networkController = 0xc0;
    constexpr uintptr_t PC_armsLodGroup = 0xc8;
    constexpr uintptr_t PC_characterView3 = 0xd0;
    constexpr uintptr_t PC_boolFlag2 = 0xd8;
    constexpr uintptr_t PC_boolFlag3 = 0xd9;
    constexpr uintptr_t PC_floatVal2 = 0xdc;
    constexpr uintptr_t PC_playerSoundController = 0xe0;
    constexpr uintptr_t PC_playerMainCamera = 0xe8;
    constexpr uintptr_t PC_playerFPSCamera = 0xf0;
    constexpr uintptr_t PC_markerTrigger = 0xf8;
    constexpr uintptr_t PC_transform2 = 0x100;
    constexpr uintptr_t PC_controllers = 0x108;
    constexpr uintptr_t PC_controllerDict = 0x110;
    constexpr uintptr_t PC_characterController = 0x118;
    constexpr uintptr_t PC_skinnedMeshLodGroup = 0x120;
    constexpr uintptr_t PC_characterLodGroup = 0x128;
    constexpr uintptr_t PC_boolFlag4 = 0x130;
    constexpr uintptr_t PC_boolFlag5 = 0x131;
    constexpr uintptr_t PC_photonView = 0x150;
    constexpr uintptr_t PC_health = 0x158;
    constexpr uintptr_t PC_armor = 0x15c;
    constexpr uintptr_t PC_photonPlayer = 0x160;

    // PlayerManager offsets
    constexpr uintptr_t PM_instance = 0x0;
    constexpr uintptr_t PM_playerDict = 0x28;
    constexpr uintptr_t PM_playerHashSet = 0x38;
    constexpr uintptr_t PM_localPlayer1 = 0x68;
    constexpr uintptr_t PM_localPlayer2 = 0x70;

    // AimController offsets
    constexpr uintptr_t AC_overrideSpineRotation = 0x53;
    constexpr uintptr_t AC_sensitivityX = 0x58;
    constexpr uintptr_t AC_sensitivityY = 0x5c;
    constexpr uintptr_t AC_minimumX = 0x60;
    constexpr uintptr_t AC_maximumX = 0x64;
    constexpr uintptr_t AC_FPSP_go = 0x68;
    constexpr uintptr_t AC_spineDirector = 0x70;
    constexpr uintptr_t AC_FPSCamera = 0x78;
    constexpr uintptr_t AC_camTransform = 0x80;
    constexpr uintptr_t AC_aimingParameters = 0x88;
    constexpr uintptr_t AC_aimingData = 0x90;
    constexpr uintptr_t AC_interpolatorsBunch = 0x98;
    constexpr uintptr_t AC_tuningParams = 0xa0;
    constexpr uintptr_t AC_headDampingSpeed = 0xa8;
    constexpr uintptr_t AC_playerController = 0xb0;
    constexpr uintptr_t AC_movementController = 0xb8;
    constexpr uintptr_t AC_transform = 0xc0;
    constexpr uintptr_t AC_mecanimController = 0xc8;

    // WeaponryController offsets
    constexpr uintptr_t WC_weaponDict = 0x58;
    constexpr uintptr_t WC_weaponList = 0x60;
    constexpr uintptr_t WC_slotList = 0x68;
    constexpr uintptr_t WC_playerController = 0x78;
    constexpr uintptr_t WC_mecanimController = 0x80;
    constexpr uintptr_t WC_currentSlot = 0x88;
    constexpr uintptr_t WC_boolFlag1 = 0x89;
    constexpr uintptr_t WC_weaponPickupController = 0x90;
    constexpr uintptr_t WC_kitController = 0x98;
    constexpr uintptr_t WC_currentWeapon = 0xa0;
    constexpr uintptr_t WC_boolFlag2 = 0xa8;
    constexpr uintptr_t WC_boolFlag3 = 0xa9;
    constexpr uintptr_t WC_floatVal1 = 0xac;
    constexpr uintptr_t WC_floatVal2 = 0xb0;
    constexpr uintptr_t WC_weaponManager = 0xb8;

    // GunController offsets
    constexpr uintptr_t GC_field100 = 0x100;
    constexpr uintptr_t GC_safeFloat1 = 0x108;
    constexpr uintptr_t GC_safeFloat2 = 0x110;
    constexpr uintptr_t GC_int1 = 0x118;
    constexpr uintptr_t GC_int2 = 0x11c;
    constexpr uintptr_t GC_safeInt1 = 0x120;
    constexpr uintptr_t GC_safeInt2 = 0x128;
    constexpr uintptr_t GC_safeBool1 = 0x130;
    constexpr uintptr_t GC_safeBool2 = 0x138;
    constexpr uintptr_t GC_gunSoundController = 0x140;
    constexpr uintptr_t GC_shootingLoopState = 0x148;
    constexpr uintptr_t GC_field150 = 0x150;
    constexpr uintptr_t GC_gunParameters = 0x168;
    constexpr uintptr_t GC_field170 = 0x170;
    constexpr uintptr_t GC_float1 = 0x178;
    constexpr uintptr_t GC_float2 = 0x17c;
    constexpr uintptr_t GC_field180 = 0x180;
    constexpr uintptr_t GC_transform1 = 0x1c0;
    constexpr uintptr_t GC_transform2 = 0x1c8;
    constexpr uintptr_t GC_transform3 = 0x1d0;
    constexpr uintptr_t GC_gunSoundParams = 0x1d8;
    constexpr uintptr_t GC_float3 = 0x1e0;
    constexpr uintptr_t GC_float4 = 0x1e4;
    constexpr uintptr_t GC_int3 = 0x1e8;
    constexpr uintptr_t GC_safeFloat3 = 0x1ec;
    constexpr uintptr_t GC_safeFloat4 = 0x1f4;

    // MovementController offsets
    constexpr uintptr_t MC_playerController = 0x58;
    constexpr uintptr_t MC_playerOcclusionController = 0x60;
    constexpr uintptr_t MC_neverIdle = 0x68;
    constexpr uintptr_t MC_transform = 0x70;
    constexpr uintptr_t MC_field78 = 0x78;
    constexpr uintptr_t MC_speed = 0x80;
    constexpr uintptr_t MC_float2 = 0x84;
    constexpr uintptr_t MC_characterController = 0x88;
    constexpr uintptr_t MC_trigger = 0x90;
    constexpr uintptr_t MC_array1 = 0x98;
    constexpr uintptr_t MC_fieldA0 = 0xa0;
    constexpr uintptr_t MC_translationParams = 0xa8;
    constexpr uintptr_t MC_translationData = 0xb0;
    constexpr uintptr_t MC_fieldB8 = 0xb8;
    constexpr uintptr_t MC_characterTransform = 0xc0;
    constexpr uintptr_t MC_mecanimController = 0xc8;
    constexpr uintptr_t MC_float3 = 0xd0;

    // AntiCheat offsets
    constexpr uintptr_t ACM_instance = 0x0;
    constexpr uintptr_t ACM_detectionLevel = 0x20;
    constexpr uintptr_t ACM_heartbeatInterval = 0x24;
    constexpr uintptr_t ACM_lastScan = 0x28;

    // PhotonView offsets
    constexpr uintptr_t PV_viewID = 0x28;
    constexpr uintptr_t PV_owner = 0x30;
    constexpr uintptr_t PV_isMine = 0x38;

    // PhotonPlayer offsets
    constexpr uintptr_t PP_ID = 0x28;
    constexpr uintptr_t PP_nickName = 0x30;
    constexpr uintptr_t PP_isMasterClient = 0x38;
    constexpr uintptr_t PP_isLocal = 0x39;

    // Camera offsets
    constexpr uintptr_t CAM_main = 0x0;
    constexpr uintptr_t CAM_fov = 0x48;
    constexpr uintptr_t CAM_nearClip = 0x4c;
    constexpr uintptr_t CAM_farClip = 0x50;
    constexpr uintptr_t CAM_transform = 0x58;

    // Transform offsets
    constexpr uintptr_t TR_position = 0x90;
    constexpr uintptr_t TR_rotation = 0xa0;
    constexpr uintptr_t TR_localPosition = 0xb0;
    constexpr uintptr_t TR_localRotation = 0xc0;
    constexpr uintptr_t TR_localScale = 0xd0;
    constexpr uintptr_t TR_parent = 0xe0;

    // CharacterController offsets
    constexpr uintptr_t CC_velocity = 0x48;
    constexpr uintptr_t CC_isGrounded = 0x50;
    constexpr uintptr_t CC_height = 0x58;
    constexpr uintptr_t CC_radius = 0x5c;
    constexpr uintptr_t CC_center = 0x60;
    constexpr uintptr_t CC_slopeLimit = 0x6c;
    constexpr uintptr_t CC_stepOffset = 0x70;

    // Animator offsets
    constexpr uintptr_t AN_transform = 0x28;
    constexpr uintptr_t AN_controller = 0x30;

    // PlayerHitController offsets
    constexpr uintptr_t PHC_playerController = 0x28;
    constexpr uintptr_t PHC_hitboxes = 0x30;
    constexpr uintptr_t PHC_godMode = 0x38;

    // NetworkController offsets
    constexpr uintptr_t NC_photonView = 0x28;
    constexpr uintptr_t NC_photonPlayer = 0x30;
    constexpr uintptr_t NC_ping = 0x38;
    constexpr uintptr_t NC_serverTimestamp = 0x3c;
    constexpr uintptr_t NC_isConnected = 0x40;
    constexpr uintptr_t NC_isMasterClient = 0x41;

    // PlayerMainCamera offsets
    constexpr uintptr_t PMC_camera = 0x28;
    constexpr uintptr_t PMC_transform = 0x30;
    constexpr uintptr_t PMC_fov = 0x38;
    constexpr uintptr_t PMC_isThirdPerson = 0x3c;

    // PlayerFPSCamera offsets
    constexpr uintptr_t PFC_camera = 0x28;
    constexpr uintptr_t PFC_transform = 0x30;
    constexpr uintptr_t PFC_fov = 0x38;
    constexpr uintptr_t PFC_recoilKick = 0x40;
    constexpr uintptr_t PFC_recoilReset = 0x4c;

    // MecanimController offsets
    constexpr uintptr_t MEC_animator = 0x28;
    constexpr uintptr_t MEC_transform = 0x30;
    constexpr uintptr_t MEC_boneTransforms = 0x38;

    // SkinManager offsets
    constexpr uintptr_t SM_instance = 0x0;
    constexpr uintptr_t SM_equippedSkins = 0x28;
    constexpr uintptr_t SM_equippedKnife = 0x30;
    constexpr uintptr_t SM_equippedGloves = 0x38;
    constexpr uintptr_t SM_equippedStickers = 0x40;

    // Inventory offsets
    constexpr uintptr_t INV_instance = 0x0;
    constexpr uintptr_t INV_items = 0x28;
    constexpr uintptr_t INV_gold = 0x30;
    constexpr uintptr_t INV_credits = 0x38;

    // Reports offsets
    constexpr uintptr_t REP_instance = 0x0;
    constexpr uintptr_t REP_reportsBlocked = 0x28;
    constexpr uintptr_t REP_reportQueue = 0x30;

    // SpectateFollowPlayerView offsets
    constexpr uintptr_t SPV_targetPlayer = 0x28;
    constexpr uintptr_t SPV_isFollowing = 0x30;
    constexpr uintptr_t SPV_cameraMode = 0x34;
}

} // namespace IL2CPP
