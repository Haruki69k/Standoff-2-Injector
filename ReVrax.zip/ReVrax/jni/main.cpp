#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <cstdlib>
#include <cstring>

#include "il2cpp_structs.h"
#include "utils/memory.h"
#include "utils/logger.h"
#include "hooks/hooks.h"
#include "menu/menu.h"
#include "anti_ban/anti_ban.h"

// ==================== GLOBALS ====================
static JavaVM* g_JavaVM = nullptr;
static jobject g_MainActivity = nullptr;
static jobject g_FloatingService = nullptr;
static pthread_t g_RenderThread = 0;
static bool g_Running = false;
static bool g_SurfaceReady = false;
static ANativeWindow* g_NativeWindow = nullptr;

// EGL
static EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
static EGLSurface g_EglSurface = EGL_NO_SURFACE;
static EGLContext g_EglContext = EGL_NO_CONTEXT;
static EGLConfig g_EglConfig;

// ImGui
static bool g_ImGuiInitialized = false;

// ==================== FORWARD DECLARATIONS ====================
static void* RenderThread(void* arg);
static bool InitializeEGL();
static void ShutdownEGL();
static bool InitializeImGui();
static void ShutdownImGui();
static void RenderFrame();

// ==================== JNI FUNCTIONS ====================

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("[ReVrax] JNI_OnLoad called");
    g_JavaVM = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL
Java_com_revrax_MainActivity_nativeInit(JNIEnv* env, jobject thiz) {
    LOGI("[ReVrax] Native init called");
    g_MainActivity = env->NewGlobalRef(thiz);

    // Initialize anti-ban first
    ReVrax::AntiBan::InitializeAntiBan();

    // Initialize hooks
    S2::InitializeHooks();

    LOGI("[ReVrax] Native init complete");
}

extern "C" JNIEXPORT void JNICALL
Java_com_revrax_MainActivity_nativeShutdown(JNIEnv* env, jobject thiz) {
    LOGI("[ReVrax] Native shutdown called");
    g_Running = false;

    if (g_RenderThread) {
        pthread_join(g_RenderThread, nullptr);
        g_RenderThread = 0;
    }

    S2::ShutdownHooks();
    ReVrax::AntiBan::ShutdownAntiBan();

    if (g_MainActivity) {
        env->DeleteGlobalRef(g_MainActivity);
        g_MainActivity = nullptr;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_revrax_FloatingService_nativeStartRender(JNIEnv* env, jobject thiz, jobject surface) {
    LOGI("[ReVrax] Starting render thread...");

    g_FloatingService = env->NewGlobalRef(thiz);
    g_NativeWindow = ANativeWindow_fromSurface(env, surface);
    g_SurfaceReady = true;
    g_Running = true;

    pthread_create(&g_RenderThread, nullptr, RenderThread, nullptr);
}

extern "C" JNIEXPORT void JNICALL
Java_com_revrax_FloatingService_nativeStopRender(JNIEnv* env, jobject thiz) {
    LOGI("[ReVrax] Stopping render thread...");
    g_Running = false;
    g_SurfaceReady = false;

    if (g_RenderThread) {
        pthread_join(g_RenderThread, nullptr);
        g_RenderThread = 0;
    }

    if (g_NativeWindow) {
        ANativeWindow_release(g_NativeWindow);
        g_NativeWindow = nullptr;
    }

    if (g_FloatingService) {
        env->DeleteGlobalRef(g_FloatingService);
        g_FloatingService = nullptr;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_revrax_FloatingService_nativeToggleMenu(JNIEnv* env, jobject thiz) {
    ReVrax::Menu::g_ShowMenu = !ReVrax::Menu::g_ShowMenu;
    LOGI("[ReVrax] Menu toggled: %s", ReVrax::Menu::g_ShowMenu ? "ON" : "OFF");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_revrax_FloatingService_nativeIsMenuVisible(JNIEnv* env, jobject thiz) {
    return ReVrax::Menu::g_ShowMenu ? JNI_TRUE : JNI_FALSE;
}

// ==================== RENDER THREAD ====================

static void* RenderThread(void* arg) {
    LOGI("[ReVrax] Render thread started");

    // Wait for surface
    int waitCount = 0;
    while (!g_SurfaceReady && waitCount < 100) {
        usleep(10000); // 10ms
        waitCount++;
    }

    if (!g_SurfaceReady) {
        LOGE("[ReVrax] Surface not ready, exiting render thread");
        return nullptr;
    }

    // Initialize EGL
    if (!InitializeEGL()) {
        LOGE("[ReVrax] EGL initialization failed");
        return nullptr;
    }

    // Initialize ImGui
    if (!InitializeImGui()) {
        LOGE("[ReVrax] ImGui initialization failed");
        ShutdownEGL();
        return nullptr;
    }

    LOGI("[ReVrax] Render loop starting...");

    // Main render loop
    while (g_Running) {
        // Poll ImGui input
        ImGuiIO& io = ImGui::GetIO();

        // Start frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();

        // Run anti-ban loop
        ReVrax::AntiBan::RunAntiBanLoop();

        // Update cheat features
        S2::UpdateAll();

        // Render menu
        ReVrax::Menu::RenderMenu();

        // Render
        ImGui::Render();

        glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        eglSwapBuffers(g_EglDisplay, g_EglSurface);

        // Small delay to prevent excessive CPU usage
        usleep(16000); // ~60 FPS
    }

    LOGI("[ReVrax] Render loop ended");

    ShutdownImGui();
    ShutdownEGL();

    return nullptr;
}

// ==================== EGL ====================

static bool InitializeEGL() {
    LOGI("[ReVrax] Initializing EGL...");

    g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g_EglDisplay == EGL_NO_DISPLAY) {
        LOGE("[ReVrax] eglGetDisplay failed");
        return false;
    }

    EGLint major, minor;
    if (!eglInitialize(g_EglDisplay, &major, &minor)) {
        LOGE("[ReVrax] eglInitialize failed");
        return false;
    }
    LOGI("[ReVrax] EGL version: %d.%d", major, minor);

    // Choose config
    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };

    EGLint numConfigs;
    eglChooseConfig(g_EglDisplay, attribs, &g_EglConfig, 1, &numConfigs);
    if (numConfigs < 1) {
        LOGE("[ReVrax] eglChooseConfig failed");
        return false;
    }

    // Create surface
    g_EglSurface = eglCreateWindowSurface(g_EglDisplay, g_EglConfig, g_NativeWindow, nullptr);
    if (g_EglSurface == EGL_NO_SURFACE) {
        LOGE("[ReVrax] eglCreateWindowSurface failed");
        return false;
    }

    // Create context
    const EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
    };
    g_EglContext = eglCreateContext(g_EglDisplay, g_EglConfig, EGL_NO_CONTEXT, contextAttribs);
    if (g_EglContext == EGL_NO_CONTEXT) {
        LOGE("[ReVrax] eglCreateContext failed");
        return false;
    }

    // Make current
    if (!eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext)) {
        LOGE("[ReVrax] eglMakeCurrent failed");
        return false;
    }

    // Set swap interval
    eglSwapInterval(g_EglDisplay, 0);

    LOGI("[ReVrax] EGL initialized successfully");
    return true;
}

static void ShutdownEGL() {
    LOGI("[ReVrax] Shutting down EGL...");

    eglMakeCurrent(g_EglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

    if (g_EglContext != EGL_NO_CONTEXT) {
        eglDestroyContext(g_EglDisplay, g_EglContext);
        g_EglContext = EGL_NO_CONTEXT;
    }

    if (g_EglSurface != EGL_NO_SURFACE) {
        eglDestroySurface(g_EglDisplay, g_EglSurface);
        g_EglSurface = EGL_NO_SURFACE;
    }

    if (g_EglDisplay != EGL_NO_DISPLAY) {
        eglTerminate(g_EglDisplay);
        g_EglDisplay = EGL_NO_DISPLAY;
    }

    LOGI("[ReVrax] EGL shutdown complete");
}

// ==================== IMGUI ====================

static bool InitializeImGui() {
    LOGI("[ReVrax] Initializing ImGui...");

    if (!ReVrax::Menu::InitializeMenu()) {
        return false;
    }

    // Get window size
    EGLint width, height;
    eglQuerySurface(g_EglDisplay, g_EglSurface, EGL_WIDTH, &width);
    eglQuerySurface(g_EglDisplay, g_EglSurface, EGL_HEIGHT, &height);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)width, (float)height);
    io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);

    // Setup input
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    // Initialize backends
    ImGui_ImplAndroid_Init(nullptr);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    g_ImGuiInitialized = true;
    LOGI("[ReVrax] ImGui initialized successfully");
    return true;
}

static void ShutdownImGui() {
    LOGI("[ReVrax] Shutting down ImGui...");

    ReVrax::Menu::ShutdownMenu();
    g_ImGuiInitialized = false;

    LOGI("[ReVrax] ImGui shutdown complete");
}

// ==================== IL2CPP RESOLUTION ====================

static bool ResolveIl2CppFunctions() {
    LOGI("[ReVrax] Resolving IL2CPP functions...");

    // Get il2cpp base
    uintptr_t il2cppBase = Mem::GetBaseAddress("libil2cpp.so");
    if (!il2cppBase) {
        LOGE("[ReVrax] libil2cpp.so not found");
        return false;
    }
    LOGI("[ReVrax] libil2cpp.so base: 0x%llx", (unsigned long long)il2cppBase);

    // Resolve functions via pattern scanning or export table
    // In production, use il2cpp API or Dobby hook with resolved addresses

    // Placeholder: would resolve all function pointers here
    // PlayerController::get_Health = (int(*)(void*))Mem::FindPattern("libil2cpp.so", "...", "...");
    // ... etc

    LOGI("[ReVrax] IL2CPP functions resolved");
    return true;
}

// ==================== ENTRY POINT ====================

__attribute__((constructor))
static void ReVraxEntry() {
    LOGI("[ReVrax] Entry point called");

    // Wait for game to load
    int waitCount = 0;
    while (Mem::GetBaseAddress("libil2cpp.so") == 0 && waitCount < 300) {
        usleep(100000); // 100ms
        waitCount++;
    }

    if (Mem::GetBaseAddress("libil2cpp.so") == 0) {
        LOGE("[ReVrax] libil2cpp.so not loaded after timeout");
        return;
    }

    LOGI("[ReVrax] Game loaded, initializing...");

    // Resolve IL2CPP
    if (!ResolveIl2CppFunctions()) {
        LOGE("[ReVrax] Failed to resolve IL2CPP functions");
        return;
    }

    // Initialize anti-ban
    ReVrax::AntiBan::InitializeAntiBan();

    // Initialize hooks
    if (!S2::InitializeHooks()) {
        LOGE("[ReVrax] Failed to initialize hooks");
        return;
    }

    LOGI("[ReVrax] Initialization complete");
}
