#include "menu.h"
#include "../anti_ban/anti_ban.h"
#include "../utils/logger.h"

namespace ReVrax {
namespace Menu {

bool g_ShowMenu = true;
bool g_Initialized = false;
float g_MenuAlpha = 0.95f;
ImVec2 g_MenuPos = ImVec2(50, 50);
ImVec2 g_MenuSize = ImVec2(600, 500);
MenuTab g_CurrentTab = MenuTab::Visual;

// Purple theme colors
ImVec4 g_ColorPrimary      = ImVec4(0.40f, 0.00f, 0.80f, 1.00f); // #6600CC
ImVec4 g_ColorSecondary    = ImVec4(0.55f, 0.20f, 0.90f, 1.00f); // #8C33E6
ImVec4 g_ColorAccent       = ImVec4(0.70f, 0.40f, 1.00f, 1.00f); // #B366FF
ImVec4 g_ColorBackground   = ImVec4(0.08f, 0.08f, 0.12f, 1.00f); // #14141F
ImVec4 g_ColorForeground   = ImVec4(0.12f, 0.12f, 0.18f, 1.00f); // #1E1E2E
ImVec4 g_ColorText         = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // #FFFFFF
ImVec4 g_ColorTextDim      = ImVec4(0.60f, 0.60f, 0.70f, 1.00f); // #9999B3
ImVec4 g_ColorBorder       = ImVec4(0.25f, 0.10f, 0.40f, 1.00f); // #401A66
ImVec4 g_ColorSuccess      = ImVec4(0.20f, 0.80f, 0.20f, 1.00f); // #33CC33
ImVec4 g_ColorWarning      = ImVec4(1.00f, 0.80f, 0.00f, 1.00f); // #FFCC00
ImVec4 g_ColorDanger       = ImVec4(1.00f, 0.20f, 0.20f, 1.00f); // #FF3333
ImVec4 g_ColorExtreme      = ImVec4(0.60f, 0.00f, 0.00f, 1.00f); // #990000

// ==================== INIT / SHUTDOWN ====================

bool InitializeMenu() {
    LOGI("[Menu] Initializing ImGui...");

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr; // Disable .ini file

    ApplyTheme();

    g_Initialized = true;
    LOGI("[Menu] ImGui initialized");
    return true;
}

void ShutdownMenu() {
    if (g_Initialized) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
        g_Initialized = false;
    }
}

void ApplyTheme() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // Window
    colors[ImGuiCol_WindowBg]             = ImVec4(g_ColorBackground.x, g_ColorBackground.y, g_ColorBackground.z, g_MenuAlpha);
    colors[ImGuiCol_ChildBg]                = g_ColorForeground;
    colors[ImGuiCol_PopupBg]                = ImVec4(g_ColorBackground.x, g_ColorBackground.y, g_ColorBackground.z, 0.98f);

    // Borders
    colors[ImGuiCol_Border]                 = g_ColorBorder;
    colors[ImGuiCol_BorderShadow]           = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

    // Text
    colors[ImGuiCol_Text]                   = g_ColorText;
    colors[ImGuiCol_TextDisabled]           = g_ColorTextDim;
    colors[ImGuiCol_TextSelectedBg]         = g_ColorPrimary;

    // Buttons
    colors[ImGuiCol_Button]                 = g_ColorPrimary;
    colors[ImGuiCol_ButtonHovered]          = g_ColorSecondary;
    colors[ImGuiCol_ButtonActive]           = g_ColorAccent;

    // Headers
    colors[ImGuiCol_Header]                 = g_ColorPrimary;
    colors[ImGuiCol_HeaderHovered]          = g_ColorSecondary;
    colors[ImGuiCol_HeaderActive]           = g_ColorAccent;

    // Frames
    colors[ImGuiCol_FrameBg]                = g_ColorForeground;
    colors[ImGuiCol_FrameBgHovered]         = ImVec4(g_ColorForeground.x + 0.05f, g_ColorForeground.y + 0.05f, g_ColorForeground.z + 0.05f, 1.0f);
    colors[ImGuiCol_FrameBgActive]          = g_ColorPrimary;

    // Sliders
    colors[ImGuiCol_SliderGrab]             = g_ColorAccent;
    colors[ImGuiCol_SliderGrabActive]       = g_ColorSecondary;

    // Checkboxes
    colors[ImGuiCol_CheckMark]              = g_ColorAccent;

    // Tabs
    colors[ImGuiCol_Tab]                    = g_ColorForeground;
    colors[ImGuiCol_TabHovered]             = g_ColorSecondary;
    colors[ImGuiCol_TabActive]              = g_ColorPrimary;
    colors[ImGuiCol_TabUnfocused]           = g_ColorForeground;
    colors[ImGuiCol_TabUnfocusedActive]     = g_ColorPrimary;

    // Scrollbar
    colors[ImGuiCol_ScrollbarBg]            = g_ColorBackground;
    colors[ImGuiCol_ScrollbarGrab]          = g_ColorPrimary;
    colors[ImGuiCol_ScrollbarGrabHovered]   = g_ColorSecondary;
    colors[ImGuiCol_ScrollbarGrabActive]    = g_ColorAccent;

    // Title
    colors[ImGuiCol_TitleBg]                = g_ColorPrimary;
    colors[ImGuiCol_TitleBgActive]          = g_ColorSecondary;
    colors[ImGuiCol_TitleBgCollapsed]       = g_ColorBackground;

    // Resize grip
    colors[ImGuiCol_ResizeGrip]             = g_ColorPrimary;
    colors[ImGuiCol_ResizeGripHovered]      = g_ColorSecondary;
    colors[ImGuiCol_ResizeGripActive]       = g_ColorAccent;

    // Plot
    colors[ImGuiCol_PlotLines]              = g_ColorAccent;
    colors[ImGuiCol_PlotLinesHovered]       = g_ColorSecondary;
    colors[ImGuiCol_PlotHistogram]          = g_ColorPrimary;
    colors[ImGuiCol_PlotHistogramHovered]   = g_ColorSecondary;

    // Style settings
    style.WindowRounding    = 8.0f;
    style.ChildRounding     = 6.0f;
    style.FrameRounding     = 4.0f;
    style.GrabRounding      = 4.0f;
    style.PopupRounding     = 6.0f;
    style.ScrollbarRounding = 4.0f;
    style.TabRounding       = 4.0f;

    style.WindowBorderSize  = 1.0f;
    style.FrameBorderSize   = 0.0f;
    style.PopupBorderSize   = 1.0f;

    style.WindowPadding     = ImVec2(12, 12);
    style.FramePadding      = ImVec2(8, 6);
    style.ItemSpacing       = ImVec2(8, 6);
    style.ItemInnerSpacing  = ImVec2(6, 4);
    style.IndentSpacing     = 20.0f;
    style.ScrollbarSize     = 10.0f;
    style.GrabMinSize       = 10.0f;
}

// ==================== HELPER WIDGETS ====================

void RiskBadge(S2::BanRisk risk) {
    const char* label = "SAFE";
    ImVec4 color = g_ColorSuccess;

    switch (risk) {
        case S2::BanRisk::SAFE:
            label = "SAFE";
            color = g_ColorSuccess;
            break;
        case S2::BanRisk::MEDIUM:
            label = "MEDIUM";
            color = g_ColorWarning;
            break;
        case S2::BanRisk::DANGEROUS:
            label = "DANGEROUS";
            color = g_ColorDanger;
            break;
        case S2::BanRisk::EXTREME:
            label = "EXTREME";
            color = g_ColorExtreme;
            break;
    }

    ImGui::SameLine();
    ImGui::PushStyleColor(ImGuiCol_Button, color);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, color);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, color);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0,0,0,1));
    ImGui::SmallButton(label);
    ImGui::PopStyleColor(4);
}

bool ToggleButton(const char* label, bool* value) {
    bool changed = ImGui::Checkbox(label, value);
    return changed;
}

bool SliderFloat(const char* label, float* value, float min, float max, const char* format) {
    return ImGui::SliderFloat(label, value, min, max, format);
}

bool SliderInt(const char* label, int* value, int min, int max) {
    return ImGui::SliderInt(label, value, min, max);
}

bool ColorPicker(const char* label, Color* color) {
    float col[4] = { color->r, color->g, color->b, color->a };
    bool changed = ImGui::ColorEdit4(label, col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel);
    if (changed) {
        color->r = col[0];
        color->g = col[1];
        color->b = col[2];
        color->a = col[3];
    }
    return changed;
}

bool ComboBox(const char* label, int* current, const char* items[], int itemsCount) {
    bool changed = false;
    if (ImGui::BeginCombo(label, items[*current])) {
        for (int i = 0; i < itemsCount; i++) {
            bool isSelected = (*current == i);
            if (ImGui::Selectable(items[i], isSelected)) {
                *current = i;
                changed = true;
            }
            if (isSelected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    return changed;
}

void SectionHeader(const char* label, S2::BanRisk risk) {
    ImGui::Separator();
    ImGui::Text("%s", label);
    RiskBadge(risk);
    ImGui::Spacing();
}

void SeparatorLine() {
    ImGui::Separator();
}

// ==================== RENDER MENU ====================

void RenderMenu() {
    if (!g_ShowMenu) return;

    ImGui::SetNextWindowPos(g_MenuPos, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(g_MenuSize, ImGuiCond_FirstUseEver);

    ImGui::Begin("ReVrax v2.0 | Standoff 2 v0.39.2", &g_ShowMenu,
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar);

    // Tab bar
    if (ImGui::BeginTabBar("MainTabs", ImGuiTabBarFlags_FittingPolicyScroll)) {
        if (ImGui::BeginTabItem("Visual")) { g_CurrentTab = MenuTab::Visual; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("ESP")) { g_CurrentTab = MenuTab::ESP; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Aimbot")) { g_CurrentTab = MenuTab::Aimbot; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Weapon")) { g_CurrentTab = MenuTab::Weapon; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Movement")) { g_CurrentTab = MenuTab::Movement; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Combat")) { g_CurrentTab = MenuTab::Combat; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Skins")) { g_CurrentTab = MenuTab::Skins; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Economy")) { g_CurrentTab = MenuTab::Economy; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Spoof")) { g_CurrentTab = MenuTab::Spoof; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Radar")) { g_CurrentTab = MenuTab::Radar; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Misc")) { g_CurrentTab = MenuTab::Misc; ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("About")) { g_CurrentTab = MenuTab::About; ImGui::EndTabItem(); }
        ImGui::EndTabBar();
    }

    ImGui::Spacing();

    // Render current tab
    switch (g_CurrentTab) {
        case MenuTab::Visual:   RenderVisualTab(); break;
        case MenuTab::ESP:      RenderESPTab(); break;
        case MenuTab::Aimbot:   RenderAimbotTab(); break;
        case MenuTab::Weapon:   RenderWeaponTab(); break;
        case MenuTab::Movement: RenderMovementTab(); break;
        case MenuTab::Combat:   RenderCombatTab(); break;
        case MenuTab::Skins:    RenderSkinsTab(); break;
        case MenuTab::Economy:  RenderEconomyTab(); break;
        case MenuTab::Spoof:    RenderSpoofTab(); break;
        case MenuTab::Radar:    RenderRadarTab(); break;
        case MenuTab::Misc:     RenderMiscTab(); break;
        case MenuTab::About:    RenderAboutTab(); break;
    }

    ImGui::End();
}

// ==================== TAB RENDERERS ====================

void RenderVisualTab() {
    ImGui::BeginChild("VisualScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Visual Modifications", S2::BanRisk::SAFE);
    ToggleButton("Enable Visual", &S2::g_Config.Visual.enabled);
    ToggleButton("Custom FOV", &S2::g_Config.Visual.enabled);
    SliderFloat("FOV", &S2::g_Config.Visual.fov, 30.0f, 150.0f);
    ToggleButton("Third Person", &S2::g_Config.Visual.thirdPerson);
    SliderFloat("ViewModel FOV", &S2::g_Config.Visual.viewModelFov, 30.0f, 120.0f);
    ToggleButton("No Flash", &S2::g_Config.Visual.noFlash);
    ToggleButton("No Smoke", &S2::g_Config.Visual.noSmoke);
    ToggleButton("Bright Mode", &S2::g_Config.Visual.brightMode);
    ToggleButton("Remove Scope Blur", &S2::g_Config.Visual.removeScopeBlur);
    ToggleButton("Custom Crosshair", &S2::g_Config.Visual.customCrosshair);
    SliderFloat("Crosshair Size", &S2::g_Config.Visual.crosshairSize, 1.0f, 20.0f);
    ColorPicker("Crosshair Color", &S2::g_Config.Visual.crosshairColor);
    ToggleButton("Night Mode", &S2::g_Config.Visual.nightMode);
    SliderFloat("Night Intensity", &S2::g_Config.Visual.nightModeIntensity, 0.0f, 1.0f);
    ToggleButton("Full Bright", &S2::g_Config.Visual.fullBright);
    ToggleButton("Disable Fog", &S2::g_Config.Visual.disableFog);
    ToggleButton("Disable Bloom", &S2::g_Config.Visual.disableBloom);
    ToggleButton("Disable Motion Blur", &S2::g_Config.Visual.disableMotionBlur);
    ToggleButton("Disable Depth of Field", &S2::g_Config.Visual.disableDepthOfField);
    ToggleButton("Wireframe Mode", &S2::g_Config.Visual.wireframeMode);

    SectionHeader("Chams", S2::BanRisk::SAFE);
    ToggleButton("Enable Chams", &S2::g_Config.Visual.chamsEnabled);
    ColorPicker("Chams Color", &S2::g_Config.Visual.chamsColor);
    ToggleButton("Visible Only", &S2::g_Config.Visual.chamsVisibleOnly);
    ToggleButton("Rainbow Chams", &S2::g_Config.Visual.chamsRainbow);

    ImGui::EndChild();
}

void RenderESPTab() {
    ImGui::BeginChild("ESPScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("ESP Settings", S2::BanRisk::MEDIUM);
    ToggleButton("Enable ESP", &S2::g_Config.ESP.enabled);
    ToggleButton("Box", &S2::g_Config.ESP.box);
    ToggleButton("Skeleton", &S2::g_Config.ESP.skeleton);
    ToggleButton("Name", &S2::g_Config.ESP.name);
    ToggleButton("Health", &S2::g_Config.ESP.health);
    ToggleButton("Armor", &S2::g_Config.ESP.armor);
    ToggleButton("Distance", &S2::g_Config.ESP.distance);
    ToggleButton("Weapon", &S2::g_Config.ESP.weapon);
    ToggleButton("Team Check", &S2::g_Config.ESP.teamCheck);
    ToggleButton("Visible Only", &S2::g_Config.ESP.visibleOnly);
    SliderFloat("Max Distance", &S2::g_Config.ESP.maxDistance, 10.0f, 500.0f);

    SectionHeader("ESP Colors", S2::BanRisk::MEDIUM);
    ColorPicker("Enemy Color", &S2::g_Config.ESP.enemyColor);
    ColorPicker("Team Color", &S2::g_Config.ESP.teamColor);
    ColorPicker("Visible Color", &S2::g_Config.ESP.visibleColor);

    SectionHeader("Advanced ESP", S2::BanRisk::MEDIUM);
    ToggleButton("Snaplines", &S2::g_Config.ESP.snaplines);
    ToggleButton("Head Dot", &S2::g_Config.ESP.headDot);
    ToggleButton("Health Bar", &S2::g_Config.ESP.healthBar);
    ToggleButton("Armor Bar", &S2::g_Config.ESP.armorBar);
    ToggleButton("Tracers", &S2::g_Config.ESP.tracers);
    ToggleButton("Off-Screen Arrows", &S2::g_Config.ESP.offScreenArrows);
    ToggleButton("Show Bomb", &S2::g_Config.ESP.showBomb);
    ToggleButton("Show Defuse Kit", &S2::g_Config.ESP.showDefuseKit);
    ToggleButton("Show Weapons", &S2::g_Config.ESP.showWeapons);
    ToggleButton("Show Grenades", &S2::g_Config.ESP.showGrenades);

    ImGui::EndChild();
}

void RenderAimbotTab() {
    ImGui::BeginChild("AimbotScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Aimbot Settings", S2::BanRisk::MEDIUM);
    ToggleButton("Enable Aimbot", &S2::g_Config.Aimbot.enabled);
    ToggleButton("Aim Lock", &S2::g_Config.Aimbot.aimLock);
    ToggleButton("Silent Aim", &S2::g_Config.Aimbot.silentAim);
    ToggleButton("Rage Aim", &S2::g_Config.Aimbot.rageAim);
    SliderFloat("FOV", &S2::g_Config.Aimbot.fov, 1.0f, 360.0f);
    SliderFloat("Smooth", &S2::g_Config.Aimbot.smooth, 1.0f, 20.0f);

    const char* bones[] = {"Head", "Neck", "Spine", "Hip"};
    ComboBox("Target Bone", &S2::g_Config.Aimbot.bone, bones, 4);

    ToggleButton("Team Check", &S2::g_Config.Aimbot.teamCheck);
    ToggleButton("Visible Check", &S2::g_Config.Aimbot.visibleCheck);
    ToggleButton("Auto Shoot", &S2::g_Config.Aimbot.autoShoot);
    ToggleButton("Auto Scope", &S2::g_Config.Aimbot.autoScope);
    SliderFloat("Max Distance", &S2::g_Config.Aimbot.maxDistance, 10.0f, 500.0f);

    SectionHeader("Advanced Aimbot", S2::BanRisk::MEDIUM);
    ToggleButton("Target Priority (Crosshair)", &S2::g_Config.Aimbot.targetPriority);
    ToggleButton("FOV Circle", &S2::g_Config.Aimbot.fovCircle);
    ToggleButton("Show Target", &S2::g_Config.Aimbot.showTarget);
    ToggleButton("Prediction", &S2::g_Config.Aimbot.prediction);
    SliderFloat("Prediction Factor", &S2::g_Config.Aimbot.predictionFactor, 0.0f, 2.0f);
    ToggleButton("Trigger Bot", &S2::g_Config.Aimbot.triggerBot);
    SliderFloat("Trigger Delay", &S2::g_Config.Aimbot.triggerDelay, 0.0f, 1.0f);
    ToggleButton("Magnet Aim", &S2::g_Config.Aimbot.magnetAim);
    SliderFloat("Magnet Strength", &S2::g_Config.Aimbot.magnetStrength, 0.0f, 1.0f);

    ImGui::EndChild();
}

void RenderWeaponTab() {
    ImGui::BeginChild("WeaponScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Weapon Modifications", S2::BanRisk::MEDIUM);
    ToggleButton("Enable Weapon", &S2::g_Config.Weapon.enabled);
    ToggleButton("No Recoil", &S2::g_Config.Weapon.noRecoil);
    ToggleButton("No Spread", &S2::g_Config.Weapon.noSpread);
    ToggleButton("Rapid Fire", &S2::g_Config.Weapon.rapidFire);
    ToggleButton("Instant Reload", &S2::g_Config.Weapon.instantReload);
    ToggleButton("Infinite Ammo", &S2::g_Config.Weapon.infiniteAmmo);
    ToggleButton("No Sway", &S2::g_Config.Weapon.noSway);
    ToggleButton("No Kick", &S2::g_Config.Weapon.noKick);
    ToggleButton("No Muzzle Flash", &S2::g_Config.Weapon.noMuzzleFlash);
    ToggleButton("No Shell Eject", &S2::g_Config.Weapon.noShellEject);
    ToggleButton("No Tracer", &S2::g_Config.Weapon.noTracer);

    SectionHeader("Dangerous Weapon", S2::BanRisk::DANGEROUS);
    ToggleButton("Wall Bang", &S2::g_Config.Weapon.wallBang);
    ToggleButton("One Hit", &S2::g_Config.Weapon.oneHit);
    ToggleButton("Damage Modifier", &S2::g_Config.Weapon.damageModifier);
    SliderFloat("Damage Multiplier", &S2::g_Config.Weapon.damageMult, 1.0f, 100.0f);
    SliderFloat("Fire Rate Multiplier", &S2::g_Config.Weapon.fireRateMult, 1.0f, 10.0f);
    SliderFloat("Range Multiplier", &S2::g_Config.Weapon.rangeMult, 1.0f, 10.0f);
    ToggleButton("Instant Kill", &S2::g_Config.Weapon.instantKill);
    ToggleButton("Always Headshot", &S2::g_Config.Weapon.alwaysHeadshot);
    ToggleButton("No Damage Falloff", &S2::g_Config.Weapon.noDamageFalloff);
    ToggleButton("Infinite Penetration", &S2::g_Config.Weapon.infinitePenetration);
    ToggleButton("No Reload Cancel", &S2::g_Config.Weapon.noReloadCancel);
    ToggleButton("Quick Switch", &S2::g_Config.Weapon.quickSwitch);
    ToggleButton("Auto Pistol", &S2::g_Config.Weapon.autoPistol);
    ToggleButton("Burst Mode", &S2::g_Config.Weapon.burstMode);
    SliderInt("Burst Count", &S2::g_Config.Weapon.burstCount, 2, 10);

    ImGui::EndChild();
}

void RenderMovementTab() {
    ImGui::BeginChild("MovementScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Movement Hacks", S2::BanRisk::DANGEROUS);
    ToggleButton("Enable Movement", &S2::g_Config.Movement.enabled);
    ToggleButton("Speed Hack", &S2::g_Config.Movement.speedHack);
    SliderFloat("Speed Multiplier", &S2::g_Config.Movement.speedMult, 1.0f, 10.0f);
    ToggleButton("Fly", &S2::g_Config.Movement.fly);
    SliderFloat("Fly Speed", &S2::g_Config.Movement.flySpeed, 1.0f, 20.0f);
    ToggleButton("No Clip", &S2::g_Config.Movement.noClip);
    ToggleButton("Super Jump", &S2::g_Config.Movement.superJump);
    SliderFloat("Jump Multiplier", &S2::g_Config.Movement.jumpMult, 1.0f, 10.0f);
    ToggleButton("Anti Gravity", &S2::g_Config.Movement.antiGravity);
    SliderFloat("Gravity Multiplier", &S2::g_Config.Movement.gravityMult, 0.0f, 2.0f);
    ToggleButton("Instant Stop", &S2::g_Config.Movement.instantStop);
    ToggleButton("Bunny Hop", &S2::g_Config.Movement.bunnyHop);
    ToggleButton("Auto Strafe", &S2::g_Config.Movement.autoStrafe);
    ToggleButton("Edge Jump", &S2::g_Config.Movement.edgeJump);
    ToggleButton("Crouch Fly", &S2::g_Config.Movement.crouchFly);
    ToggleButton("Fast Crouch", &S2::g_Config.Movement.fastCrouch);
    ToggleButton("No Fall Damage", &S2::g_Config.Movement.noFallDamage);
    ToggleButton("Infinite Stamina", &S2::g_Config.Movement.infiniteStamina);
    ToggleButton("Climb Walls", &S2::g_Config.Movement.climbWalls);

    SectionHeader("Teleport", S2::BanRisk::DANGEROUS);
    ToggleButton("Enable Teleport", &S2::g_Config.Movement.teleport);
    if (ImGui::Button("Save Position")) S2::g_Config.Movement.teleportSave = true;
    if (ImGui::Button("Load Position")) S2::g_Config.Movement.teleportLoad = true;

    ImGui::EndChild();
}

void RenderCombatTab() {
    ImGui::BeginChild("CombatScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Combat Hacks", S2::BanRisk::DANGEROUS);
    ToggleButton("Enable Combat", &S2::g_Config.Combat.enabled);
    ToggleButton("God Mode", &S2::g_Config.Combat.godMode);
    ToggleButton("Infinite Health", &S2::g_Config.Combat.infiniteHealth);
    ToggleButton("Infinite Armor", &S2::g_Config.Combat.infiniteArmor);
    ToggleButton("One Hit Kill", &S2::g_Config.Combat.oneHitKill);
    ToggleButton("Damage Modifier", &S2::g_Config.Combat.damageModifier);
    SliderFloat("Damage Multiplier", &S2::g_Config.Combat.damageMult, 1.0f, 100.0f);
    ToggleButton("Instant Kill", &S2::g_Config.Combat.instantKill);
    ToggleButton("No Knockback", &S2::g_Config.Combat.noKnockback);
    ToggleButton("No Stun", &S2::g_Config.Combat.noStun);
    ToggleButton("No Flash Effect", &S2::g_Config.Combat.noFlashEffect);
    ToggleButton("No Smoke Effect", &S2::g_Config.Combat.noSmokeEffect);
    ToggleButton("Heal On Kill", &S2::g_Config.Combat.healOnKill);
    SliderFloat("Heal Amount", &S2::g_Config.Combat.healAmount, 1.0f, 100.0f);
    ToggleButton("Auto Heal", &S2::g_Config.Combat.autoHeal);
    SliderFloat("Heal Threshold", &S2::g_Config.Combat.autoHealThreshold, 1.0f, 99.0f);

    ImGui::EndChild();
}

void RenderSkinsTab() {
    ImGui::BeginChild("SkinsScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Skin Changer", S2::BanRisk::EXTREME);
    ToggleButton("Enable Skins", &S2::g_Config.Skins.enabled);
    ToggleButton("Skin Changer", &S2::g_Config.Skins.skinChanger);
    ToggleButton("Knife Changer", &S2::g_Config.Skins.knifeChanger);
    ToggleButton("Glove Changer", &S2::g_Config.Skins.gloveChanger);
    ToggleButton("Sticker Changer", &S2::g_Config.Skins.stickerChanger);
    ToggleButton("All Skins", &S2::g_Config.Skins.allSkins);
    ToggleButton("Rare Knives", &S2::g_Config.Skins.rareKnives);
    ToggleButton("StatTrak", &S2::g_Config.Skins.statTrak);
    ToggleButton("Nametag", &S2::g_Config.Skins.nametag);
    ToggleButton("Wear Override", &S2::g_Config.Skins.wearOverride);
    SliderFloat("Wear Value", &S2::g_Config.Skins.wearValue, 0.0f, 1.0f);
    ToggleButton("Seed Override", &S2::g_Config.Skins.seedOverride);
    SliderInt("Seed Value", &S2::g_Config.Skins.seedValue, 0, 1000);

    if (ImGui::Button("Apply All Skins")) S2::ApplyAllSkins();

    ImGui::EndChild();
}

void RenderEconomyTab() {
    ImGui::BeginChild("EconomyScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Economy Hacks", S2::BanRisk::EXTREME);
    ToggleButton("Enable Economy", &S2::g_Config.Economy.enabled);
    ToggleButton("Money Hack", &S2::g_Config.Economy.moneyHack);
    SliderInt("Money Amount", &S2::g_Config.Economy.moneyAmount, 0, 9999999);
    ToggleButton("Gold Hack", &S2::g_Config.Economy.goldHack);
    SliderInt("Gold Amount", &S2::g_Config.Economy.goldAmount, 0, 9999999);
    ToggleButton("XP Hack", &S2::g_Config.Economy.xpHack);
    SliderInt("XP Amount", &S2::g_Config.Economy.xpAmount, 0, 9999999);
    ToggleButton("Level Hack", &S2::g_Config.Economy.levelHack);
    SliderInt("Level", &S2::g_Config.Economy.levelAmount, 1, 1000);
    ToggleButton("Medal Hack", &S2::g_Config.Economy.medalHack);
    ToggleButton("Case Hack", &S2::g_Config.Economy.caseHack);
    ToggleButton("Free Shop", &S2::g_Config.Economy.freeShop);
    ToggleButton("Free Cases", &S2::g_Config.Economy.freeCases);
    ToggleButton("Instant Open", &S2::g_Config.Economy.instantOpen);

    ImGui::EndChild();
}

void RenderSpoofTab() {
    ImGui::BeginChild("SpoofScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Device Spoofing", S2::BanRisk::MEDIUM);
    ToggleButton("Enable Spoofing", &S2::g_Config.Spoof.enabled);
    ToggleButton("Spoof Device", &S2::g_Config.Spoof.spoofDevice);
    ToggleButton("Spoof Android ID", &S2::g_Config.Spoof.spoofAndroidID);
    ToggleButton("Spoof IMEI", &S2::g_Config.Spoof.spoofIMEI);
    ToggleButton("Spoof IMSI", &S2::g_Config.Spoof.spoofIMSI);
    ToggleButton("Spoof MAC", &S2::g_Config.Spoof.spoofMAC);
    ToggleButton("Spoof Bluetooth MAC", &S2::g_Config.Spoof.spoofBluetoothMAC);
    ToggleButton("Spoof HWID", &S2::g_Config.Spoof.spoofHWID);
    ToggleButton("Spoof Fingerprint", &S2::g_Config.Spoof.spoofFingerprint);
    ToggleButton("Spoof Brand", &S2::g_Config.Spoof.spoofBrand);
    ToggleButton("Spoof Model", &S2::g_Config.Spoof.spoofModel);
    ToggleButton("Spoof Manufacturer", &S2::g_Config.Spoof.spoofManufacturer);
    ToggleButton("Spoof Board", &S2::g_Config.Spoof.spoofBoard);
    ToggleButton("Spoof Device Name", &S2::g_Config.Spoof.spoofDeviceName);
    ToggleButton("Spoof Product", &S2::g_Config.Spoof.spoofProduct);
    ToggleButton("Spoof Serial", &S2::g_Config.Spoof.spoofSerial);
    ToggleButton("Spoof Bootloader", &S2::g_Config.Spoof.spoofBootloader);
    ToggleButton("Spoof Radio", &S2::g_Config.Spoof.spoofRadio);

    SectionHeader("Standoff 2 Spoofing", S2::BanRisk::MEDIUM);
    ToggleButton("Spoof Standoff UUID", &S2::g_Config.Spoof.spoofStandoffUUID);
    ToggleButton("Spoof Standoff Token", &S2::g_Config.Spoof.spoofStandoffToken);
    ToggleButton("Spoof Standoff Account ID", &S2::g_Config.Spoof.spoofStandoffAccountID);
    ToggleButton("Spoof Standoff Session ID", &S2::g_Config.Spoof.spoofStandoffSessionID);
    ToggleButton("Spoof Standoff Signature", &S2::g_Config.Spoof.spoofStandoffSignature);

    SectionHeader("Ban Reset", S2::BanRisk::EXTREME);
    if (ImGui::Button("Reset Ban")) S2::g_Config.Spoof.resetBan = true;
    if (ImGui::Button("Clear Ban Flags")) S2::g_Config.Spoof.clearBanFlags = true;
    if (ImGui::Button("Spoof New Identity")) S2::g_Config.Spoof.spoofNewIdentity = true;
    if (ImGui::Button("Wipe Game Traces")) S2::g_Config.Spoof.wipeGameTraces = true;
    if (ImGui::Button("Wipe AntiCheat Logs")) S2::g_Config.Spoof.wipeAntiCheatLogs = true;

    SectionHeader("Network Spoofing", S2::BanRisk::MEDIUM);
    ToggleButton("Change IP", &S2::g_Config.Spoof.changeIP);
    ToggleButton("Use Proxy", &S2::g_Config.Spoof.useProxy);
    ImGui::InputText("Proxy Address", S2::g_Config.Spoof.proxyAddr, sizeof(S2::g_Config.Spoof.proxyAddr));
    ToggleButton("Spoof DNS", &S2::g_Config.Spoof.spoofDNS);

    SectionHeader("Anti-Report", S2::BanRisk::SAFE);
    ToggleButton("Block Reports", &S2::g_Config.Spoof.blockReports);
    ToggleButton("Block Kicks", &S2::g_Config.Spoof.blockKicks);
    ToggleButton("Block Spectate", &S2::g_Config.Spoof.blockSpectate);
    ToggleButton("Block Vote Kick", &S2::g_Config.Spoof.blockVoteKick);

    ImGui::EndChild();
}

void RenderRadarTab() {
    ImGui::BeginChild("RadarScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Radar Settings", S2::BanRisk::MEDIUM);
    ToggleButton("Enable Radar", &S2::g_Config.Radar.enabled);
    ToggleButton("Show Enemies", &S2::g_Config.Radar.showEnemies);
    ToggleButton("Show Teammates", &S2::g_Config.Radar.showTeammates);
    ToggleButton("Show Local Player", &S2::g_Config.Radar.showLocal);
    ToggleButton("Show Bomb", &S2::g_Config.Radar.showBomb);
    ToggleButton("Show Weapons", &S2::g_Config.Radar.showWeapons);
    ToggleButton("Show Grenades", &S2::g_Config.Radar.showGrenades);
    SliderFloat("Scale", &S2::g_Config.Radar.scale, 0.1f, 5.0f);
    SliderFloat("Zoom", &S2::g_Config.Radar.zoom, 0.1f, 5.0f);
    SliderFloat("Opacity", &S2::g_Config.Radar.opacity, 0.1f, 1.0f);
    SliderInt("Position X", &S2::g_Config.Radar.posX, 0, 1920);
    SliderInt("Position Y", &S2::g_Config.Radar.posY, 0, 1080);
    SliderInt("Size", &S2::g_Config.Radar.size, 50, 500);
    ToggleButton("Circle Shape", &S2::g_Config.Radar.circleShape);
    ToggleButton("Rotate With Player", &S2::g_Config.Radar.rotateWithPlayer);
    ToggleButton("Show Names", &S2::g_Config.Radar.showNames);
    ToggleButton("Show Health", &S2::g_Config.Radar.showHealth);
    ToggleButton("Show Distance", &S2::g_Config.Radar.showDistance);

    SectionHeader("Radar Share", S2::BanRisk::MEDIUM);
    ToggleButton("Share Link", &S2::g_Config.Radar.shareLink);
    if (S2::g_Config.Radar.shareLink) {
        ImGui::Text("Share URL: %s", S2::g_Config.Radar.shareURL);
        if (ImGui::Button("Generate Link")) S2::ShareRadarLink();
    }

    ImGui::EndChild();
}

void RenderMiscTab() {
    ImGui::BeginChild("MiscScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    SectionHeader("Miscellaneous", S2::BanRisk::SAFE);
    ToggleButton("Enable Misc", &S2::g_Config.Misc.enabled);
    ToggleButton("Anti AFK", &S2::g_Config.Misc.antiAFK);
    ToggleButton("Auto Accept", &S2::g_Config.Misc.autoAccept);
    ToggleButton("Auto Ready", &S2::g_Config.Misc.autoReady);
    ToggleButton("Auto Reconnect", &S2::g_Config.Misc.autoReconnect);
    ToggleButton("Skip Warmup", &S2::g_Config.Misc.skipWarmup);
    ToggleButton("Fast Restart", &S2::g_Config.Misc.fastRestart);
    ToggleButton("No Ads", &S2::g_Config.Misc.noAds);
    ToggleButton("Unlock FPS", &S2::g_Config.Misc.unlockFPS);
    SliderInt("Target FPS", &S2::g_Config.Misc.targetFPS, 30, 240);
    ToggleButton("Disable VSync", &S2::g_Config.Misc.disableVSync);
    ToggleButton("Force GPU", &S2::g_Config.Misc.forceGPU);
    ToggleButton("Reduce Lag", &S2::g_Config.Misc.reduceLag);
    ToggleButton("Ping Spoof", &S2::g_Config.Misc.pingSpoof);
    SliderInt("Fake Ping", &S2::g_Config.Misc.fakePing, 1, 999);
    ToggleButton("Name Stealer", &S2::g_Config.Misc.nameStealer);
    ToggleButton("Chat Spam", &S2::g_Config.Misc.chatSpam);
    ImGui::InputText("Spam Text", S2::g_Config.Misc.spamText, sizeof(S2::g_Config.Misc.spamText));
    SliderInt("Spam Interval (ms)", &S2::g_Config.Misc.spamInterval, 100, 10000);

    ImGui::EndChild();
}

void RenderAboutTab() {
    ImGui::BeginChild("AboutScroll", ImVec2(0, 0), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    ImGui::TextColored(g_ColorAccent, "ReVrax v2.0 - Standoff 2 Mod Menu");
    ImGui::Text("Build: 2026.08.29");
    ImGui::Text("Game Version: 0.39.2");
    ImGui::Text("Architecture: ARM64");
    ImGui::Separator();

    ImGui::TextColored(g_ColorPrimary, "Credits:");
    ImGui::Text("Code: Kimi 2.6 Moonshot AI");
    ImGui::Text("Dump & Text Support: Haru (Kimi User)");
    ImGui::Separator();

    ImGui::TextColored(g_ColorAccent, "Special Thanks:");
    ImGui::TextWrapped("миндальная связь трипл киндзи аска в больнице поддердка мистер бист за шаги гиги - @XSALLT on telegram |KKVAAZAR");
    ImGui::Separator();

    ImGui::TextColored(g_ColorWarning, "Disclaimer:");
    ImGui::TextWrapped("This tool is for educational purposes only. Use at your own risk.");
    ImGui::TextWrapped("The developers are not responsible for any bans or account suspensions.");

    ImGui::EndChild();
}

} // namespace Menu
} // namespace ReVrax
