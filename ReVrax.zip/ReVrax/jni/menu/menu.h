#pragma once
#include "../hooks/hooks.h"
#include "../il2cpp_structs.h"
#include <imgui.h>
#include <imgui_internal.h>
#include <imgui_impl_android.h>
#include <imgui_impl_opengl3.h>

namespace ReVrax {
namespace Menu {

// ==================== MENU STATE ====================
extern bool g_ShowMenu;
extern bool g_Initialized;
extern float g_MenuAlpha;
extern ImVec2 g_MenuPos;
extern ImVec2 g_MenuSize;

// ==================== THEME COLORS (Purple) ====================
extern ImVec4 g_ColorPrimary;      // Main purple
extern ImVec4 g_ColorSecondary;    // Light purple
extern ImVec4 g_ColorAccent;       // Bright purple
extern ImVec4 g_ColorBackground;   // Dark background
extern ImVec4 g_ColorForeground;   // Panel background
extern ImVec4 g_ColorText;         // White text
extern ImVec4 g_ColorTextDim;      // Dim text
extern ImVec4 g_ColorBorder;       // Border color
extern ImVec4 g_ColorSuccess;      // Green (safe)
extern ImVec4 g_ColorWarning;      // Yellow (medium)
extern ImVec4 g_ColorDanger;       // Red (dangerous)
extern ImVec4 g_ColorExtreme;      // Dark red (extreme)

// ==================== TAB ENUMS ====================
enum class MenuTab {
    Visual = 0,
    ESP = 1,
    Aimbot = 2,
    Weapon = 3,
    Movement = 4,
    Combat = 5,
    Skins = 6,
    Economy = 7,
    Spoof = 8,
    Radar = 9,
    Misc = 10,
    About = 11
};

extern MenuTab g_CurrentTab;

// ==================== MENU FUNCTIONS ====================
bool InitializeMenu();
void ShutdownMenu();
void RenderMenu();
void ApplyTheme();
void RenderVisualTab();
void RenderESPTab();
void RenderAimbotTab();
void RenderWeaponTab();
void RenderMovementTab();
void RenderCombatTab();
void RenderSkinsTab();
void RenderEconomyTab();
void RenderSpoofTab();
void RenderRadarTab();
void RenderMiscTab();
void RenderAboutTab();

// ==================== HELPER WIDGETS ====================
void RiskBadge(S2::BanRisk risk);
bool ToggleButton(const char* label, bool* value);
bool SliderFloat(const char* label, float* value, float min, float max, const char* format = "%.2f");
bool SliderInt(const char* label, int* value, int min, int max);
bool ColorPicker(const char* label, Color* color);
bool ComboBox(const char* label, int* current, const char* items[], int itemsCount);
void SectionHeader(const char* label, S2::BanRisk risk);
void SeparatorLine();

} // namespace Menu
} // namespace ReVrax
