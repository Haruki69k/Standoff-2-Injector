#include "renderer.h"
#include "../utils/logger.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>

namespace ReVrax {
namespace Renderer {

static bool g_oglInitialized = false;

bool InitializeOpenGL() {
    LOGI("[Renderer] Initializing OpenGL ES 3...");
    g_oglInitialized = true;
    return true;
}

void ShutdownOpenGL() {
    LOGI("[Renderer] Shutting down OpenGL ES 3...");
    g_oglInitialized = false;
}

} // namespace Renderer
} // namespace ReVrax
