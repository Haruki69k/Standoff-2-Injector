#pragma once

namespace ReVrax {
namespace Renderer {

enum class RenderAPI {
    OpenGLES3 = 0,
    Vulkan = 1,
    AutoDetect = 2
};

bool Initialize(RenderAPI api = RenderAPI::AutoDetect);
void Shutdown();
void BeginFrame();
void EndFrame();
bool IsInitialized();
RenderAPI GetCurrentAPI();

} // namespace Renderer
} // namespace ReVrax
