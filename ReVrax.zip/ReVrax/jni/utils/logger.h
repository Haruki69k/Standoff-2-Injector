#pragma once
#include <cstdio>
#include <android/log.h>

#define LOG_TAG "ReVrax"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

// Silent mode for production builds
#ifdef REVRAX_SILENT
  #undef LOGI
  #undef LOGD
  #undef LOGE
  #undef LOGW
  #define LOGI(...)
  #define LOGD(...)
  #define LOGE(...)
  #define LOGW(...)
#endif
