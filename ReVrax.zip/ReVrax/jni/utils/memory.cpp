#include "memory.h"
#include "logger.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <cstdio>
#include <cmath>

namespace Mem {

uintptr_t GetBaseAddress(const char* libName) {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, libName) && strstr(line, "r-xp")) {
            sscanf(line, "%lx", &base);
            break;
        }
    }
    fclose(fp);
    return base;
}

uintptr_t GetModuleSize(const char* libName) {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    char line[512];
    uintptr_t start = 0, end = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, libName) && strstr(line, "r-xp")) {
            sscanf(line, "%lx-%lx", &start, &end);
            break;
        }
    }
    fclose(fp);
    return end - start;
}

bool Read(uintptr_t addr, void* buf, size_t len) {
    if (!addr || !buf || addr < 0x1000) return false;
    memcpy(buf, (void*)addr, len);
    return true;
}

bool Write(uintptr_t addr, void* buf, size_t len) {
    if (!addr || !buf || addr < 0x1000) return false;
    size_t page_size = sysconf(_SC_PAGESIZE);
    uintptr_t page_start = addr & ~(page_size - 1);
    size_t page_len = ((addr + len - page_start) + page_size - 1) & ~(page_size - 1);
    if (mprotect((void*)page_start, page_len, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
        return false;
    memcpy((void*)addr, buf, len);
    mprotect((void*)page_start, page_len, PROT_READ | PROT_EXEC);
    return true;
}

bool SetProtection(uintptr_t addr, size_t len, int prot) {
    size_t page_size = sysconf(_SC_PAGESIZE);
    uintptr_t page_start = addr & ~(page_size - 1);
    size_t page_len = ((addr + len - page_start) + page_size - 1) & ~(page_size - 1);
    return mprotect((void*)page_start, page_len, prot) == 0;
}

void* Hook(void* target, void* replacement, void** original) {
    if (!target || !replacement || !original) return nullptr;
    *original = target;

    // ARM64 inline hook: 16 bytes
    // LDR X16, [PC, #8]
    // BR X16
    // .quad replacement
    uint32_t hook_code[4];
    hook_code[0] = 0x58000050; // LDR X16, #8
    hook_code[1] = 0xD61F0200; // BR X16

    uintptr_t addr = (uintptr_t)target;
    size_t page_size = sysconf(_SC_PAGESIZE);
    uintptr_t page_start = addr & ~(page_size - 1);
    size_t page_len = ((addr + 16 - page_start) + page_size - 1) & ~(page_size - 1);

    if (mprotect((void*)page_start, page_len, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
        return nullptr;

    // Save original bytes for unhook
    static uint8_t saved_bytes[16];
    memcpy(saved_bytes, target, 16);

    // Write hook
    memcpy((void*)addr, hook_code, 8);
    *(void**)(addr + 8) = replacement;

    __builtin___clear_cache((char*)addr, (char*)(addr + 16));
    mprotect((void*)page_start, page_len, PROT_READ | PROT_EXEC);

    return target;
}

void Unhook(void* target, void* original) {
    if (!target || !original) return;
    // Restore original bytes - would need saved_bytes storage per hook
}

uintptr_t FindPattern(uintptr_t start, size_t len, const char* pattern, const char* mask) {
    size_t patternLen = strlen(mask);
    for (size_t i = 0; i < len - patternLen; i++) {
        bool found = true;
        for (size_t j = 0; j < patternLen; j++) {
            if (mask[j] == 'x' && ((char*)start)[i + j] != pattern[j]) {
                found = false;
                break;
            }
        }
        if (found) return start + i;
    }
    return 0;
}

uintptr_t FindPattern(const char* libName, const char* pattern, const char* mask) {
    uintptr_t base = GetBaseAddress(libName);
    if (!base) return 0;
    uintptr_t size = GetModuleSize(libName);
    return FindPattern(base, size, pattern, mask);
}

std::vector<uintptr_t> FindAllPatterns(const char* libName, const char* pattern, const char* mask) {
    std::vector<uintptr_t> results;
    uintptr_t base = GetBaseAddress(libName);
    if (!base) return results;
    uintptr_t size = GetModuleSize(libName);
    size_t patternLen = strlen(mask);
    for (size_t i = 0; i < size - patternLen; i++) {
        bool found = true;
        for (size_t j = 0; j < patternLen; j++) {
            if (mask[j] == 'x' && ((char*)base)[i + j] != pattern[j]) {
                found = false;
                break;
            }
        }
        if (found) results.push_back(base + i);
    }
    return results;
}

uintptr_t FollowPointer(uintptr_t base, std::initializer_list<uintptr_t> offsets) {
    uintptr_t addr = base;
    for (auto offset : offsets) {
        if (!addr || addr < 0x1000) return 0;
        addr = Read<uintptr_t>(addr);
        if (!addr || addr < 0x1000) return 0;
        addr += offset;
    }
    return addr;
}

void HexDump(uintptr_t addr, size_t len) {
    LOGD("[Memory] Hex dump @ 0x%llx (%zu bytes):", (unsigned long long)addr, len);
    for (size_t i = 0; i < len; i += 16) {
        char hex[128] = {0};
        char ascii[32] = {0};
        for (size_t j = 0; j < 16 && (i + j) < len; j++) {
            uint8_t b = Read<uint8_t>(addr + i + j);
            sprintf(hex + j * 3, "%02x ", b);
            ascii[j] = (b >= 32 && b < 127) ? (char)b : '.';
        }
        LOGD("  %04zx: %s | %s", i, hex, ascii);
    }
}

std::vector<ModuleInfo> GetModules() {
    std::vector<ModuleInfo> modules;
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return modules;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, ".so") && strstr(line, "r-xp")) {
            uintptr_t start, end;
            char name[256] = {0};
            sscanf(line, "%lx-%lx %*s %*s %*s %*s %s", &start, &end, name);
            if (strlen(name) > 0) {
                ModuleInfo info;
                info.name = name;
                info.base = start;
                info.size = end - start;
                modules.push_back(info);
            }
        }
    }
    fclose(fp);
    return modules;
}

std::string ReadString(uintptr_t addr, size_t maxLen) {
    std::string result;
    if (!addr || addr < 0x1000) return result;
    for (size_t i = 0; i < maxLen; i++) {
        char c = Read<char>(addr + i);
        if (c == '\0') break;
        result += c;
    }
    return result;
}

std::string ReadIl2CppString(void* str) {
    if (!str) return "";
    // Il2CppString: Il2CppObject + int32_t length + wchar_t chars[]
    int32_t len = Read<int32_t>((uintptr_t)str + sizeof(void*) * 2);
    if (len <= 0 || len > 1024) return "";
    std::string result;
    for (int i = 0; i < len; i++) {
        wchar_t wc = Read<wchar_t>((uintptr_t)str + sizeof(void*) * 2 + sizeof(int32_t) + i * sizeof(wchar_t));
        if (wc < 128) result += (char)wc;
        else result += '?';
    }
    return result;
}

bool BypassVmProtect(const char* libName) {
    // Placeholder for VMProtect bypass
    // Real implementation would patch VMProtect handlers
    LOGI("[Memory] VMProtect bypass attempt for %s", libName);
    return true;
}

std::vector<uintptr_t> ScanMemory(uintptr_t start, size_t len, const void* data, size_t dataLen) {
    std::vector<uintptr_t> results;
    if (!start || !data || dataLen == 0) return results;
    for (size_t i = 0; i < len - dataLen; i++) {
        if (memcmp((void*)(start + i), data, dataLen) == 0) {
            results.push_back(start + i);
        }
    }
    return results;
}

std::vector<uintptr_t> ScanMemoryFloat(uintptr_t start, size_t len, float value, float tolerance) {
    std::vector<uintptr_t> results;
    if (!start) return results;
    for (size_t i = 0; i < len - sizeof(float); i += sizeof(float)) {
        float readVal = Read<float>(start + i);
        if (fabsf(readVal - value) <= tolerance) {
            results.push_back(start + i);
        }
    }
    return results;
}

std::vector<uintptr_t> ScanMemoryInt(uintptr_t start, size_t len, int32_t value) {
    std::vector<uintptr_t> results;
    if (!start) return results;
    for (size_t i = 0; i < len - sizeof(int32_t); i += sizeof(int32_t)) {
        if (Read<int32_t>(start + i) == value) {
            results.push_back(start + i);
        }
    }
    return results;
}

} // namespace Mem
