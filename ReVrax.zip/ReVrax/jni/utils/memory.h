#pragma once
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <unistd.h>
#include <sys/mman.h>
#include <dlfcn.h>
#include <cstring>

namespace Mem {
    uintptr_t GetBaseAddress(const char* libName);
    uintptr_t GetModuleSize(const char* libName);
    bool Read(uintptr_t addr, void* buf, size_t len);
    bool Write(uintptr_t addr, void* buf, size_t len);

    template<typename T>
    T Read(uintptr_t addr) { 
        T val{}; 
        Read(addr, &val, sizeof(T)); 
        return val; 
    }

    template<typename T>
    void Write(uintptr_t addr, T val) { 
        Write(addr, &val, sizeof(T)); 
    }

    bool SetProtection(uintptr_t addr, size_t len, int prot);
    void* Hook(void* target, void* replacement, void** original);
    void Unhook(void* target, void* original);
    uintptr_t FindPattern(const char* libName, const char* pattern, const char* mask);
    uintptr_t FindPattern(uintptr_t start, size_t len, const char* pattern, const char* mask);
    std::vector<uintptr_t> FindAllPatterns(const char* libName, const char* pattern, const char* mask);

    // Safe memory operations with validation
    template<typename T>
    bool SafeRead(uintptr_t addr, T& out) {
        if (!addr || addr < 0x1000) return false;
        return Read(addr, &out, sizeof(T));
    }

    template<typename T>
    bool SafeWrite(uintptr_t addr, T val) {
        if (!addr || addr < 0x1000) return false;
        return Write(addr, &val, sizeof(T));
    }

    // Pointer chain following
    uintptr_t FollowPointer(uintptr_t base, std::initializer_list<uintptr_t> offsets);

    // Memory dump
    void HexDump(uintptr_t addr, size_t len);

    // Module enumeration
    struct ModuleInfo {
        std::string name;
        uintptr_t base;
        size_t size;
    };
    std::vector<ModuleInfo> GetModules();

    // String operations
    std::string ReadString(uintptr_t addr, size_t maxLen = 256);
    std::string ReadIl2CppString(void* str);

    // VM protection bypass
    bool BypassVmProtect(const char* libName);

    // Memory scanning
    std::vector<uintptr_t> ScanMemory(uintptr_t start, size_t len, const void* data, size_t dataLen);
    std::vector<uintptr_t> ScanMemoryFloat(uintptr_t start, size_t len, float value, float tolerance = 0.001f);
    std::vector<uintptr_t> ScanMemoryInt(uintptr_t start, size_t len, int32_t value);
}
