# ProGuard rules for ReVrax
-keep class com.revrax.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
