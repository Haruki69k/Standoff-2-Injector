#pragma once
#include "../il2cpp_structs.h"
#include "../utils/memory.h"
#include "../utils/logger.h"
#include <vector>
#include <cmath>

using namespace IL2CPP;

namespace S2 {

// ==================== BAN RISK LEVELS ====================
enum class BanRisk {
    SAFE = 0,      // Visual only, no gameplay modification
    MEDIUM = 1,    // ESP, Aimbot with smoothing
    DANGEROUS = 2, // Instant kill, speed hack, fly
    EXTREME = 3    // Money hack, skin changer server-side
};

// ==================== CHEAT CONFIG ====================
struct CheatConfig {
    // --- SAFE (Low ban risk) ---
    struct {
        bool enabled = false;
        float fov = 90.0f;
        bool thirdPerson = false;
        float viewModelFov = 68.0f;
        bool noFlash = false;
        bool noSmoke = false;
        bool brightMode = false;
        bool removeScopeBlur = false;
        bool customCrosshair = false;
        float crosshairSize = 4.0f;
        Color crosshairColor = Color(1,0,0,1);
        bool nightMode = false;
        float nightModeIntensity = 0.3f;
        bool fullBright = false;
        bool disableFog = false;
        bool disableBloom = false;
        bool disableMotionBlur = false;
        bool disableDepthOfField = false;
        bool wireframeMode = false;
        bool chamsEnabled = false;
        Color chamsColor = Color(0,1,1,0.5f);
        bool chamsVisibleOnly = false;
        bool chamsRainbow = false;
    } Visual;

    // --- MEDIUM (Medium ban risk) ---
    struct {
        bool enabled = false;
        bool box = false;
        bool skeleton = false;
        bool name = false;
        bool health = false;
        bool armor = false;
        bool distance = false;
        bool weapon = false;
        bool teamCheck = true;
        bool visibleOnly = false;
        float maxDistance = 200.0f;
        Color enemyColor = Color(1,0,0,1);
        Color teamColor = Color(0,1,0,1);
        Color visibleColor = Color(0,1,1,1);
        bool snaplines = false;
        bool headDot = false;
        bool healthBar = false;
        bool armorBar = false;
        bool tracers = false;
        bool offScreenArrows = false;
        bool showBomb = false;
        bool showDefuseKit = false;
        bool showWeapons = false;
        bool showGrenades = false;
        bool showHostages = false;
        bool showDecoys = false;
    } ESP;

    // --- MEDIUM (Medium ban risk) ---
    struct {
        bool enabled = false;
        bool aimLock = false;
        bool silentAim = false;
        bool rageAim = false;
        float fov = 90.0f;
        float smooth = 5.0f;
        int bone = 0; // 0=Head, 1=Neck, 2=Spine, 3=Hip
        bool teamCheck = true;
        bool visibleCheck = false;
        bool autoShoot = false;
        bool autoScope = false;
        float maxDistance = 150.0f;
        bool targetPriority = false; // Priority: closest to crosshair
        bool fovCircle = true;
        bool showTarget = false;
        bool prediction = false;
        float predictionFactor = 0.5f;
        bool triggerBot = false;
        float triggerDelay = 0.0f;
        bool magnetAim = false;
        float magnetStrength = 0.3f;
    } Aimbot;

    // --- MEDIUM (Medium ban risk) ---
    struct {
        bool enabled = false;
        bool noRecoil = false;
        bool noSpread = false;
        bool rapidFire = false;
        bool instantReload = false;
        bool infiniteAmmo = false;
        bool noSway = false;
        bool noKick = false;
        bool noMuzzleFlash = false;
        bool noShellEject = false;
        bool noTracer = false;
        bool wallBang = false; // Shoot through walls
        bool oneHit = false;
        float damageMult = 1.0f;
        float fireRateMult = 1.0f;
        float rangeMult = 1.0f;
        bool instantKill = false;
        bool alwaysHeadshot = false;
        bool noDamageFalloff = false;
        bool infinitePenetration = false;
        bool noReloadCancel = false;
        bool quickSwitch = false;
        bool autoPistol = false;
        bool burstMode = false;
        int burstCount = 3;
    } Weapon;

    // --- DANGEROUS (High ban risk) ---
    struct {
        bool enabled = false;
        bool speedHack = false;
        float speedMult = 1.5f;
        bool fly = false;
        float flySpeed = 5.0f;
        bool noClip = false;
        bool superJump = false;
        float jumpMult = 2.0f;
        bool antiGravity = false;
        float gravityMult = 0.5f;
        bool instantStop = false;
        bool bunnyHop = false;
        bool autoStrafe = false;
        bool edgeJump = false;
        bool crouchFly = false;
        bool fastCrouch = false;
        bool noFallDamage = false;
        bool infiniteStamina = false;
        bool climbWalls = false;
        bool teleport = false;
        Vector3 teleportPos;
        bool teleportSave = false;
        bool teleportLoad = false;
    } Movement;

    // --- DANGEROUS (High ban risk) ---
    struct {
        bool enabled = false;
        bool godMode = false;
        bool infiniteHealth = false;
        bool infiniteArmor = false;
        bool oneHitKill = false;
        bool damageModifier = false;
        float damageMult = 10.0f;
        bool instantKill = false;
        bool noKnockback = false;
        bool noStun = false;
        bool noFlashEffect = false;
        bool noSmokeEffect = false;
        bool healOnKill = false;
        float healAmount = 50.0f;
        bool autoHeal = false;
        float autoHealThreshold = 30.0f;
    } Combat;

    // --- DANGEROUS (Very high ban risk) ---
    struct {
        bool enabled = false;
        bool skinChanger = false;
        bool knifeChanger = false;
        bool gloveChanger = false;
        bool stickerChanger = false;
        bool allSkins = false;
        bool rareKnives = false;
        bool statTrak = false;
        bool nametag = false;
        bool wearOverride = false;
        float wearValue = 0.0f;
        bool seedOverride = false;
        int seedValue = 0;
    } Skins;

    // --- DANGEROUS (Very high ban risk) ---
    struct {
        bool enabled = false;
        bool moneyHack = false;
        int moneyAmount = 999999;
        bool goldHack = false;
        int goldAmount = 999999;
        bool xpHack = false;
        int xpAmount = 999999;
        bool levelHack = false;
        int levelAmount = 100;
        bool medalHack = false;
        bool caseHack = false;
        bool freeShop = false;
        bool freeCases = false;
        bool instantOpen = false;
    } Economy;

    // --- SPOOFING (Ban risk varies) ---
    struct {
        bool enabled = false;
        bool spoofDevice = false;
        bool spoofAndroidID = false;
        bool spoofIMEI = false;
        bool spoofIMSI = false;
        bool spoofMAC = false;
        bool spoofBluetoothMAC = false;
        bool spoofHWID = false;
        bool spoofFingerprint = false;
        bool spoofBrand = false;
        bool spoofModel = false;
        bool spoofManufacturer = false;
        bool spoofBoard = false;
        bool spoofDeviceName = false;
        bool spoofProduct = false;
        bool spoofSerial = false;
        bool spoofBootloader = false;
        bool spoofRadio = false;
        bool spoofStandoffUUID = false;
        bool spoofStandoffToken = false;
        bool spoofStandoffAccountID = false;
        bool spoofStandoffSessionID = false;
        bool spoofStandoffSignature = false;
        bool resetBan = false;
        bool clearBanFlags = false;
        bool spoofNewIdentity = false;
        bool wipeGameTraces = false;
        bool wipeAntiCheatLogs = false;
        bool changeIP = false;
        bool useProxy = false;
        char proxyAddr[256];
        bool spoofDNS = false;
        bool blockReports = false;
        bool blockKicks = false;
        bool blockSpectate = false;
        bool blockVoteKick = false;
    } Spoof;

    // --- RADAR (Medium ban risk) ---
    struct {
        bool enabled = false;
        bool showEnemies = true;
        bool showTeammates = false;
        bool showLocal = true;
        bool showBomb = true;
        bool showWeapons = true;
        bool showGrenades = true;
        bool shareLink = false;
        char shareURL[256];
        float scale = 1.0f;
        float zoom = 1.0f;
        float opacity = 0.8f;
        int posX = 20;
        int posY = 20;
        int size = 200;
        bool circleShape = true;
        bool rotateWithPlayer = true;
        bool showNames = false;
        bool showHealth = false;
        bool showDistance = false;
    } Radar;

    // --- MISC ---
    struct {
        bool enabled = false;
        bool antiAFK = false;
        bool autoAccept = false;
        bool autoReady = false;
        bool autoReconnect = false;
        bool skipWarmup = false;
        bool fastRestart = false;
        bool noAds = false;
        bool unlockFPS = false;
        int targetFPS = 120;
        bool disableVSync = false;
        bool forceGPU = false;
        bool reduceLag = false;
        bool pingSpoof = false;
        int fakePing = 30;
        bool nameStealer = false;
        bool chatSpam = false;
        char spamText[256];
        int spamInterval = 1000;
    } Misc;
};

extern CheatConfig g_Config;

// ==================== HOOK TARGETS ====================
extern void* o_PlayerController_Update;
extern void* o_AimController_Update;
extern void* o_GunController_Shoot;
extern void* o_GunController_GetSpread;
extern void* o_GunController_GetRecoil;
extern void* o_GunController_GetFireRate;
extern void* o_GunController_GetDamage;
extern void* o_GunController_GetRange;
extern void* o_GunController_Reload;
extern void* o_DamageEffectController_Apply;
extern void* o_PlayerHitbox_GetPosition;
extern void* o_MovementController_Update;
extern void* o_AntiCheatManager_Report;
extern void* o_AntiCheatManager_Ban;
extern void* o_AntiCheatManager_Kick;
extern void* o_AntiCheatManager_CheckIntegrity;
extern void* o_AntiCheatManager_ScanMemory;
extern void* o_PhotonView_RPC;
extern void* o_PhotonView_Send;
extern void* o_Camera_WorldToScreenPoint;
extern void* o_Camera_get_fieldOfView;
extern void* o_Camera_set_fieldOfView;
extern void* o_Transform_get_position;
extern void* o_Transform_set_position;
extern void* o_CharacterController_Move;
extern void* o_CharacterController_get_isGrounded;
extern void* o_Reports_SendReport;
extern void* o_KickVote_Process;
extern void* o_Spectate_Follow;
extern void* o_RadarManager_Update;
extern void* o_WeaponryController_SwitchWeapon;
extern void* o_PlayerController_get_Health;
extern void* o_PlayerController_set_Health;
extern void* o_PlayerController_get_Armor;
extern void* o_PlayerController_set_Armor;
extern void* o_NetworkController_SendRPC;
extern void* o_Animator_GetBoneTransform;

// ==================== HOOK FUNCTIONS ====================
void PlayerController_Update_Hook(void* self);
void AimController_Update_Hook(void* self);
void GunController_Shoot_Hook(void* self);
float GunController_GetSpread_Hook(void* self);
Vector3 GunController_GetRecoil_Hook(void* self);
float GunController_GetFireRate_Hook(void* self);
float GunController_GetDamage_Hook(void* self);
float GunController_GetRange_Hook(void* self);
void GunController_Reload_Hook(void* self);
void DamageEffectController_Apply_Hook(void* self, float damage, void* attacker, int damageType);
Vector3 PlayerHitbox_GetPosition_Hook(void* self);
void MovementController_Update_Hook(void* self);
void AntiCheatManager_Report_Hook(void* self, void* player, int reason);
void AntiCheatManager_Ban_Hook(void* self, void* player, int code, int duration);
void AntiCheatManager_Kick_Hook(void* self, void* player, void* reason);
bool AntiCheatManager_CheckIntegrity_Hook(void* self);
void AntiCheatManager_ScanMemory_Hook(void* self);
void PhotonView_RPC_Hook(void* self, void* method, void* target, void* params);
void PhotonView_Send_Hook(void* self, void* data);
Vector3 Camera_WorldToScreenPoint_Hook(void* self, Vector3 pos, int eye);
float Camera_get_fieldOfView_Hook(void* self);
void Camera_set_fieldOfView_Hook(void* self, float fov);
Vector3 Transform_get_position_Hook(void* self);
void Transform_set_position_Hook(void* self, Vector3 pos);
void CharacterController_Move_Hook(void* self, Vector3 motion);
bool CharacterController_get_isGrounded_Hook(void* self);
void Reports_SendReport_Hook(void* self, void* target, int reason, void* details);
void KickVote_Process_Hook(void* self, void* args);
void Spectate_Follow_Hook(void* self, void* player);
void RadarManager_Update_Hook(void* self);
void WeaponryController_SwitchWeapon_Hook(void* self, int slot);
int PlayerController_get_Health_Hook(void* self);
void PlayerController_set_Health_Hook(void* self, int val);
int PlayerController_get_Armor_Hook(void* self);
void PlayerController_set_Armor_Hook(void* self, int val);
void NetworkController_SendRPC_Hook(void* self, void* method, void* target, void* params);
void* Animator_GetBoneTransform_Hook(void* self, int humanBoneId);

// ==================== HELPER FUNCTIONS ====================
std::vector<void*> GetAllPlayers();
void* GetLocalPlayer();
Team GetPlayerTeam(void* player);
int GetPlayerHealth(void* player);
int GetPlayerArmor(void* player);
bool IsPlayerDead(void* player);
bool IsPlayerLocal(void* player);
Vector3 GetPlayerPosition(void* player);
Vector3 GetPlayerHeadPosition(void* player);
Vector3 GetPlayerBonePosition(void* player, Bip bone);
const char* GetPlayerName(void* player);
void* GetPlayerWeapon(void* player);
int GetPlayerWeaponId(void* player);
float GetDistanceToPlayer(void* player);
bool IsPlayerVisible(void* player);
bool IsPlayerVisibleBone(void* player, Bip bone);
bool IsTeammate(void* player);
void* GetClosestPlayer(float maxDist, bool visibleOnly, bool teamCheck);
void* GetClosestPlayerToCrosshair(float fov, bool visibleOnly, bool teamCheck);
Vector3 WorldToScreen(Vector3 worldPos);
bool IsOnScreen(Vector3 screenPos);
float GetCrosshairDistance(Vector3 screenPos);
void* GetMainCamera();
Vector3 GetCameraPosition();
Vector3 GetCameraForward();
void SetCameraFOV(float fov);
float GetCameraFOV();
void* GetAimController();
void* GetWeaponryController();
void* GetMovementController();
void* GetCurrentGun();
void* GetGunParameters(void* gun);

// ==================== AIMBOT FUNCTIONS ====================
void RunAimbot();
void RunSilentAim();
void RunRageAim();
void RunTriggerBot();
void RunMagnetAim();
Vector3 GetAimTargetPosition(void* player, int bone);
void AimAt(Vector3 target);
void SmoothAim(Vector3 target, float smooth);
float CalculateFOV(Vector3 target);
bool IsTargetValid(void* player);

// ==================== ESP FUNCTIONS ====================
void DrawESP();
void DrawBox(void* player, Color color);
void DrawSkeleton(void* player, Color color);
void DrawHealthBar(void* player);
void DrawArmorBar(void* player);
void DrawName(void* player, Color color);
void DrawDistance(void* player);
void DrawWeapon(void* player);
void DrawSnapline(void* player, Color color);
void DrawHeadDot(void* player, Color color);
void DrawTracers(void* player);
void DrawOffScreenArrow(void* player, Color color);

// ==================== RADAR FUNCTIONS ====================
void DrawRadar();
void UpdateRadar();
void DrawRadarPlayer(void* player, Vector2 pos, Color color);
void DrawRadarLocalPlayer(Vector2 pos);
void ShareRadarLink();

// ==================== MOVEMENT FUNCTIONS ====================
void RunSpeedHack();
void RunFly();
void RunNoClip();
void RunSuperJump();
void RunAntiGravity();
void RunBunnyHop();
void RunAutoStrafe();
void RunTeleport();

// ==================== WEAPON FUNCTIONS ====================
void RunNoRecoil();
void RunNoSpread();
void RunRapidFire();
void RunInstantReload();
void RunInfiniteAmmo();
void RunWallBang();
void RunOneHit();
void RunDamageModifier();
void RunAutoShoot();

// ==================== COMBAT FUNCTIONS ====================
void RunGodMode();
void RunInfiniteHealth();
void RunInfiniteArmor();
void RunHealOnKill();
void RunAutoHeal();

// ==================== SKIN FUNCTIONS ====================
void RunSkinChanger();
void RunKnifeChanger();
void RunGloveChanger();
void RunStickerChanger();
void ApplyAllSkins();

// ==================== SPOOF FUNCTIONS ====================
void RunSpoofing();
void RunBanReset();
void RunBlockReports();
void RunBlockKicks();
void RunBlockSpectate();
void RunBlockVoteKick();

// ==================== INIT / SHUTDOWN ====================
bool InitializeHooks();
void ShutdownHooks();
void UpdateAll();

} // namespace S2
